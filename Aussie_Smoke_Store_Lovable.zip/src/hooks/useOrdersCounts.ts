import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Single source of truth for order counts across the entire app.
 *
 * A module-level store shares one cache + one Realtime subscription
 * between every consumer (admin dashboard, analytics, storefront
 * social proof, etc.) so every widget renders the exact same number
 * and reacts to inserts/updates/deletes at the same moment.
 */
export interface OrdersCounts {
  total: number;
  pending: number;
  last24h: number;
  paidRevenue: number;
  paidCount: number;
  loading: boolean;
  lastUpdated: number | null;
}

const initial: OrdersCounts = {
  total: 0,
  pending: 0,
  last24h: 0,
  paidRevenue: 0,
  paidCount: 0,
  loading: true,
  lastUpdated: null,
};


let cache: OrdersCounts = initial;
const listeners = new Set<(c: OrdersCounts) => void>();
let channel: ReturnType<typeof supabase.channel> | null = null;
let debounce: ReturnType<typeof setTimeout> | null = null;
let inflight: Promise<void> | null = null;

const emit = () => {
  for (const l of listeners) l(cache);
};

const fetchCounts = async () => {
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const [totalRes, pendingRes, last24Res, paidRes] = await Promise.all([
        supabase.from("orders").select("*", { count: "exact", head: true }),
        supabase
          .from("orders")
          .select("*", { count: "exact", head: true })
          .eq("status", "pending"),
        supabase
          .from("orders")
          .select("*", { count: "exact", head: true })
          .gte("created_at", since),
        // paginated sum of paid order totals (PostgREST caps per-request at 1000)
        (async () => {
          const PAGE = 1000;
          let sum = 0;
          let count = 0;
          for (let from = 0; ; from += PAGE) {
            const { data, error } = await supabase
              .from("orders")
              .select("total")
              .eq("payment_status", "paid")
              .range(from, from + PAGE - 1);
            if (error) throw error;
            if (!data || data.length === 0) break;
            for (const r of data) {
              sum += Number((r as { total: number }).total) || 0;
              count += 1;
            }
            if (data.length < PAGE) break;
          }
          return { sum, count };
        })(),
      ]);

      const paid = await paidRes;
      cache = {
        total: totalRes.count ?? 0,
        pending: pendingRes.count ?? 0,
        last24h: last24Res.count ?? 0,
        paidRevenue: paid.sum,
        paidCount: paid.count,
        loading: false,
        lastUpdated: Date.now(),
      };

      emit();
    } catch (err) {
      console.error("[useOrdersCounts] fetch failed:", err);
      cache = { ...cache, loading: false };
      emit();
    } finally {
      inflight = null;
    }
  })();
  return inflight;
};

const schedule = () => {
  if (debounce) clearTimeout(debounce);
  debounce = setTimeout(fetchCounts, 300);
};

const ensureSubscription = () => {
  if (channel) return;
  channel = supabase
    .channel("orders-counts-shared")
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "orders" },
      schedule,
    )
    .subscribe();
};

const teardownIfIdle = () => {
  if (listeners.size === 0 && channel) {
    supabase.removeChannel(channel);
    channel = null;
    if (debounce) {
      clearTimeout(debounce);
      debounce = null;
    }
  }
};

/**
 * Subscribe to the shared orders counts. Every consumer sees the same
 * numbers and updates in lockstep whenever orders change.
 */
export function useOrdersCounts(): OrdersCounts {
  const [snapshot, setSnapshot] = useState<OrdersCounts>(cache);

  useEffect(() => {
    listeners.add(setSnapshot);
    ensureSubscription();
    // If cache is stale (older than 30s) or empty, refresh
    if (!cache.lastUpdated || Date.now() - cache.lastUpdated > 30_000) {
      fetchCounts();
    } else {
      setSnapshot(cache);
    }
    return () => {
      listeners.delete(setSnapshot);
      teardownIfIdle();
    };
  }, []);

  return snapshot;
}

/** Force an immediate refresh from any component (rarely needed). */
export const refreshOrdersCounts = fetchCounts;
