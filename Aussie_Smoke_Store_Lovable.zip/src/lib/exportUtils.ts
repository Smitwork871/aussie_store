import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";

export const exportToCSV = (data: Record<string, any>[], filename: string) => {
  if (data.length === 0) {
    return;
  }

  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(","),
    ...data.map((row) =>
      headers
        .map((header) => {
          const value = row[header];
          // Handle null/undefined
          if (value === null || value === undefined) {
            return "";
          }
          // Handle objects/arrays by converting to JSON string
          if (typeof value === "object") {
            return `"${JSON.stringify(value).replace(/"/g, '""')}"`;
          }
          // Handle strings with commas, quotes, or newlines
          if (typeof value === "string" && (value.includes(",") || value.includes('"') || value.includes("\n"))) {
            return `"${value.replace(/"/g, '""')}"`;
          }
          return value;
        })
        .join(",")
    ),
  ].join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `${filename}_${format(new Date(), "yyyy-MM-dd_HH-mm")}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

const formatShippingAddress = (addr: Record<string, any> | null | undefined) => {
  if (!addr) return "";
  const parts = [
    addr.address_line1,
    addr.address_line2,
    addr.city,
    addr.state,
    addr.postal_code,
    addr.country,
  ].filter((p) => p && String(p).trim().length > 0);
  return parts.join(", ");
};

export const exportCustomers = async () => {
  const { data: profiles, error } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) throw error;

  const { data: orders, error: ordersError } = await supabase
    .from("orders")
    .select("user_id, guest_email, order_number, total, shipping_address, created_at")
    .order("created_at", { ascending: false });

  if (ordersError) throw ordersError;

  type OrderAgg = {
    order_numbers: string[];
    total_amount: number;
    latest_address: string;
  };
  const byUser = new Map<string, OrderAgg>();
  orders?.forEach((o) => {
    if (!o.user_id) return;
    const existing =
      byUser.get(o.user_id) ||
      ({ order_numbers: [], total_amount: 0, latest_address: "" } as OrderAgg);
    existing.order_numbers.push(o.order_number);
    existing.total_amount += Number(o.total) || 0;
    if (!existing.latest_address) {
      existing.latest_address = formatShippingAddress(
        o.shipping_address as Record<string, any> | null
      );
    }
    byUser.set(o.user_id, existing);
  });

  const formattedData = profiles?.map((profile) => {
    const agg = byUser.get(profile.user_id);
    return {
      email: profile.email,
      full_name: profile.full_name || "",
      phone: profile.phone || "",
      age_verified: profile.age_verified ? "Yes" : "No",
      age_verified_at: profile.age_verified_at
        ? format(new Date(profile.age_verified_at), "yyyy-MM-dd HH:mm")
        : "",
      shipping_address: agg?.latest_address || "",
      order_numbers: agg?.order_numbers.join(" | ") || "",
      total_orders: agg?.order_numbers.length || 0,
      total_order_amount: (agg?.total_amount || 0).toFixed(2),
      created_at: format(new Date(profile.created_at), "yyyy-MM-dd HH:mm"),
      updated_at: format(new Date(profile.updated_at), "yyyy-MM-dd HH:mm"),
    };
  });

  exportToCSV(formattedData || [], "customers");
  return formattedData?.length || 0;
};

export const exportOrders = async () => {
  const { data: orders, error } = await supabase
    .from("orders")
    .select("*, order_items(*)")
    .order("created_at", { ascending: false });

  if (error) throw error;

  const formattedData = orders?.map((order) => {
    const shippingAddress = order.shipping_address as Record<string, any> | null;
    return {
      order_number: order.order_number,
      status: order.status,
      payment_status: order.payment_status,
      payment_method: order.payment_method || "",
      subtotal: order.subtotal,
      tax_amount: order.tax_amount,
      shipping_amount: order.shipping_amount,
      discount_amount: order.discount_amount,
      total: order.total,
      items_count: order.order_items?.length || 0,
      guest_email: order.guest_email || "",
      shipping_name: shippingAddress?.full_name || "",
      shipping_address: shippingAddress
        ? `${shippingAddress.address_line1 || ""}, ${shippingAddress.city || ""}, ${shippingAddress.state || ""} ${shippingAddress.postal_code || ""}`
        : "",
      shipping_phone: shippingAddress?.phone || "",
      notes: order.notes || "",
      created_at: format(new Date(order.created_at), "yyyy-MM-dd HH:mm"),
      shipped_at: order.shipped_at
        ? format(new Date(order.shipped_at), "yyyy-MM-dd HH:mm")
        : "",
      delivered_at: order.delivered_at
        ? format(new Date(order.delivered_at), "yyyy-MM-dd HH:mm")
        : "",
    };
  });

  exportToCSV(formattedData || [], "orders");
  return formattedData?.length || 0;
};

export const exportOrderItems = async () => {
  const { data: orders, error } = await supabase
    .from("orders")
    .select("order_number, order_items(*)")
    .order("created_at", { ascending: false });

  if (error) throw error;

  const formattedData: Record<string, any>[] = [];
  
  orders?.forEach((order) => {
    order.order_items?.forEach((item: any) => {
      formattedData.push({
        order_number: order.order_number,
        product_name: item.product_name,
        product_sku: item.product_sku || "",
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price,
        created_at: format(new Date(item.created_at), "yyyy-MM-dd HH:mm"),
      });
    });
  });

  exportToCSV(formattedData, "order_items");
  return formattedData.length;
};

export const exportProducts = async () => {
  const { data: products, error } = await supabase
    .from("products")
    .select("*, category:categories(name)")
    .order("created_at", { ascending: false });

  if (error) throw error;

  const formattedData = products?.map((product) => ({
    name: product.name,
    slug: product.slug,
    sku: product.sku || "",
    brand: product.brand || "",
    category: (product.category as any)?.name || "",
    price: product.price,
    compare_at_price: product.compare_at_price || "",
    cost_price: "",
    stock_quantity: product.stock_quantity,
    low_stock_threshold: product.low_stock_threshold,
    is_active: product.is_active ? "Yes" : "No",
    is_featured: product.is_featured ? "Yes" : "No",
    short_description: product.short_description || "",
    description: product.description || "",
    weight: product.weight || "",
    dimensions: product.dimensions || "",
    created_at: format(new Date(product.created_at), "yyyy-MM-dd HH:mm"),
  }));

  exportToCSV(formattedData || [], "products");
  return formattedData?.length || 0;
};

export const exportMasterReport = async (from: Date, to: Date, statuses?: string[]) => {
  const fromIso = new Date(from.getFullYear(), from.getMonth(), from.getDate(), 0, 0, 0).toISOString();
  const toIso = new Date(to.getFullYear(), to.getMonth(), to.getDate(), 23, 59, 59, 999).toISOString();

  let query = supabase
    .from("orders")
    .select("*, order_items(*)")
    .gte("created_at", fromIso)
    .lte("created_at", toIso)
    .order("created_at", { ascending: false });

  if (statuses && statuses.length > 0) {
    query = query.in("status", statuses as any);
  }

  const { data: orders, error } = await query;

  if (error) throw error;


  const userIds = Array.from(
    new Set((orders || []).map((o: any) => o.user_id).filter(Boolean))
  ) as string[];
  let profilesByUser = new Map<string, any>();
  if (userIds.length > 0) {
    const { data: profiles } = await supabase
      .from("profiles")
      .select("user_id, full_name, email, phone")
      .in("user_id", userIds);
    profilesByUser = new Map((profiles || []).map((p: any) => [p.user_id, p]));
  }

  const rows: Record<string, any>[] = [];

  orders?.forEach((order: any) => {
    const addr = (order.shipping_address || {}) as Record<string, any>;
    const profile = (order.user_id && profilesByUser.get(order.user_id)) || {};
    const customer_name = profile.full_name || addr.full_name || "";
    const customer_email = profile.email || order.guest_email || "";
    const customer_phone = profile.phone || addr.phone || "";
    const shipping_address = [
      addr.address_line1,
      addr.address_line2,
      addr.city,
      addr.state,
      addr.postal_code,
      addr.country,
    ]
      .filter((p) => p && String(p).trim().length > 0)
      .join(", ");

    const items = order.order_items?.length ? order.order_items : [null];
    items.forEach((item: any) => {
      rows.push({
        order_number: order.order_number,
        order_date: format(new Date(order.created_at), "yyyy-MM-dd HH:mm"),
        order_status: order.status,
        payment_status: order.payment_status,
        payment_method: order.payment_method || "",
        customer_name,
        customer_email,
        customer_phone,
        shipping_address,
        product_name: item?.product_name || "",
        product_sku: item?.product_sku || "",
        quantity: item?.quantity ?? "",
        unit_price: item?.unit_price ?? "",
        line_total: item?.total_price ?? "",
        order_subtotal: order.subtotal,
        order_shipping: order.shipping_amount,
        order_tax: order.tax_amount,
        order_discount: order.discount_amount,
        order_total: order.total,
        notes: order.notes || "",
      });
    });
  });

  exportToCSV(rows, "master_export");
  return rows.length;
};

export const exportRepeatCustomers = async (
  from: Date,
  to: Date,
  minOrders: number
) => {
  const fromIso = new Date(from.getFullYear(), from.getMonth(), from.getDate(), 0, 0, 0).toISOString();
  const toIso = new Date(to.getFullYear(), to.getMonth(), to.getDate(), 23, 59, 59, 999).toISOString();

  const { data: orders, error } = await supabase
    .from("orders")
    .select("user_id, guest_email, order_number, total, shipping_address, created_at")
    .gte("created_at", fromIso)
    .lte("created_at", toIso)
    .order("created_at", { ascending: false });

  if (error) throw error;

  type Agg = {
    key: string;
    user_id: string | null;
    email: string;
    name: string;
    phone: string;
    order_numbers: string[];
    total_spent: number;
    first_order_at: Date;
    last_order_at: Date;
  };

  const groups = new Map<string, Agg>();
  (orders || []).forEach((o: any) => {
    const email = (o.guest_email || "").toLowerCase();
    const key = o.user_id || (email ? `email:${email}` : null);
    if (!key) return;
    const addr = (o.shipping_address || {}) as Record<string, any>;
    const created = new Date(o.created_at);
    const existing = groups.get(key);
    if (existing) {
      existing.order_numbers.push(o.order_number);
      existing.total_spent += Number(o.total) || 0;
      if (created < existing.first_order_at) existing.first_order_at = created;
      if (created > existing.last_order_at) existing.last_order_at = created;
      if (!existing.name && addr.full_name) existing.name = addr.full_name;
      if (!existing.phone && addr.phone) existing.phone = addr.phone;
      if (!existing.email && o.guest_email) existing.email = o.guest_email;
    } else {
      groups.set(key, {
        key,
        user_id: o.user_id || null,
        email: o.guest_email || "",
        name: addr.full_name || "",
        phone: addr.phone || "",
        order_numbers: [o.order_number],
        total_spent: Number(o.total) || 0,
        first_order_at: created,
        last_order_at: created,
      });
    }
  });

  const repeat = Array.from(groups.values()).filter(
    (g) => g.order_numbers.length >= minOrders
  );

  const userIds = repeat.map((r) => r.user_id).filter(Boolean) as string[];
  if (userIds.length > 0) {
    const { data: profiles } = await supabase
      .from("profiles")
      .select("user_id, full_name, email, phone")
      .in("user_id", userIds);
    const byUser = new Map((profiles || []).map((p: any) => [p.user_id, p]));
    repeat.forEach((r) => {
      if (!r.user_id) return;
      const p = byUser.get(r.user_id);
      if (p) {
        r.name = p.full_name || r.name;
        r.email = p.email || r.email;
        r.phone = p.phone || r.phone;
      }
    });
  }

  repeat.sort((a, b) => b.order_numbers.length - a.order_numbers.length);

  const rows = repeat.map((r) => ({
    name: r.name,
    email: r.email,
    phone: r.phone,
    customer_type: r.user_id ? "registered" : "guest",
    total_orders: r.order_numbers.length,
    total_spent: r.total_spent.toFixed(2),
    first_order_at: format(r.first_order_at, "yyyy-MM-dd HH:mm"),
    last_order_at: format(r.last_order_at, "yyyy-MM-dd HH:mm"),
    order_numbers: r.order_numbers.join(" | "),
  }));

  exportToCSV(rows, "repeat_customers");
  return rows.length;
};




export const exportInventoryLogs = async () => {
  const { data: logs, error } = await supabase
    .from("inventory_logs")
    .select("*, product:products(name, sku)")
    .order("created_at", { ascending: false });

  if (error) throw error;

  const formattedData = logs?.map((log) => ({
    product_name: (log.product as any)?.name || "",
    product_sku: (log.product as any)?.sku || "",
    previous_quantity: log.previous_quantity,
    new_quantity: log.new_quantity,
    change: log.new_quantity - log.previous_quantity,
    change_type: log.change_type,
    notes: log.notes || "",
    created_at: format(new Date(log.created_at), "yyyy-MM-dd HH:mm"),
  }));

  exportToCSV(formattedData || [], "inventory_logs");
  return formattedData?.length || 0;
};
