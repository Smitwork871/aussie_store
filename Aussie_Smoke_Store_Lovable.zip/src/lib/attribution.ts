// Capture landing page + recovery token early so we can attribute orders later.
// Runs at App mount (imported once).
if (typeof window !== 'undefined') {
  try {
    if (!sessionStorage.getItem('landing_page')) {
      sessionStorage.setItem('landing_page', window.location.pathname + window.location.search);
    }
    const url = new URL(window.location.href);
    const token = url.searchParams.get('recovery');
    if (token) {
      sessionStorage.setItem('recovery_token', token);
    }
  } catch {
    // ignore
  }
}

export {};
