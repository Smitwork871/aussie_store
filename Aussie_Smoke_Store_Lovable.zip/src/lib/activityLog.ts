import { supabase } from "@/integrations/supabase/client";

export interface ActivityLogInput {
  actionType: string;
  description: string;
  refType?: "order" | "product" | "customer" | null;
  refId?: string | null;
  refLabel?: string | null;
  metadata?: Record<string, unknown>;
}

/**
 * Fire-and-forget audit log entry. Never throws and never blocks the caller —
 * most actions are already logged automatically by database triggers, this is
 * for things the database cannot see (logins, bulk run summaries, etc).
 */
export function logActivity(input: ActivityLogInput): void {
  void (async () => {
    try {
      await supabase.rpc("log_activity", {
        p_action_type: input.actionType,
        p_description: input.description,
        p_ref_type: input.refType ?? null,
        p_ref_id: input.refId ?? null,
        p_ref_label: input.refLabel ?? null,
        p_metadata: (input.metadata ?? {}) as never,
      });
    } catch {
      // Audit logging must never break an admin action
    }
  })();
}

/** Awaitable variant for cases where the session is about to end (e.g. sign out). */
export async function logActivityAwait(input: ActivityLogInput): Promise<void> {
  try {
    await supabase.rpc("log_activity", {
      p_action_type: input.actionType,
      p_description: input.description,
      p_ref_type: input.refType ?? null,
      p_ref_id: input.refId ?? null,
      p_ref_label: input.refLabel ?? null,
      p_metadata: (input.metadata ?? {}) as never,
    });
  } catch {
    // ignore
  }
}
