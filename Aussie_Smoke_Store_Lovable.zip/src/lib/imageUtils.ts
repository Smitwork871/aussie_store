/**
 * Optimizes Supabase Storage image URLs by appending transformation parameters.
 * Reduces payload size via resizing and quality adjustment.
 */

const SUPABASE_STORAGE_HOST = 'supabase.co/storage';

interface ImageOptions {
  width?: number;
  height?: number;
  quality?: number;
  resize?: 'cover' | 'contain' | 'fill';
}

export function optimizeImageUrl(
  url: string | undefined | null,
  options: ImageOptions = {}
): string {
  if (!url) return '/placeholder.svg';
  
  // Only transform Supabase storage URLs
  if (!url.includes(SUPABASE_STORAGE_HOST)) return url;

  const { width, height, quality = 75, resize = 'cover' } = options;

  const params = new URLSearchParams();
  if (width) params.set('width', String(width));
  if (height) params.set('height', String(height));
  params.set('quality', String(quality));
  params.set('resize', resize);
  params.set('format', 'origin');

  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}${params.toString()}`;
}

/** Preset sizes for common use cases */
export const imgSize = {
  /** Product card thumbnail (grid) */
  card: (url?: string | null) =>
    optimizeImageUrl(url, { width: 400, height: 400, quality: 70 }),
  
  /** Product detail main image */
  detail: (url?: string | null) =>
    optimizeImageUrl(url, { width: 800, height: 800, quality: 80 }),
  
  /** Product detail thumbnail strip */
  detailThumb: (url?: string | null) =>
    optimizeImageUrl(url, { width: 100, height: 100, quality: 60 }),

  /** Cart / checkout line item */
  cartItem: (url?: string | null) =>
    optimizeImageUrl(url, { width: 96, height: 96, quality: 65 }),

  /** Admin table thumbnail */
  adminThumb: (url?: string | null) =>
    optimizeImageUrl(url, { width: 80, height: 80, quality: 60 }),

  /** Category card on homepage */
  category: (url?: string | null) =>
    optimizeImageUrl(url, { width: 400, height: 300, quality: 70 }),
} as const;
