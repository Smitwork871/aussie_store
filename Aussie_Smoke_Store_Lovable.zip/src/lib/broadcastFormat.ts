// Helpers to convert between admin-facing plain text and the safe HTML
// that gets stored in `broadcasts.html` and sent by the edge function.

const PLAIN_MARKER = "<!--format:plain-->";
const SRC_OPEN = "<!--src:";
const SRC_CLOSE = "-->";

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function linkify(escaped: string): string {
  // URLs are matched on the already-escaped string, so no HTML injection risk.
  return escaped.replace(
    /(https?:\/\/[^\s<]+[^\s<.,;:!?)"'])/g,
    '<a href="$1" style="color:#5B4CF5;text-decoration:underline;">$1</a>',
  );
}

/** Convert user-entered plain text into safe HTML suitable for email. */
export function plainToHtml(text: string): string {
  const trimmed = (text ?? "").replace(/\r\n/g, "\n").trim();
  if (!trimmed) return "";
  const blocks = trimmed.split(/\n{2,}/);
  const htmlBody = blocks
    .map((block) => {
      const inner = linkify(escapeHtml(block)).replace(/\n/g, "<br/>");
      return `<p style="margin:0 0 12px;">${inner}</p>`;
    })
    .join("\n");
  // Embed the original text (base64-encoded to survive HTML) so we can restore
  // the plain-text editor when the draft is re-opened.
  const encoded =
    typeof btoa === "function"
      ? btoa(unescape(encodeURIComponent(trimmed)))
      : "";
  return `${PLAIN_MARKER}${SRC_OPEN}${encoded}${SRC_CLOSE}\n${htmlBody}`;
}

/** If `html` was produced from plain text, return the original text; else null. */
export function extractPlainSource(html: string): string | null {
  if (!html || !html.startsWith(PLAIN_MARKER)) return null;
  const start = html.indexOf(SRC_OPEN);
  if (start === -1) return null;
  const end = html.indexOf(SRC_CLOSE, start + SRC_OPEN.length);
  if (end === -1) return null;
  const encoded = html.slice(start + SRC_OPEN.length, end);
  try {
    return decodeURIComponent(escape(atob(encoded)));
  } catch {
    return null;
  }
}

export function isPlainAuthored(html: string): boolean {
  return typeof html === "string" && html.startsWith(PLAIN_MARKER);
}
