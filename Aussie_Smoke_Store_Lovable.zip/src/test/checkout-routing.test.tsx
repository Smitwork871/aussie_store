import { render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { vi, test, expect } from 'vitest';
import Checkout from '../pages/Checkout';

const session = vi.hoisted(() => ({ isLoading: true, items: [], subtotal: 0 }));
vi.mock('@/contexts/CartContext', () => ({ useCart: () => session }));
vi.mock('@/contexts/AuthContext', () => ({ useAuth: () => ({ user: null }) }));
vi.mock('@/integrations/supabase/client', () => ({ supabase: {} }));

function checkoutRoute() {
  return <MemoryRouter initialEntries={['/checkout']}><Routes>
    <Route path="/checkout" element={<Checkout />} />
    <Route path="/cart" element={<p>Empty cart</p>} />
  </Routes></MemoryRouter>;
}

test('checkout waits for the saved cart before redirecting an empty cart', async () => {
  const page = render(checkoutRoute());
  expect(screen.queryByText('Empty cart')).toBeNull();
  session.isLoading = false;
  page.rerender(checkoutRoute());
  expect(await screen.findByText('Empty cart')).toBeInTheDocument();
});
