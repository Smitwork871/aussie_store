import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface AgeVerificationContextType {
  isVerified: boolean;
  showModal: boolean;
  verify: () => void;
  decline: () => void;
}

const AgeVerificationContext = createContext<AgeVerificationContextType | undefined>(undefined);

const AGE_VERIFIED_KEY = 'age_verified_session';

export const AgeVerificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, profile, verifyAge } = useAuth();
  const [isVerified, setIsVerified] = useState(false);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    // Skip age verification for search engine bots to prevent content blocking
    const ua = navigator.userAgent.toLowerCase();
    const isBot = /googlebot|bingbot|slurp|duckduckbot|baiduspider|yandexbot|facebot|ia_archiver|crawl|spider|bot/i.test(ua);
    if (isBot) {
      setIsVerified(true);
      setShowModal(false);
      return;
    }

    // Check if user is logged in and age verified
    if (user && profile?.age_verified) {
      setIsVerified(true);
      setShowModal(false);
      return;
    }

    // Check session storage for guest verification
    const sessionVerified = sessionStorage.getItem(AGE_VERIFIED_KEY);
    if (sessionVerified === 'true') {
      setIsVerified(true);
      setShowModal(false);
      return;
    }

    // Show verification modal
    setIsVerified(false);
    setShowModal(true);
  }, [user, profile]);

  const verify = async () => {
    if (user) {
      await verifyAge();
    } else {
      sessionStorage.setItem(AGE_VERIFIED_KEY, 'true');
    }
    setIsVerified(true);
    setShowModal(false);
  };

  const decline = () => {
    // Redirect to a safe page or show message
    window.location.href = 'https://www.google.com';
  };

  return (
    <AgeVerificationContext.Provider
      value={{
        isVerified,
        showModal,
        verify,
        decline,
      }}
    >
      {children}
    </AgeVerificationContext.Provider>
  );
};

export const useAgeVerification = () => {
  const context = useContext(AgeVerificationContext);
  if (context === undefined) {
    throw new Error('useAgeVerification must be used within an AgeVerificationProvider');
  }
  return context;
};
