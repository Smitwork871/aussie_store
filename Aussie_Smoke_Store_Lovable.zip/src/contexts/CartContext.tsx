import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';
import { Product } from '@/types/database';
import { toast } from 'sonner';

export interface CartItemWithProduct {
  id: string;
  product_id: string;
  quantity: number;
  product: Product;
}

interface CartContextType {
  items: CartItemWithProduct[];
  isLoading: boolean;
  addToCart: (productId: string, quantity?: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  itemCount: number;
  subtotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

// Local storage cart for guests
const GUEST_CART_KEY = 'guest_cart';

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItemWithProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const prevUserIdRef = useRef<string | null>(null);

  const fetchCart = useCallback(async () => {
    setIsLoading(true);

    if (user) {
      // Merge guest cart into user cart on first sign-in
      const guestCartRaw = localStorage.getItem(GUEST_CART_KEY);
      if (guestCartRaw) {
        try {
          const guestCart: Array<{ product_id: string; quantity: number }> = JSON.parse(guestCartRaw);
          if (guestCart.length > 0) {
            const { data: existing } = await supabase
              .from('cart_items')
              .select('product_id, quantity')
              .eq('user_id', user.id);
            const existingMap = new Map((existing || []).map((r: any) => [r.product_id, r.quantity]));
            for (const g of guestCart) {
              const currentQty = existingMap.get(g.product_id) || 0;
              const newQty = currentQty + g.quantity;
              if (currentQty > 0) {
                await supabase
                  .from('cart_items')
                  .update({ quantity: newQty })
                  .eq('user_id', user.id)
                  .eq('product_id', g.product_id);
              } else {
                await supabase
                  .from('cart_items')
                  .insert({ user_id: user.id, product_id: g.product_id, quantity: g.quantity });
              }
            }
          }
        } catch (e) {
          console.error('Failed to merge guest cart:', e);
        }
        localStorage.removeItem(GUEST_CART_KEY);
      }

      const { data, error } = await supabase
        .from('cart_items')
        .select('id, product_id, quantity')
        .eq('user_id', user.id);

      if (error) {
        console.error('Error fetching cart:', error);
        setIsLoading(false);
        return;
      }

      if (data && data.length > 0) {
        const productIds = data.map((r) => r.product_id);
        const { data: products, error: prodErr } = await supabase
          .from('public_products')
          .select('*')
          .in('id', productIds);
        if (prodErr) {
          console.error('Error fetching cart products:', prodErr);
        } else if (products) {
          const cartItems = data
            .map((item) => {
              const product = products.find((p: any) => p.id === item.product_id);
              return product
                ? { id: item.id, product_id: item.product_id, quantity: item.quantity, product: product as unknown as Product }
                : null;
            })
            .filter((x): x is CartItemWithProduct => x !== null);
          setItems(cartItems);
        }
      } else {
        setItems([]);
      }
    } else {
      // Load guest cart from localStorage
      const guestCart = localStorage.getItem(GUEST_CART_KEY);
      if (guestCart) {
        const parsed = JSON.parse(guestCart);
        // Fetch product details for guest cart
        const productIds = parsed.map((item: any) => item.product_id);
        if (productIds.length > 0) {
          const { data: products } = await supabase
            .from('public_products')
            .select('*')
            .in('id', productIds);
          
          if (products) {
            const cartItems = parsed.map((item: any) => ({
              id: item.id,
              product_id: item.product_id,
              quantity: item.quantity,
              product: products.find((p: any) => p.id === item.product_id) as Product,
            })).filter((item: CartItemWithProduct) => item.product);
            setItems(cartItems);
          }
        } else {
          setItems([]);
        }
      } else {
        setItems([]);
      }
    }

    setIsLoading(false);
  }, [user]);

  useEffect(() => {
    prevUserIdRef.current = user?.id ?? null;
    fetchCart();
  }, [fetchCart, user]);

  const addToCart = async (productId: string, quantity = 1) => {
    if (user) {
      const existingItem = items.find(item => item.product_id === productId);
      
      if (existingItem) {
        await updateQuantity(productId, existingItem.quantity + quantity);
      } else {
        const { error } = await supabase
          .from('cart_items')
          .insert({
            user_id: user.id,
            product_id: productId,
            quantity,
          });
        
        if (error) {
          toast.error('Failed to add to cart');
          return;
        }
        
        await fetchCart();
      }
    } else {
      // Guest cart
      const guestCart = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
      const existingIndex = guestCart.findIndex((item: any) => item.product_id === productId);
      
      if (existingIndex > -1) {
        guestCart[existingIndex].quantity += quantity;
      } else {
        guestCart.push({
          id: crypto.randomUUID(),
          product_id: productId,
          quantity,
        });
      }
      
      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(guestCart));
      await fetchCart();
    }
    
    toast.success('Added to cart');
  };

  const removeFromCart = async (productId: string) => {
    if (user) {
      await supabase
        .from('cart_items')
        .delete()
        .eq('user_id', user.id)
        .eq('product_id', productId);
    } else {
      const guestCart = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
      const filtered = guestCart.filter((item: any) => item.product_id !== productId);
      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(filtered));
    }
    
    await fetchCart();
    toast.success('Removed from cart');
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    if (quantity < 1) {
      await removeFromCart(productId);
      return;
    }
    
    if (user) {
      await supabase
        .from('cart_items')
        .update({ quantity })
        .eq('user_id', user.id)
        .eq('product_id', productId);
    } else {
      const guestCart = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
      const index = guestCart.findIndex((item: any) => item.product_id === productId);
      if (index > -1) {
        guestCart[index].quantity = quantity;
        localStorage.setItem(GUEST_CART_KEY, JSON.stringify(guestCart));
      }
    }
    
    await fetchCart();
  };

  const clearCart = async () => {
    if (user) {
      await supabase
        .from('cart_items')
        .delete()
        .eq('user_id', user.id);
    } else {
      localStorage.removeItem(GUEST_CART_KEY);
    }
    
    setItems([]);
  };

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  return (
    <CartContext.Provider
      value={{
        items,
        isLoading,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        itemCount,
        subtotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
