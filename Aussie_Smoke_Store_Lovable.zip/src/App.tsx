import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { CartProvider } from "@/contexts/CartContext";
import { WishlistProvider } from "@/contexts/WishlistContext";
import { AgeVerificationProvider } from "@/contexts/AgeVerificationContext";
import { lazy, Suspense } from "react";
import "@/lib/attribution";
import Index from "./pages/Index";
import MaintenancePage from "./components/MaintenancePage";
import AdminAccessUnlock, { AdminAccessLock } from "./pages/AdminAccessUnlock";

const MAINTENANCE_MODE = false;
const MAINTENANCE_BYPASS_KEY = "maintenance_bypass";
const hasMaintenanceBypass = () => {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem(MAINTENANCE_BYPASS_KEY) === "true";
  } catch {
    return false;
  }
};

// Lazy load all non-homepage routes for code splitting
const Wishlist = lazy(() => import("./pages/Wishlist"));
const Products = lazy(() => import("./pages/Products"));
const ProductDetail = lazy(() => import("./pages/ProductDetail"));
const Cart = lazy(() => import("./pages/Cart"));
const Checkout = lazy(() => import("./pages/Checkout"));
const OrderConfirmation = lazy(() => import("./pages/OrderConfirmation"));
const Login = lazy(() => import("./pages/Login"));
const Register = lazy(() => import("./pages/Register"));
const ForgotPassword = lazy(() => import("./pages/ForgotPassword"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const NotFound = lazy(() => import("./pages/NotFound"));
const Profile = lazy(() => import("./pages/Profile"));
const Categories = lazy(() => import("./pages/Categories"));
const About = lazy(() => import("./pages/About"));
const Contact = lazy(() => import("./pages/Contact"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Terms = lazy(() => import("./pages/Terms"));
const AdminDashboard = lazy(() => import("./pages/admin/Dashboard"));
const AdminProducts = lazy(() => import("./pages/admin/Products"));
const AdminCategories = lazy(() => import("./pages/admin/Categories"));
const AdminCustomers = lazy(() => import("./pages/admin/Customers"));
const AdminCoupons = lazy(() => import("./pages/admin/Coupons"));
const AdminOrders = lazy(() => import("./pages/admin/Orders"));
const AdminInventory = lazy(() => import("./pages/admin/Inventory"));
const AdminAnalytics = lazy(() => import("./pages/admin/Analytics"));
const AdminSettings = lazy(() => import("./pages/admin/Settings"));
const AdminPrintOrders = lazy(() => import("./pages/admin/PrintOrders"));
const AdminBulkOperations = lazy(() => import("./pages/admin/BulkOperations"));
const AdminBroadcasts = lazy(() => import("./pages/admin/Broadcasts"));
const AdminBroadcastHistory = lazy(() => import("./pages/admin/BroadcastHistory"));
const AdminBroadcastDetail = lazy(() => import("./pages/admin/BroadcastDetail"));
const AdminActivityLogs = lazy(() => import("./pages/admin/ActivityLogs"));
const Unsubscribe = lazy(() => import("./pages/Unsubscribe"));
const CheapSmokesOnline = lazy(() => import("./pages/CheapSmokesOnline"));
const CheapCigarettesOnline = lazy(() => import("./pages/CheapCigarettesOnline"));
const CheapVapesOnline = lazy(() => import("./pages/CheapVapesOnline"));
const BuyCigarettesOnlineAustralia = lazy(() => import("./pages/BuyCigarettesOnlineAustralia"));
const CheapTobaccoOnline = lazy(() => import("./pages/CheapTobaccoOnline"));
const CheapRollingTobaccoOnline = lazy(() => import("./pages/CheapRollingTobaccoOnline"));
const BestCigarettesAustralia = lazy(() => import("./pages/BestCigarettesAustralia"));
const DiscountTobaccoOnline = lazy(() => import("./pages/DiscountTobaccoOnline"));
const BuyCheapSmokesAustralia = lazy(() => import("./pages/BuyCheapSmokesAustralia"));
const OnlineTobaccoShopAustralia = lazy(() => import("./pages/OnlineTobaccoShopAustralia"));
const NicotinePouchesAustralia = lazy(() => import("./pages/NicotinePouchesAustralia"));
const MarlboroCigarettesAustralia = lazy(() => import("./pages/MarlboroCigarettesAustralia"));
const TobaccoDeliveryAustralia = lazy(() => import("./pages/TobaccoDeliveryAustralia"));
const CigarettesNearMe = lazy(() => import("./pages/CigarettesNearMe"));
const DutyFreeCigarettesAustralia = lazy(() => import("./pages/DutyFreeCigarettesAustralia"));
const CheapSmokesSydney = lazy(() => import("./pages/city/CheapSmokesSydney"));
const CheapSmokesMelbourne = lazy(() => import("./pages/city/CheapSmokesMelbourne"));
const CheapSmokesBrisbane = lazy(() => import("./pages/city/CheapSmokesBrisbane"));
const CheapSmokesPerth = lazy(() => import("./pages/city/CheapSmokesPerth"));
const CheapSmokesAdelaide = lazy(() => import("./pages/city/CheapSmokesAdelaide"));
const CheapSmokesCanberra = lazy(() => import("./pages/city/CheapSmokesCanberra"));
const CheapSmokesHobart = lazy(() => import("./pages/city/CheapSmokesHobart"));
const CheapSmokesDarwin = lazy(() => import("./pages/city/CheapSmokesDarwin"));
const CheapSmokesGoldCoast = lazy(() => import("./pages/city/CheapSmokesGoldCoast"));
const CheapSmokesNewcastle = lazy(() => import("./pages/city/CheapSmokesNewcastle"));
const CigarettePriceGuide = lazy(() => import("./pages/guides/CigarettePriceGuide"));
const RollingTobaccoGuide = lazy(() => import("./pages/guides/RollingTobaccoGuide"));
const VapeGuide = lazy(() => import("./pages/guides/VapeGuide"));
const TobaccoTaxGuide = lazy(() => import("./pages/guides/TobaccoTaxGuide"));
const TobaccoLawsAustralia = lazy(() => import("./pages/guides/TobaccoLawsAustralia"));
const BulkTobaccoPriceGuide = lazy(() => import("./pages/guides/BulkTobaccoPriceGuide"));
const ChopChopTobaccoGuide = lazy(() => import("./pages/guides/ChopChopTobaccoGuide"));
const ManchesterCigarettesReview = lazy(() => import("./pages/guides/ManchesterCigarettesReview"));
const SupermarketPriceComparison = lazy(() => import("./pages/SupermarketPriceComparison"));
const CheapDartsOnline = lazy(() => import("./pages/CheapDartsOnline"));
const CheapDurriesOnline = lazy(() => import("./pages/CheapDurriesOnline"));
const CheapestCigarettesAustralia = lazy(() => import("./pages/CheapestCigarettesAustralia"));
const OnlineSmokeShopAustralia = lazy(() => import("./pages/OnlineSmokeShopAustralia"));
const BulkCigarettesAustralia = lazy(() => import("./pages/BulkCigarettesAustralia"));
const OrderCigarettesOnlineAustralia = lazy(() => import("./pages/OrderCigarettesOnlineAustralia"));
const ManchesterCigarettesAustralia = lazy(() => import("./pages/brands/ManchesterCigarettesAustralia"));
const BensonHedgesCigarettesAustralia = lazy(() => import("./pages/brands/BensonHedgesCigarettesAustralia"));
const UwellVapesAustralia = lazy(() => import("./pages/brands/UwellVapesAustralia"));
const AlibarbarVapesAustralia = lazy(() => import("./pages/brands/AlibarbarVapesAustralia"));
const DoubleHappinessCigarettesAustralia = lazy(() => import("./pages/brands/DoubleHappinessCigarettesAustralia"));
const ManchesterDoubleDriveAustralia = lazy(() => import("./pages/brands/ManchesterDoubleDriveAustralia"));
const ManchesterRoyalRedCigarettesAustralia = lazy(() => import("./pages/brands/ManchesterRoyalRedCigarettesAustralia"));
const ManchesterSapphireBlueAustralia = lazy(() => import("./pages/brands/ManchesterSapphireBlueAustralia"));
const MarlboroIceBlastAustralia = lazy(() => import("./pages/brands/MarlboroIceBlastAustralia"));
const MarlboroRedCigarettesAustralia = lazy(() => import("./pages/brands/MarlboroRedCigarettesAustralia"));
const MacCoolBlastCigarettesAustralia = lazy(() => import("./pages/brands/MacCoolBlastCigarettesAustralia"));
const EuroBlueCigarettesAustralia = lazy(() => import("./pages/brands/EuroBlueCigarettesAustralia"));
const EsseMentholCigarettesAustralia = lazy(() => import("./pages/brands/EsseMentholCigarettesAustralia"));
const BensonsHedgesGoldCigarettesAustralia = lazy(() => import("./pages/brands/BensonsHedgesGoldCigarettesAustralia"));
const DunhillBlueCigarettesAustralia = lazy(() => import("./pages/brands/DunhillBlueCigarettesAustralia"));
const CheapSmokesNSW = lazy(() => import("./pages/state/CheapSmokesNSW"));
const CheapSmokesVIC = lazy(() => import("./pages/state/CheapSmokesVIC"));
const CheapSmokesQLD = lazy(() => import("./pages/state/CheapSmokesQLD"));
const CheapSmokesWA = lazy(() => import("./pages/state/CheapSmokesWA"));
const CheapSmokesSA = lazy(() => import("./pages/state/CheapSmokesSA"));
const Deals = lazy(() => import("./pages/Deals"));
const AlternativeTo = lazy(() => import("./pages/AlternativeTo"));
const CityLanding = lazy(() => import("./pages/locations/CityLanding"));

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <CartProvider>
          <WishlistProvider>
            <AgeVerificationProvider>
              <Toaster />
              <Sonner />
              <BrowserRouter>
                <Suspense fallback={<div className="min-h-screen bg-background" />}>
                  <Routes>
                    <Route path="/admin-access-8f3a2c" element={<AdminAccessUnlock />} />
                    <Route path="/admin-access-lock" element={<AdminAccessLock />} />
                    {MAINTENANCE_MODE && !hasMaintenanceBypass() ? (
                      <Route path="*" element={<MaintenancePage />} />
                    ) : (
                      <>
                    <Route path="/" element={<Index />} />
                    <Route path="/products" element={<Products />} />
                    <Route path="/products/:slug" element={<ProductDetail />} />
                    <Route path="/locations/:citySlug" element={<CityLanding />} />
                    <Route path="/locations/:citySlug/:category" element={<CityLanding />} />
                    <Route path="/cart" element={<Cart />} />
                    <Route path="/checkout" element={<Checkout />} />
                    <Route path="/order-confirmation/:orderId" element={<OrderConfirmation />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/forgot-password" element={<ForgotPassword />} />
                    <Route path="/reset-password" element={<ResetPassword />} />
                    <Route path="/profile" element={<Profile />} />
                    <Route path="/wishlist" element={<Wishlist />} />
                    <Route path="/categories" element={<Categories />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/privacy" element={<Privacy />} />
                    <Route path="/terms" element={<Terms />} />
                    <Route path="/cheap-smokes-online" element={<CheapSmokesOnline />} />
                    <Route path="/cheap-cigarettes-online" element={<CheapCigarettesOnline />} />
                    <Route path="/cheap-vapes-online" element={<CheapVapesOnline />} />
                    <Route path="/buy-cigarettes-online-australia" element={<BuyCigarettesOnlineAustralia />} />
                    <Route path="/cheap-tobacco-online" element={<CheapTobaccoOnline />} />
                    <Route path="/cheap-rolling-tobacco-online" element={<CheapRollingTobaccoOnline />} />
                    <Route path="/best-cigarettes-australia" element={<BestCigarettesAustralia />} />
                    <Route path="/discount-tobacco-online" element={<DiscountTobaccoOnline />} />
                    <Route path="/buy-cheap-smokes-australia" element={<BuyCheapSmokesAustralia />} />
                    <Route path="/online-tobacco-shop-australia" element={<OnlineTobaccoShopAustralia />} />
                    <Route path="/nicotine-pouches-australia" element={<NicotinePouchesAustralia />} />
                    <Route path="/marlboro-cigarettes-australia" element={<MarlboroCigarettesAustralia />} />
                    <Route path="/tobacco-delivery-australia" element={<TobaccoDeliveryAustralia />} />
                    <Route path="/cigarettes-near-me" element={<CigarettesNearMe />} />
                    <Route path="/duty-free-cigarettes-australia" element={<DutyFreeCigarettesAustralia />} />
                    <Route path="/cheap-smokes-sydney" element={<CheapSmokesSydney />} />
                    <Route path="/cheap-smokes-melbourne" element={<CheapSmokesMelbourne />} />
                    <Route path="/cheap-smokes-brisbane" element={<CheapSmokesBrisbane />} />
                    <Route path="/cheap-smokes-perth" element={<CheapSmokesPerth />} />
                    <Route path="/cheap-smokes-adelaide" element={<CheapSmokesAdelaide />} />
                    <Route path="/cigarette-prices-australia" element={<CigarettePriceGuide />} />
                    <Route path="/rolling-tobacco-guide-australia" element={<RollingTobaccoGuide />} />
                    <Route path="/vape-guide-australia" element={<VapeGuide />} />
                    <Route path="/australian-tobacco-tax-guide" element={<TobaccoTaxGuide />} />
                    <Route path="/tobacco-laws-australia" element={<TobaccoLawsAustralia />} />
                    <Route path="/chop-chop-tobacco-australia-guide" element={<ChopChopTobaccoGuide />} />
                    <Route path="/guides/manchester-cigarettes-review" element={<ManchesterCigarettesReview />} />
      <Route path="/1kg-tobacco-price-guide-australia" element={<BulkTobaccoPriceGuide />} />
      <Route path="/tobacco-price-comparison-supermarkets" element={<SupermarketPriceComparison />} />
                    <Route path="/cheap-smokes-canberra" element={<CheapSmokesCanberra />} />
                    <Route path="/cheap-smokes-hobart" element={<CheapSmokesHobart />} />
                    <Route path="/cheap-smokes-darwin" element={<CheapSmokesDarwin />} />
                    <Route path="/cheap-smokes-gold-coast" element={<CheapSmokesGoldCoast />} />
                    <Route path="/cheap-smokes-newcastle" element={<CheapSmokesNewcastle />} />
                    <Route path="/cheap-darts-online" element={<CheapDartsOnline />} />
                    <Route path="/cheap-durries-online" element={<CheapDurriesOnline />} />
                    <Route path="/cheapest-cigarettes-australia" element={<CheapestCigarettesAustralia />} />
                    <Route path="/online-smoke-shop-australia" element={<OnlineSmokeShopAustralia />} />
                    <Route path="/bulk-cigarettes-australia" element={<BulkCigarettesAustralia />} />
                    <Route path="/order-cigarettes-online-australia" element={<OrderCigarettesOnlineAustralia />} />
                    <Route path="/manchester-cigarettes-australia" element={<ManchesterCigarettesAustralia />} />
                    <Route path="/benson-hedges-cigarettes-australia" element={<BensonHedgesCigarettesAustralia />} />
                    <Route path="/uwell-vapes-australia" element={<UwellVapesAustralia />} />
                    <Route path="/alibarbar-vapes-australia" element={<AlibarbarVapesAustralia />} />
                    <Route path="/double-happiness-cigarettes-australia" element={<DoubleHappinessCigarettesAustralia />} />
                    <Route path="/manchester-double-drive-australia" element={<ManchesterDoubleDriveAustralia />} />
                    <Route path="/manchester-royal-red-cigarettes-australia" element={<ManchesterRoyalRedCigarettesAustralia />} />
                    <Route path="/manchester-sapphire-blue-australia" element={<ManchesterSapphireBlueAustralia />} />
                    <Route path="/marlboro-ice-blast-australia" element={<MarlboroIceBlastAustralia />} />
                    <Route path="/marlboro-red-cigarettes-australia" element={<MarlboroRedCigarettesAustralia />} />
                    <Route path="/mac-cool-blast-cigarettes-australia" element={<MacCoolBlastCigarettesAustralia />} />
                    <Route path="/euro-blue-cigarettes-australia" element={<EuroBlueCigarettesAustralia />} />
                    <Route path="/esse-menthol-cigarettes-australia" element={<EsseMentholCigarettesAustralia />} />
                    <Route path="/bensons-hedges-gold-cigarettes-australia" element={<BensonsHedgesGoldCigarettesAustralia />} />
                    <Route path="/dunhill-blue-cigarettes-australia" element={<DunhillBlueCigarettesAustralia />} />
                    <Route path="/cheap-smokes-nsw" element={<CheapSmokesNSW />} />
                    <Route path="/cheap-smokes-vic" element={<CheapSmokesVIC />} />
                    <Route path="/cheap-smokes-qld" element={<CheapSmokesQLD />} />
                    <Route path="/cheap-smokes-wa" element={<CheapSmokesWA />} />
                    <Route path="/cheap-smokes-sa" element={<CheapSmokesSA />} />
                    <Route path="/deals" element={<Deals />} />
                    <Route path="/alternatives/:competitor" element={<AlternativeTo />} />
                    <Route path="/admin" element={<AdminDashboard />} />
                    <Route path="/admin/products" element={<AdminProducts />} />
                    <Route path="/admin/categories" element={<AdminCategories />} />
                    <Route path="/admin/customers" element={<AdminCustomers />} />
                    <Route path="/admin/coupons" element={<AdminCoupons />} />
                    <Route path="/admin/orders" element={<AdminOrders />} />
                    <Route path="/admin/inventory" element={<AdminInventory />} />
                    <Route path="/admin/analytics" element={<AdminAnalytics />} />
                    <Route path="/admin/settings" element={<AdminSettings />} />
                  <Route path="/admin/bulk-operations" element={<AdminBulkOperations />} />
                  <Route path="/admin/bulk-operations/:toolSlug" element={<AdminBulkOperations />} />
                   <Route path="/admin/bulk-verification" element={<Navigate to="/admin/bulk-operations" replace />} />
                   <Route path="/admin/print-orders" element={<AdminPrintOrders />} />
                   <Route path="/admin/broadcasts" element={<AdminBroadcasts />} />
                   <Route path="/admin/broadcasts/history" element={<AdminBroadcastHistory />} />
                   <Route path="/admin/broadcasts/:id" element={<AdminBroadcastDetail />} />
                   <Route path="/admin/activity-logs" element={<AdminActivityLogs />} />
                    <Route path="/unsubscribe" element={<Unsubscribe />} />
                    <Route path="*" element={<NotFound />} />
                      </>
                    )}
                  </Routes>
                </Suspense>
              </BrowserRouter>
            </AgeVerificationProvider>
          </WishlistProvider>
        </CartProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
