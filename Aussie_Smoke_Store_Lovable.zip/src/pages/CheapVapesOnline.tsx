import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap vapes online in Australia?', answer: 'Aussie Smoke Store offers a huge range of cheap vapes online including U Well, Alibabar, Iget and Kuz brands. We deliver Australia-wide with free shipping on orders over A$50.' },
  { question: 'What vape brands do you stock?', answer: 'We stock popular vape brands including U Well (7K and 12K puffs), Alibabar (9K and 12K Ice Adjust), Iget, and Kuz disposable vapes.' },
  { question: 'Are your vapes authentic?', answer: 'Yes, all vapes sold on Aussie Smoke Store are 100% authentic products sourced from authorised distributors.' },
  { question: 'How long does vape delivery take?', answer: 'Orders are processed within 1-3 business days. Delivery takes 3-7 business days depending on your location in Australia. Free shipping on orders over A$50.' },
];

const CheapVapesOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data: cats } = await supabase
        .from('categories')
        .select('id')
        .ilike('name', '%vape%')
        .eq('is_active', true);

      let query = supabase.from('public_products').select('*').eq('is_active', true);

      if (cats && cats.length > 0) {
        query = query.in('category_id', cats.map(c => c.id));
      }

      const { data } = await query.order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Vapes Online Australia — Buy Vapes at Best Prices"
        description="Buy cheap vapes online in Australia. U Well, Alibabar, Iget, Kuz disposable vapes at the lowest prices. Free shipping over A$50. Shop cheap vapes online at Aussie Smoke Store."
        canonical="/cheap-vapes-online"
        keywords="cheap vapes online, buy vapes online Australia, cheap vapes Australia, disposable vapes online, U Well vape, Alibabar vape, Iget vape, Kuz vape, vapes online Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Vapes Online', url: '/cheap-vapes-online' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Vapes Online Australia
              <span className="text-primary block mt-2">Top Brands, Best Prices</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Shop <strong>cheap vapes online</strong> from Australia's leading brands. U Well, Alibabar, Iget and Kuz at unbeatable prices. <strong>Free shipping over A$50</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products?category=vapes">Shop All Vapes <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-smokes-online">All Cheap Smokes</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Vapes Online in Australia</h2>
            <p>
              Aussie Smoke Store is Australia's best destination for <strong>cheap vapes online</strong>. We stock the most popular disposable vape brands at prices you won't find anywhere else.
            </p>
            <h3>Vape Brands We Carry</h3>
            <ul>
              <li><strong>U Well 7K</strong> — 7,000 puffs disposable vape with premium flavours</li>
              <li><strong>U Well 12K</strong> — 12,000 puffs for extended enjoyment</li>
              <li><strong>Alibabar 9K</strong> — 9,000 puffs with bold flavour profiles</li>
              <li><strong>Alibabar 12K Ice Adjust</strong> — Adjustable ice cooling technology</li>
              <li><strong>Iget</strong> — Popular Australian favourite vape brand</li>
              <li><strong>Kuz</strong> — Premium disposable vapes at competitive prices</li>
            </ul>
            <h3>Australia-Wide Vape Delivery</h3>
            <p>
              We ship <strong>cheap vapes</strong> to all Australian cities and towns. Enjoy <strong>free shipping on orders over A$50</strong> — the best deal for buying vapes online in Australia.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Cheap Smokes Online
            </Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Cheap Cigarettes Online
            </Link>
            <Link to="/products?category=rolling-tobacco" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Rolling Tobacco
            </Link>
            <Link to="/categories" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              All Categories
            </Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheap Vapes — Best Sellers</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions About Cheap Vapes Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapVapesOnline;
