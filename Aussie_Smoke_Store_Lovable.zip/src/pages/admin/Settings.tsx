import { useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  Store,
  Download,
  Users,
  ShoppingCart,
  Package,
  Boxes,
  Loader2,
  FileSpreadsheet,
  CalendarIcon,
  Repeat,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { format, subDays } from "date-fns";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  exportCustomers,
  exportOrders,
  exportOrderItems,
  exportProducts,
  exportInventoryLogs,
  exportMasterReport,
  exportRepeatCustomers,
} from "@/lib/exportUtils";

const ORDER_STATUSES = [
  "pending",
  "confirmed",
  "processing",
  "shipped",
  "delivered",
  "cancelled",
] as const;


const AdminSettings = () => {
  const [exporting, setExporting] = useState<string | null>(null);
  const [masterOpen, setMasterOpen] = useState(false);
  const [repeatOpen, setRepeatOpen] = useState(false);
  const [fromDate, setFromDate] = useState<Date | undefined>(subDays(new Date(), 30));
  const [toDate, setToDate] = useState<Date | undefined>(new Date());
  const [repeatFromDate, setRepeatFromDate] = useState<Date | undefined>(subDays(new Date(), 90));
  const [repeatToDate, setRepeatToDate] = useState<Date | undefined>(new Date());
  const [minOrders, setMinOrders] = useState<number>(2);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);

  const toggleStatus = (status: string) => {
    setSelectedStatuses((prev) =>
      prev.includes(status) ? prev.filter((s) => s !== status) : [...prev, status]
    );
  };


  const handleExport = async (type: string, exportFn: () => Promise<number>) => {
    setExporting(type);
    try {
      const count = await exportFn();
      toast.success(`Exported ${count} ${type} records`);
    } catch (error: any) {
      toast.error(`Failed to export ${type}: ${error.message}`);
    } finally {
      setExporting(null);
    }
  };

  const handleMasterExport = async () => {
    if (!fromDate || !toDate) {
      toast.error("Please select both From and To dates");
      return;
    }
    if (fromDate > toDate) {
      toast.error("From date must be before To date");
      return;
    }
    setExporting("master export");
    try {
      const count = await exportMasterReport(fromDate, toDate, selectedStatuses);
      const suffix = selectedStatuses.length > 0 ? ` (status: ${selectedStatuses.join(", ")})` : "";
      toast.success(`Exported ${count} rows${suffix}`);
      setMasterOpen(false);
      setSelectedStatuses([]);

    } catch (error: any) {
      toast.error(`Failed to export: ${error.message}`);
    } finally {
      setExporting(null);
    }
  };

  const handleRepeatExport = async () => {
    if (!repeatFromDate || !repeatToDate) {
      toast.error("Please select both From and To dates");
      return;
    }
    if (repeatFromDate > repeatToDate) {
      toast.error("From date must be before To date");
      return;
    }
    if (!minOrders || minOrders < 2) {
      toast.error("Minimum orders must be at least 2");
      return;
    }
    setExporting("repeat customers");
    try {
      const count = await exportRepeatCustomers(repeatFromDate, repeatToDate, minOrders);
      if (count === 0) {
        toast.info("No repeat customers found for the selected filters");
      } else {
        toast.success(`Exported ${count} repeat customers`);
      }
      setRepeatOpen(false);
    } catch (error: any) {
      toast.error(`Failed to export: ${error.message}`);
    } finally {
      setExporting(null);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Settings</h1>
          <p className="text-muted-foreground">Manage your store settings</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" />
              Export Data
            </CardTitle>
            <CardDescription>
              Download your store data as CSV files for backup or analysis.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <Button
                variant="outline"
                className="justify-start gap-2 h-auto py-4"
                onClick={() => handleExport("customers", exportCustomers)}
                disabled={exporting !== null}
              >
                {exporting === "customers" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Users className="h-4 w-4" />
                )}
                <div className="text-left">
                  <div className="font-medium">Customers</div>
                  <div className="text-xs text-muted-foreground">Email, name, phone, verification</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start gap-2 h-auto py-4"
                onClick={() => handleExport("orders", exportOrders)}
                disabled={exporting !== null}
              >
                {exporting === "orders" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ShoppingCart className="h-4 w-4" />
                )}
                <div className="text-left">
                  <div className="font-medium">Orders</div>
                  <div className="text-xs text-muted-foreground">Order details, totals, shipping</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start gap-2 h-auto py-4"
                onClick={() => handleExport("order items", exportOrderItems)}
                disabled={exporting !== null}
              >
                {exporting === "order items" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ShoppingCart className="h-4 w-4" />
                )}
                <div className="text-left">
                  <div className="font-medium">Order Items</div>
                  <div className="text-xs text-muted-foreground">Line items with quantities</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start gap-2 h-auto py-4"
                onClick={() => handleExport("products", exportProducts)}
                disabled={exporting !== null}
              >
                {exporting === "products" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Package className="h-4 w-4" />
                )}
                <div className="text-left">
                  <div className="font-medium">Products</div>
                  <div className="text-xs text-muted-foreground">Catalog with prices, stock</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start gap-2 h-auto py-4"
                onClick={() => handleExport("inventory logs", exportInventoryLogs)}
                disabled={exporting !== null}
              >
                {exporting === "inventory logs" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Boxes className="h-4 w-4" />
                )}
                <div className="text-left">
                  <div className="font-medium">Inventory Logs</div>
                  <div className="text-xs text-muted-foreground">Stock change history</div>
                </div>
              </Button>

              <Button
                className="justify-start gap-2 h-auto py-4"
                onClick={() => setMasterOpen(true)}
                disabled={exporting !== null}
              >
                {exporting === "master export" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <FileSpreadsheet className="h-4 w-4" />
                )}
                <div className="text-left">
                  <div className="font-medium">Master Export</div>
                  <div className="text-xs text-muted-foreground">All-in-one order + customer + items</div>
                </div>
              </Button>

              <Button
                variant="secondary"
                className="justify-start gap-2 h-auto py-4"
                onClick={() => setRepeatOpen(true)}
                disabled={exporting !== null}
              >
                {exporting === "repeat customers" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Repeat className="h-4 w-4" />
                )}
                <div className="text-left">
                  <div className="font-medium">Repeat Customers</div>
                  <div className="text-xs text-muted-foreground">Customers with multiple orders</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Dialog open={masterOpen} onOpenChange={setMasterOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Master Export</DialogTitle>
              <DialogDescription>
                One row per ordered item, merging customer, address, order and product details for the selected date range.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-2 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>From</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !fromDate && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {fromDate ? format(fromDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={fromDate}
                      onSelect={setFromDate}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>To</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !toDate && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {toDate ? format(toDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={toDate}
                      onSelect={setToDate}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div className="space-y-2 py-2">
              <div className="flex items-center justify-between">
                <Label>Order Status</Label>
                <div className="flex gap-2 text-xs">
                  <button
                    type="button"
                    className="text-primary hover:underline"
                    onClick={() => setSelectedStatuses([...ORDER_STATUSES])}
                  >
                    Select all
                  </button>
                  <span className="text-muted-foreground">·</span>
                  <button
                    type="button"
                    className="text-muted-foreground hover:underline"
                    onClick={() => setSelectedStatuses([])}
                  >
                    Clear
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 rounded-md border border-border p-3">
                {ORDER_STATUSES.map((status) => (
                  <label
                    key={status}
                    className="flex items-center gap-2 text-sm capitalize cursor-pointer"
                  >
                    <Checkbox
                      checked={selectedStatuses.includes(status)}
                      onCheckedChange={() => toggleStatus(status)}
                    />
                    {status}
                  </label>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                Leave all unchecked to export every status.
              </p>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setMasterOpen(false)} disabled={exporting === "master export"}>
                Cancel
              </Button>
              <Button onClick={handleMasterExport} disabled={exporting === "master export"}>
                {exporting === "master export" ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Exporting...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" /> Export CSV
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={repeatOpen} onOpenChange={setRepeatOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Export Repeat Customers</DialogTitle>
              <DialogDescription>
                Export customers who placed more than one order in the selected date range.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-2 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>From</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !repeatFromDate && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {repeatFromDate ? format(repeatFromDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={repeatFromDate}
                      onSelect={setRepeatFromDate}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>To</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !repeatToDate && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {repeatToDate ? format(repeatToDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={repeatToDate}
                      onSelect={setRepeatToDate}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="min-orders">Minimum orders placed</Label>
                <Input
                  id="min-orders"
                  type="number"
                  min={2}
                  value={minOrders}
                  onChange={(e) => setMinOrders(parseInt(e.target.value) || 2)}
                />
                <p className="text-xs text-muted-foreground">
                  Only customers with at least this many orders in the date range will be included.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setRepeatOpen(false)} disabled={exporting === "repeat customers"}>
                Cancel
              </Button>
              <Button onClick={handleRepeatExport} disabled={exporting === "repeat customers"}>
                {exporting === "repeat customers" ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Exporting...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" /> Export CSV
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>



        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Store Settings</CardTitle>
              <CardDescription>
                Configure your store name, contact information, and other general settings.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Coming soon...</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Settings</CardTitle>
              <CardDescription>
                Configure Razorpay, Wise, and other payment methods.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Coming soon...</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Shipping Settings</CardTitle>
              <CardDescription>
                Configure shipping zones, rates, and free shipping thresholds.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Coming soon...</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Email Settings</CardTitle>
              <CardDescription>
                Configure email templates and Mailchimp integration.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Coming soon...</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="pt-6">
            <Button variant="outline" asChild>
              <Link to="/">
                <Store className="mr-2 h-4 w-4" />
                View Storefront
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminSettings;
