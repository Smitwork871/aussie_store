import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { format } from "date-fns";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, Send } from "lucide-react";
import { plainToHtml, extractPlainSource } from "@/lib/broadcastFormat";

const DEFAULT_SUBJECT = "Important Payment Reminder – Please Confirm Bank Details Before Payment";

const DEFAULT_PLAIN = `Dear Customer,

Please do not use the same saved bank account details for every payment.

Before making any payment, kindly refer to the latest email sent to you, as the bank account details may be different for each order or invoice. Please confirm the correct bank details from the most recent email before transferring the payment.

Using old or incorrect bank account details may delay payment confirmation and could affect your order processing and delivery timing.

Thank you for your understanding and cooperation.

Kind regards,
Aussie Smoke Store`;

const DEFAULT_HTML = `<h2 style="margin:0 0 12px;color:#0F172A;font-size:18px;">Important Payment Reminder</h2>
<p>Dear Customer,</p>
<p><strong>Please do not use the same saved bank account details for every payment.</strong></p>
<p>Before making any payment, kindly refer to the latest email sent to you, as the bank account details may be different for each order or invoice. Please confirm the correct bank details from the most recent email before transferring the payment.</p>
<p>Using old or incorrect bank account details may delay payment confirmation and could affect your order processing and delivery timing.</p>
<p>Thank you for your understanding and cooperation.</p>
<p style="margin-top:20px;">Kind regards,<br/><strong>Aussie Smoke Store</strong></p>`;

type Format = "plain" | "html";

export default function Broadcasts() {
  const { user } = useAuth();
  const [format_, setFormat] = useState<Format>("plain");
  const [subject, setSubject] = useState(DEFAULT_SUBJECT);
  const [plain, setPlain] = useState(DEFAULT_PLAIN);
  const [html, setHtml] = useState(DEFAULT_HTML);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ total: number; suppressed: number } | null>(null);
  const [busy, setBusy] = useState<null | "preview" | "test" | "send" | "save" | "sendDraft">(null);
  const [drafts, setDrafts] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [sendingDraftId, setSendingDraftId] = useState<string | null>(null);

  // The HTML we will actually store / send.
  const outgoingHtml = useMemo(
    () => (format_ === "plain" ? plainToHtml(plain) : html),
    [format_, plain, html],
  );

  const loadAll = async () => {
    const { data } = await supabase.from("broadcasts").select("*").order("created_at", { ascending: false }).limit(50);
    const rows = data ?? [];
    setDrafts(rows.filter((b: any) => b.status === "draft"));
    setHistory(rows.filter((b: any) => b.status !== "draft"));
  };
  useEffect(() => { loadAll(); }, []);

  const resetForm = () => {
    setSubject(DEFAULT_SUBJECT);
    setPlain(DEFAULT_PLAIN);
    setHtml(DEFAULT_HTML);
    setFormat("plain");
    setEditingId(null);
    setPreview(null);
  };

  const call = async (action: "preview" | "test" | "send", extra: any = {}) => {
    const { data, error } = await supabase.functions.invoke("send-bulk-broadcast", {
      body: { action, subject, html: outgoingHtml, ...extra },
    });
    if (error) throw error;
    if ((data as any)?.error) throw new Error((data as any).error);
    return data as any;
  };

  const bodyIsEmpty = format_ === "plain" ? !plain.trim() : !html.trim();

  const onPreview = async () => {
    setBusy("preview");
    try {
      const d = await call("preview");
      setPreview({ total: d.total, suppressed: d.suppressed });
      toast.success(`${d.total} recipients (${d.suppressed} suppressed)`);
    } catch (e: any) { toast.error(e.message); } finally { setBusy(null); }
  };

  const onTest = async () => {
    if (!user?.email) return toast.error("No admin email");
    setBusy("test");
    try {
      await call("test", { to: user.email });
      toast.success(`Test sent to ${user.email}`);
    } catch (e: any) { toast.error(e.message); } finally { setBusy(null); }
  };

  const onSaveDraft = async () => {
    if (!subject.trim() || bodyIsEmpty) return toast.error("Subject and body required");
    setBusy("save");
    try {
      if (editingId) {
        const { error } = await supabase.from("broadcasts")
          .update({ subject, html: outgoingHtml })
          .eq("id", editingId);
        if (error) throw error;
        toast.success("Draft updated");
      } else {
        const { error } = await supabase.from("broadcasts").insert({
          subject, html: outgoingHtml, created_by: user?.id, status: "draft",
        });
        if (error) throw error;
        toast.success("Draft saved");
        resetForm();
      }
      loadAll();
    } catch (e: any) { toast.error(e.message); } finally { setBusy(null); }
  };

  const onSend = async () => {
    setBusy("send");
    try {
      const d = await call("send", editingId ? { broadcastId: editingId } : {});
      toast.success(`Sent ${d.sent} / ${d.total} · ${d.failed} failed · ${d.skipped} skipped`);
      resetForm();
      loadAll();
    } catch (e: any) { toast.error(e.message); } finally { setBusy(null); }
  };

  const onSendDraft = async (draft: any) => {
    setSendingDraftId(draft.id);
    setBusy("sendDraft");
    try {
      const { data, error } = await supabase.functions.invoke("send-bulk-broadcast", {
        body: { action: "send", subject: draft.subject, html: draft.html, broadcastId: draft.id },
      });
      if (error) throw error;
      if ((data as any)?.error) throw new Error((data as any).error);
      const d = data as any;
      toast.success(`Sent ${d.sent} / ${d.total} · ${d.failed} failed · ${d.skipped} skipped`);
      loadAll();
    } catch (e: any) { toast.error(e.message); } finally { setBusy(null); setSendingDraftId(null); }
  };

  const onEditDraft = (draft: any) => {
    setSubject(draft.subject);
    const src = extractPlainSource(draft.html ?? "");
    if (src !== null) {
      setFormat("plain");
      setPlain(src);
      setHtml(DEFAULT_HTML);
    } else {
      setFormat("html");
      setHtml(draft.html ?? "");
      setPlain(DEFAULT_PLAIN);
    }
    setEditingId(draft.id);
    setPreview(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const onDeleteDraft = async (id: string) => {
    const { error } = await supabase.from("broadcasts").delete().eq("id", id);
    if (error) return toast.error(error.message);
    if (editingId === id) resetForm();
    toast.success("Draft deleted");
    loadAll();
  };

  return (
    <AdminLayout>
      <div className="space-y-6 p-6">
        <div>
          <h1 className="text-2xl font-bold">Broadcasts</h1>
          <p className="text-sm text-muted-foreground">Compose, save, and send emails to all customers.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {editingId ? "Edit draft" : "Compose"}
              {editingId && <Badge variant="secondary">Editing draft</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Subject</Label>
              <Input value={subject} onChange={(e) => setSubject(e.target.value)} />
            </div>

            <div>
              <Label>Format</Label>
              <div className="mt-1 inline-flex rounded-md border p-1 bg-muted/30">
                <button
                  type="button"
                  onClick={() => setFormat("plain")}
                  className={`px-3 py-1 text-sm rounded ${format_ === "plain" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
                >
                  Plain text
                </button>
                <button
                  type="button"
                  onClick={() => setFormat("html")}
                  className={`px-3 py-1 text-sm rounded ${format_ === "html" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
                >
                  HTML
                </button>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {format_ === "plain"
                  ? "Just type — line breaks and links are formatted automatically. Switch to HTML for full control."
                  : "Write raw HTML. Use Plain text if you don't want to deal with tags."}
              </p>
            </div>

            {format_ === "plain" ? (
              <div>
                <Label>Message</Label>
                <Textarea
                  value={plain}
                  onChange={(e) => setPlain(e.target.value)}
                  rows={14}
                  placeholder="Write your message here…"
                />
              </div>
            ) : (
              <div>
                <Label>Body (HTML)</Label>
                <Textarea
                  value={html}
                  onChange={(e) => setHtml(e.target.value)}
                  rows={14}
                  className="font-mono text-xs"
                />
              </div>
            )}

            <div className="flex flex-wrap gap-3 items-center">
              <Button variant="outline" onClick={onSaveDraft} disabled={!!busy}>
                {busy === "save" ? "Saving…" : editingId ? "Update draft" : "Save as draft"}
              </Button>
              {editingId && (
                <Button variant="ghost" onClick={resetForm} disabled={!!busy}>New</Button>
              )}
              <Button variant="outline" onClick={onPreview} disabled={!!busy}>
                {busy === "preview" ? "Counting…" : "Preview recipient count"}
              </Button>
              <Button variant="outline" onClick={onTest} disabled={!!busy || !user?.email}>
                {busy === "test" ? "Sending…" : `Send test to me`}
              </Button>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button disabled={!!busy || !preview}>Send to all</Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Send broadcast to {preview?.total ?? 0} customers?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This sends "{subject}" to every unique customer email.
                      {preview?.suppressed ? ` ${preview.suppressed} unsubscribed addresses will be skipped.` : ""} Sending typically takes 1–5 minutes.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={onSend}>Send now</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              {preview && (
                <span className="text-sm text-muted-foreground">
                  {preview.total} will receive · {preview.suppressed} suppressed
                </span>
              )}
            </div>

            <div className="rounded-lg border p-4 bg-muted/30">
              <p className="text-xs font-semibold mb-2 text-muted-foreground">PREVIEW</p>
              <div
                className="prose prose-sm max-w-none"
                dangerouslySetInnerHTML={{ __html: outgoingHtml }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Saved drafts ({drafts.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Saved</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {drafts.length === 0 && (
                  <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground">No drafts. Save a draft above to reuse it later.</TableCell></TableRow>
                )}
                {drafts.map((b) => (
                  <TableRow key={b.id}>
                    <TableCell className="whitespace-nowrap">{format(new Date(b.created_at), "yyyy-MM-dd HH:mm")}</TableCell>
                    <TableCell className="max-w-md truncate">{b.subject}</TableCell>
                    <TableCell className="text-right">
                      <div className="inline-flex gap-2">
                        <Button size="sm" variant="ghost" onClick={() => onEditDraft(b)} disabled={!!busy}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="ghost" disabled={!!busy}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete this draft?</AlertDialogTitle>
                              <AlertDialogDescription>This cannot be undone.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => onDeleteDraft(b.id)}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" disabled={!!busy}>
                              <Send className="h-4 w-4 mr-1" />
                              {sendingDraftId === b.id ? "Sending…" : "Send now"}
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Send this draft to all customers?</AlertDialogTitle>
                              <AlertDialogDescription>
                                "{b.subject}" will be sent to every unique customer email. Unsubscribed addresses are skipped automatically.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => onSendDraft(b)}>Send now</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>History</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Sent</TableHead>
                  <TableHead className="text-right">Failed</TableHead>
                  <TableHead className="text-right">Skipped</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {history.length === 0 && (
                  <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground">No broadcasts yet</TableCell></TableRow>
                )}
                {history.map((b) => (
                  <TableRow key={b.id}>
                    <TableCell>{format(new Date(b.created_at), "yyyy-MM-dd HH:mm")}</TableCell>
                    <TableCell className="max-w-md truncate">{b.subject}</TableCell>
                    <TableCell className="text-right">{b.total}</TableCell>
                    <TableCell className="text-right text-primary">{b.sent}</TableCell>
                    <TableCell className="text-right text-destructive">{b.failed}</TableCell>
                    <TableCell className="text-right">{b.skipped}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
