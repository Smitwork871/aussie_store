import { useEffect, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Printer, Loader2, CheckSquare, Square } from "lucide-react";
import { Tables } from "@/integrations/supabase/types";
import {
  startOfDay,
  startOfWeek,
  startOfMonth,
  endOfDay,
  format,
} from "date-fns";

type DbOrder = Tables<"orders">;

const PrintOrders = () => {
  const [orders, setOrders] = useState<DbOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeFilter, setTimeFilter] = useState<string>("today");
  const [statusFilter, setStatusFilter] = useState<string>("confirmed");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchOrders();
  }, [timeFilter, statusFilter]);

  const getDateRange = () => {
    const now = new Date();
    switch (timeFilter) {
      case "today":
        return { from: startOfDay(now), to: endOfDay(now) };
      case "week":
        return { from: startOfWeek(now, { weekStartsOn: 1 }), to: endOfDay(now) };
      case "month":
        return { from: startOfMonth(now), to: endOfDay(now) };
      case "all":
        return { from: null, to: null };
      default:
        return { from: startOfDay(now), to: endOfDay(now) };
    }
  };

  const fetchOrders = async () => {
    setLoading(true);
    const { from, to } = getDateRange();

    let query = supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });

    if (statusFilter !== "all") {
      query = query.eq("status", statusFilter as any);
    }

    if (from && to) {
      query = query.gte("created_at", from.toISOString()).lte("created_at", to.toISOString());
    }

    const { data, error } = await query;

    if (error) {
      toast.error("Failed to fetch orders");
    } else {
      setOrders(data || []);
      setSelectedIds(new Set());
    }
    setLoading(false);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === orders.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(orders.map((o) => o.id)));
    }
  };

  const handleBulkPrint = () => {
    const selected = orders.filter((o) => selectedIds.has(o.id));
    if (selected.length === 0) {
      toast.error("Select at least one order to print");
      return;
    }

    const printWindow = window.open("", "_blank", "width=800,height=900");
    if (!printWindow) return;

    const esc = (v: unknown) =>
      String(v ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');

    const stickersHtml = selected
      .map((order) => {
        const address = order.shipping_address as any;
        return `
        <div class="sticker">
          <div class="logo">Aussie Smoke Store</div>
          <div class="order-num">${esc(order.order_number)}</div>
          <div class="section">
            <div class="label">Ship To:</div>
            <div class="value">
              ${esc(address?.full_name || "N/A")}<br>
              ${esc(address?.address_line1 || "")}<br>
              ${address?.address_line2 ? esc(address.address_line2) + "<br>" : ""}
              ${esc(address?.city || "")}, ${esc(address?.state || "")} ${esc(address?.postal_code || "")}<br>
              ${address?.phone ? "Ph: " + esc(address.phone) : ""}
            </div>
          </div>
          <div class="section">
            <div class="label">Payment:</div>
            <div class="value">${esc(String(order.payment_status).toUpperCase())} | ${esc(order.payment_method || "N/A")}</div>
          </div>
          <div class="section">
            <div class="label">Total: A$${Number(order.total).toFixed(2)}</div>
          </div>
          <div class="section">
            <div class="label">Date: ${esc(new Date(order.created_at).toLocaleDateString())}</div>
          </div>
        </div>`;
      })
      .join("");


    printWindow.document.write(`
      <html>
      <head><title>Bulk Print - ${selected.length} Labels</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 10px; margin: 0; }
        .sticker { border: 2px dashed #333; padding: 20px; max-width: 350px; margin: 10px auto; page-break-inside: avoid; }
        .logo { text-align: center; font-size: 18px; font-weight: bold; margin-bottom: 12px; border-bottom: 2px solid #333; padding-bottom: 8px; }
        .order-num { text-align: center; font-size: 14px; margin-bottom: 12px; color: #555; }
        .section { margin-bottom: 10px; }
        .label { font-weight: bold; font-size: 12px; color: #666; text-transform: uppercase; margin-bottom: 2px; }
        .value { font-size: 14px; line-height: 1.4; }
        @media print {
          body { padding: 0; }
          .sticker { border: 2px dashed #333; break-inside: avoid; }
        }
      </style>
      </head>
      <body>${stickersHtml}<script>window.print();</script></body></html>
    `);
    printWindow.document.close();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-yellow-500/10 text-yellow-500";
      case "confirmed": return "bg-blue-500/10 text-blue-500";
      case "processing": return "bg-purple-500/10 text-purple-500";
      case "shipped": return "bg-indigo-500/10 text-indigo-500";
      case "delivered": return "bg-green-500/10 text-green-500";
      case "cancelled": return "bg-red-500/10 text-red-500";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const filterLabel = () => {
    switch (timeFilter) {
      case "today": return "Today";
      case "week": return "This Week";
      case "month": return "This Month";
      case "all": return "All Time";
      default: return "";
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Print Orders</h1>
            <p className="text-muted-foreground">
              Bulk print shipping labels — {filterLabel()} ({orders.length} orders)
            </p>
          </div>
          <Button
            onClick={handleBulkPrint}
            disabled={selectedIds.size === 0}
          >
            <Printer className="mr-2 h-4 w-4" />
            Print {selectedIds.size > 0 ? `${selectedIds.size} Labels` : "Selected"}
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row gap-4">
              <Select value={timeFilter} onValueChange={setTimeFilter}>
                <SelectTrigger className="w-44">
                  <SelectValue placeholder="Time period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="all">All Time</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-44">
                  <SelectValue placeholder="Order status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="processing">Processing</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : orders.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No orders found for the selected filters
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={selectedIds.size === orders.length && orders.length > 0}
                        onCheckedChange={toggleSelectAll}
                      />
                    </TableHead>
                    <TableHead>Order</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Payment</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((order) => (
                    <TableRow
                      key={order.id}
                      className={selectedIds.has(order.id) ? "bg-primary/5" : ""}
                    >
                      <TableCell>
                        <Checkbox
                          checked={selectedIds.has(order.id)}
                          onCheckedChange={() => toggleSelect(order.id)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">
                        {order.order_number}
                      </TableCell>
                      <TableCell>
                        {format(new Date(order.created_at), "dd MMM yyyy")}
                      </TableCell>
                      <TableCell>
                        {(order.shipping_address as any)?.full_name ||
                          order.guest_email ||
                          "N/A"}
                      </TableCell>
                      <TableCell>A${Number(order.total).toFixed(2)}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(order.status)}>
                          {order.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            order.payment_status === "paid"
                              ? "default"
                              : "outline"
                          }
                        >
                          {order.payment_status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default PrintOrders;
