import { useEffect, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format, formatDistanceToNow } from "date-fns";
import { RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";

type Broadcast = {
  id: string;
  subject: string;
  status: string;
  total: number | null;
  sent: number | null;
  failed: number | null;
  skipped: number | null;
  created_at: string;
};

const statusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
  switch (status) {
    case "sent":
    case "completed":
      return "default";
    case "sending":
    case "running":
    case "queued":
      return "secondary";
    case "failed":
      return "destructive";
    default:
      return "outline";
  }
};

const statusLabel = (status: string) => {
  const map: Record<string, string> = {
    running: "sending",
    completed: "sent",
  };
  return (map[status] ?? status).toUpperCase();
};

export default function BroadcastHistory() {
  const [rows, setRows] = useState<Broadcast[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("broadcasts")
      .select("id,subject,status,total,sent,failed,skipped,created_at")
      .neq("status", "draft")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) toast.error(error.message);
    setRows((data ?? []) as Broadcast[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, []);

  return (
    <AdminLayout>
      <div className="space-y-6 p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Send history</h1>
            <p className="text-sm text-muted-foreground">
              Every broadcast send with its current status and timestamps. Auto-refreshes every 15s.
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All sends ({rows.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead>Relative</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Sent</TableHead>
                  <TableHead className="text-right">Failed</TableHead>
                  <TableHead className="text-right">Skipped</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground">
                      {loading ? "Loading…" : "No broadcasts have been sent yet."}
                    </TableCell>
                  </TableRow>
                )}
                {rows.map((b) => (
                  <TableRow key={b.id}>
                    <TableCell>
                      <Badge variant={statusVariant(b.status)}>{statusLabel(b.status)}</Badge>
                    </TableCell>
                    <TableCell className="max-w-md truncate">
                      <Link to={`/admin/broadcasts/${b.id}`} className="text-primary hover:underline">
                        {b.subject}
                      </Link>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {format(new Date(b.created_at), "yyyy-MM-dd HH:mm:ss")}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-muted-foreground">
                      {formatDistanceToNow(new Date(b.created_at), { addSuffix: true })}
                    </TableCell>
                    <TableCell className="text-right">{b.total ?? 0}</TableCell>
                    <TableCell className="text-right text-primary">{b.sent ?? 0}</TableCell>
                    <TableCell className="text-right text-destructive">{b.failed ?? 0}</TableCell>
                    <TableCell className="text-right">{b.skipped ?? 0}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
