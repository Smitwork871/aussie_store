import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  ChevronLeft,
  ChevronRight,
  ScrollText,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { toast } from "sonner";

interface ActivityLog {
  id: string;
  created_at: string;
  actor_id: string | null;
  actor_email: string | null;
  actor_label: string;
  action_type: string;
  description: string;
  ref_type: string | null;
  ref_id: string | null;
  ref_label: string | null;
}

const PAGE_SIZE = 25;

const ACTION_TYPES = [
  "Order Created",
  "Order Status Changed",
  "Order Cancelled",
  "Payment Status Changed",
  "Payment Verified (Bulk)",
  "Bulk Status Change",
  "Tracking Number Added",
  "Tracking Number Removed",
  "Stock Change",
  "Product Added",
  "Product Updated",
  "Product Deleted",
  "Customer Note Added",
  "Customer Note Updated",
  "Customer Note Deleted",
  "Admin Login",
  "Admin Logout",
];

const actionColor = (type: string) => {
  if (type.startsWith("Order Cancelled") || type.includes("Deleted") || type.includes("Removed"))
    return "bg-destructive/15 text-destructive border-destructive/30";
  if (type.startsWith("Payment")) return "bg-emerald-500/15 text-emerald-500 border-emerald-500/30";
  if (type.startsWith("Product")) return "bg-blue-500/15 text-blue-500 border-blue-500/30";
  if (type.startsWith("Stock")) return "bg-amber-500/15 text-amber-500 border-amber-500/30";
  if (type.startsWith("Admin")) return "bg-purple-500/15 text-purple-400 border-purple-500/30";
  return "bg-muted text-muted-foreground border-border";
};

const formatWhen = (iso: string) =>
  new Date(iso).toLocaleString("en-AU", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

export default function ActivityLogs() {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);

  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [actorFilter, setActorFilter] = useState("all");
  const [actionFilter, setActionFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  const [actors, setActors] = useState<{ id: string; label: string }[]>([]);

  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(0);
    }, 350);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    const loadActors = async () => {
      const { data } = await supabase
        .from("activity_logs")
        .select("actor_id, actor_label")
        .order("created_at", { ascending: false })
        .limit(1000);
      const map = new Map<string, string>();
      (data ?? []).forEach((row: any) => {
        map.set(row.actor_id ?? "system", row.actor_label ?? "System");
      });
      setActors(Array.from(map, ([id, label]) => ({ id, label })));
    };
    loadActors();
  }, []);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      let query = supabase
        .from("activity_logs")
        .select("*", { count: "exact" })
        .order("created_at", { ascending: false })
        .range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);

      if (actionFilter !== "all") query = query.eq("action_type", actionFilter);
      if (actorFilter === "system") query = query.is("actor_id", null);
      else if (actorFilter !== "all") query = query.eq("actor_id", actorFilter);
      if (dateFrom) query = query.gte("created_at", new Date(`${dateFrom}T00:00:00`).toISOString());
      if (dateTo) query = query.lte("created_at", new Date(`${dateTo}T23:59:59`).toISOString());
      if (debouncedSearch.trim()) {
        const q = debouncedSearch.trim().replace(/[%,]/g, "");
        query = query.or(`description.ilike.%${q}%,ref_label.ilike.%${q}%`);
      }

      const { data, error, count } = await query;
      if (error) throw error;
      setLogs((data ?? []) as ActivityLog[]);
      setTotal(count ?? 0);
    } catch (error: any) {
      toast.error(`Could not load activity logs: ${error.message}`);
    } finally {
      setLoading(false);
    }
  }, [page, actionFilter, actorFilter, dateFrom, dateTo, debouncedSearch]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  const activeChips = useMemo(() => {
    const chips: { label: string; clear: () => void }[] = [];
    if (actionFilter !== "all")
      chips.push({ label: `Action: ${actionFilter}`, clear: () => setActionFilter("all") });
    if (actorFilter !== "all") {
      const label = actors.find((a) => a.id === actorFilter)?.label ?? actorFilter;
      chips.push({ label: `Admin: ${label}`, clear: () => setActorFilter("all") });
    }
    if (dateFrom) chips.push({ label: `From: ${dateFrom}`, clear: () => setDateFrom("") });
    if (dateTo) chips.push({ label: `To: ${dateTo}`, clear: () => setDateTo("") });
    return chips;
  }, [actionFilter, actorFilter, dateFrom, dateTo, actors]);

  const clearAll = () => {
    setActionFilter("all");
    setActorFilter("all");
    setDateFrom("");
    setDateTo("");
    setSearch("");
    setPage(0);
  };

  const renderFilterFields = (prefix: string) => (
    <>
      <div className="space-y-1.5">
        <Label htmlFor={`${prefix}-actor`} className="text-xs">Admin User</Label>
        <select
          id={`${prefix}-actor`}
          value={actorFilter}
          onChange={(e) => {
            setActorFilter(e.target.value);
            setPage(0);
          }}
          className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
        >
          <option value="all">All users</option>
          {actors.map((a) => (
            <option key={a.id} value={a.id === "system" ? "system" : a.id}>
              {a.label}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor={`${prefix}-action`} className="text-xs">Action Type</Label>
        <select
          id={`${prefix}-action`}
          value={actionFilter}
          onChange={(e) => {
            setActionFilter(e.target.value);
            setPage(0);
          }}
          className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
        >
          <option value="all">All actions</option>
          {ACTION_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor={`${prefix}-from`} className="text-xs">From</Label>
        <Input
          id={`${prefix}-from`}
          type="date"
          value={dateFrom}
          onChange={(e) => {
            setDateFrom(e.target.value);
            setPage(0);
          }}
          className="h-9"
        />
      </div>

      <div className="space-y-1.5">
        <Label htmlFor={`${prefix}-to`} className="text-xs">To</Label>
        <Input
          id={`${prefix}-to`}
          type="date"
          value={dateTo}
          onChange={(e) => {
            setDateTo(e.target.value);
            setPage(0);
          }}
          className="h-9"
        />
      </div>
    </>
  );

  const renderReference = (log: ActivityLog) => {
    if (!log.ref_label) return <span className="text-muted-foreground">—</span>;
    if (log.ref_type === "order")
      return (
        <Link
          to={`/admin/orders?search=${encodeURIComponent(log.ref_label)}`}
          className="text-primary hover:underline font-mono text-xs"
        >
          {log.ref_label}
        </Link>
      );
    if (log.ref_type === "product")
      return (
        <Link to="/admin/products" className="text-primary hover:underline text-xs">
          {log.ref_label}
        </Link>
      );
    if (log.ref_type === "customer")
      return (
        <Link
          to={`/admin/customers?search=${encodeURIComponent(log.ref_label)}`}
          className="text-primary hover:underline text-xs"
        >
          {log.ref_label}
        </Link>
      );
    return <span className="text-xs">{log.ref_label}</span>;
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <ScrollText className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold">Activity Logs</h1>
            <p className="text-sm text-muted-foreground">
              Read-only audit trail of every admin and system action.
            </p>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-base">Filters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search details or reference (e.g. order number)…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>

              <div className="lg:hidden">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full gap-2">
                      <SlidersHorizontal className="h-4 w-4" />
                      Filters
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-72 space-y-3" align="end">
                    {renderFilterFields("mobile")}
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div className="hidden lg:grid grid-cols-4 gap-3">{renderFilterFields("desktop")}</div>

            {activeChips.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                {activeChips.map((chip) => (
                  <Badge key={chip.label} variant="secondary" className="gap-1">
                    {chip.label}
                    <button onClick={chip.clear} aria-label={`Clear ${chip.label}`}>
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
                <Button variant="ghost" size="sm" onClick={clearAll}>
                  Clear all
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[180px]">Timestamp</TableHead>
                  <TableHead className="w-[180px]">Admin User</TableHead>
                  <TableHead className="w-[200px]">Action Type</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead className="w-[160px]">Reference</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 5 }).map((__, j) => (
                        <TableCell key={j}>
                          <Skeleton className="h-4 w-full" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                      No activity found for these filters.
                    </TableCell>
                  </TableRow>
                ) : (
                  logs.map((log) => (
                    <TableRow key={log.id} className="hover:bg-muted/40">
                      <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                        {formatWhen(log.created_at)}
                      </TableCell>
                      <TableCell className="text-sm">
                        {log.actor_id ? (
                          <span title={log.actor_email ?? undefined}>{log.actor_label}</span>
                        ) : (
                          <Badge variant="outline" className="text-xs">System</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`text-xs ${actionColor(log.action_type)}`}>
                          {log.action_type}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{log.description}</TableCell>
                      <TableCell>{renderReference(log)}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted-foreground">
            {total === 0
              ? "No entries"
              : `Showing ${page * PAGE_SIZE + 1}–${Math.min((page + 1) * PAGE_SIZE, total)} of ${total} entries`}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page === 0 || loading}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
            >
              <ChevronLeft className="h-4 w-4" /> Previous
            </Button>
            <span className="text-sm text-muted-foreground">
              Page {page + 1} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={page + 1 >= totalPages || loading}
              onClick={() => setPage((p) => p + 1)}
            >
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
