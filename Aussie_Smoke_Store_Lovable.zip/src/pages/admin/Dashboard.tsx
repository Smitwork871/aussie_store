import { useEffect, useRef, useMemo, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";

import { HealthCheckCard } from "@/components/admin/HealthCheckCard";
import { RealtimeStatusCard } from "@/components/admin/RealtimeStatusCard";
import { useOrdersCounts } from "@/hooks/useOrdersCounts";

interface DashboardStats {
  totalProducts: number;
  lowStockProducts: number;
}

interface RecentOrder {
  id: string;
  order_number: string;
  total: number;
  status: string;
  created_at: string;
}

const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);
  const [orderSearch, setOrderSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const filteredOrders = useMemo(() => {
    const q = orderSearch.trim().toLowerCase();
    if (!q) return recentOrders;
    return recentOrders.filter((o) => o.order_number.toLowerCase().includes(q));
  }, [recentOrders, orderSearch]);



  const orders = useOrdersCounts();

  const fetchProductsStats = async () => {
    const { count: productCount } = await supabase
      .from('products')
      .select('*', { count: 'exact', head: true });
    const { data: lowStock } = await supabase
      .from('products')
      .select('id')
      .lt('stock_quantity', 10);

    setStats({
      totalProducts: productCount || 0,
      lowStockProducts: lowStock?.length || 0,
    });
  };

  const fetchRecentOrders = async () => {
    const PAGE = 1000;
    const all: RecentOrder[] = [];
    for (let from = 0; ; from += PAGE) {
      const { data, error } = await supabase
        .from('orders')
        .select('id, order_number, total, status, created_at')
        .order('created_at', { ascending: false })
        .range(from, from + PAGE - 1);
      if (error) throw error;
      if (!data || data.length === 0) break;
      all.push(...(data as RecentOrder[]));
      if (data.length < PAGE) break;
    }
    setRecentOrders(all);
  };


  useEffect(() => {
    (async () => {
      try {
        await Promise.all([fetchProductsStats(), fetchRecentOrders()]);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    })();

    let productsTimer: ReturnType<typeof setTimeout> | null = null;
    const scheduleProducts = () => {
      if (productsTimer) clearTimeout(productsTimer);
      productsTimer = setTimeout(() => {
        fetchProductsStats();
      }, 300);
    };

    // Recent orders list still needs its own listener (row-level, not a count)
    let ordersTimer: ReturnType<typeof setTimeout> | null = null;
    const scheduleOrders = () => {
      if (ordersTimer) clearTimeout(ordersTimer);
      ordersTimer = setTimeout(fetchRecentOrders, 300);
    };

    const ordersChannel = supabase
      .channel('dashboard-recent-orders')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, scheduleOrders)
      .subscribe();

    const productsChannel = supabase
      .channel('dashboard-products')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, scheduleProducts)
      .subscribe();

    return () => {
      if (ordersTimer) clearTimeout(ordersTimer);
      if (productsTimer) clearTimeout(productsTimer);
      supabase.removeChannel(ordersChannel);
      supabase.removeChannel(productsChannel);
    };
  }, []);

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'cancelled':
        return 'bg-destructive/10 text-destructive border border-destructive/20';
      case 'delivered':
      case 'shipped':
        return 'bg-success/10 text-success border border-success/20';
      case 'pending':
        return 'bg-warning/10 text-warning border border-warning/20';
      default:
        return 'bg-muted text-muted-foreground border border-border';
    }
  };

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto space-y-12 px-2">
        {/* Header */}
        <header className="flex flex-col gap-2 border-b border-border pb-8">
          <div className="text-[10px] font-bold tracking-[0.2em] text-muted-foreground uppercase">
            Management Console
          </div>
          <h1 className="text-3xl md:text-4xl font-semibold tracking-tight text-foreground leading-tight">
            System Overview
          </h1>
          <p className="text-sm text-muted-foreground">
            Key metrics, recent activity, and infrastructure status.
          </p>
        </header>

        {/* KPI Cards */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border rounded-xl overflow-hidden border border-border">
          {[
            {
              label: "Revenue (Paid)",
              loading: orders.loading,
              skeleton: <Skeleton className="h-8 w-32" />,
              value: (
                <div className="flex items-baseline gap-1.5">
                  <span className="text-3xl font-semibold tracking-tight text-foreground tabular-nums">
                    A${orders.paidRevenue.toFixed(2)}
                  </span>
                  <span className="text-[10px] font-bold text-muted-foreground">AUD</span>
                </div>
              ),
              footnote: "Paid orders only",
            },
            {
              label: "Total Orders",
              loading: orders.loading,
              skeleton: <Skeleton className="h-8 w-20" />,
              value: (
                <div className="text-3xl font-semibold tracking-tight text-foreground tabular-nums">
                  {orders.total.toLocaleString()}
                </div>
              ),
              footnote: orders.pending
                ? `${orders.pending} pending review`
                : "No pending orders",
            },
            {
              label: "Active Products",
              loading,
              skeleton: <Skeleton className="h-8 w-20" />,
              value: (
                <div className="text-3xl font-semibold tracking-tight text-foreground tabular-nums">
                  {stats?.totalProducts.toLocaleString()}
                </div>
              ),
              footnote: "Current catalog",
            },
            {
              label: "Low Stock",
              loading,
              skeleton: <Skeleton className="h-8 w-16" />,
              value: (
                <div
                  className={`text-3xl font-semibold tracking-tight tabular-nums ${
                    (stats?.lowStockProducts || 0) > 0
                      ? "text-destructive"
                      : "text-foreground"
                  }`}
                >
                  {stats?.lowStockProducts}
                </div>
              ),
              footnote:
                (stats?.lowStockProducts || 0) > 0 ? (
                  <span className="inline-flex items-center gap-1.5 text-destructive">
                    <span className="block w-1.5 h-1.5 rounded-full bg-destructive animate-pulse" />
                    Requires attention
                  </span>
                ) : (
                  "All stocked"
                ),
            },
          ].map((kpi) => (
            <div key={kpi.label} className="p-6 bg-card flex flex-col justify-between min-h-[140px]">
              <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-[0.15em]">
                {kpi.label}
              </div>
              <div className="mt-4">
                {kpi.loading ? kpi.skeleton : kpi.value}
                <div className="mt-2 text-[11px] font-medium text-muted-foreground">
                  {kpi.footnote}
                </div>
              </div>
            </div>
          ))}
        </section>

        {/* Main Section */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Orders */}
          <div className="lg:col-span-2 flex flex-col">
            <div className="flex items-center justify-between mb-2 h-6">
              <h2 className="text-xs font-semibold text-foreground uppercase tracking-[0.15em]">
                All Orders
              </h2>
              <a
                href="/admin/orders"
                className="text-[11px] font-semibold text-muted-foreground hover:text-foreground underline underline-offset-4 transition-colors"
              >
                View Ledger →
              </a>
            </div>
            <div className="flex items-center justify-between gap-3 mb-3">
              <p className="text-[11px] text-muted-foreground">
                {loading
                  ? "Loading orders…"
                  : `Showing ${filteredOrders.length.toLocaleString()} of ${recentOrders.length.toLocaleString()} orders`}
              </p>
              <Input
                type="search"
                placeholder="Search order #"
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                className="h-8 w-48 text-xs"
              />
            </div>
            <div className="flex-1 overflow-hidden border border-border rounded-xl bg-card">
              {loading ? (
                <div className="p-4 space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : recentOrders.length === 0 ? (
                <p className="text-muted-foreground text-center py-12 text-sm">
                  No orders yet
                </p>
              ) : (
                <div className="max-h-[520px] overflow-y-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-muted/40 border-b border-border sticky top-0 z-10">
                      <tr>
                        <th className="px-4 py-3 font-medium text-muted-foreground text-[11px] uppercase tracking-wider">
                          Order ID
                        </th>
                        <th className="px-4 py-3 font-medium text-muted-foreground text-[11px] uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-4 py-3 font-medium text-muted-foreground text-[11px] uppercase tracking-wider text-center">
                          Status
                        </th>
                        <th className="px-4 py-3 font-medium text-muted-foreground text-[11px] uppercase tracking-wider text-right whitespace-nowrap">
                          Total (AUD)
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredOrders.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-4 py-8 text-center text-muted-foreground text-sm">
                            No orders match "{orderSearch}"
                          </td>
                        </tr>
                      ) : (
                        filteredOrders.map((order) => (
                          <tr key={order.id} className="hover:bg-muted/30 transition-colors">
                            <td className="px-4 py-3 text-foreground font-medium tabular-nums">
                              {order.order_number}
                            </td>
                            <td className="px-4 py-3 text-muted-foreground tabular-nums">
                              {new Date(order.created_at).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-3 text-center">
                              <span
                                className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${getStatusBadgeClass(order.status)}`}
                              >
                                {order.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right tabular-nums text-foreground font-medium">
                              A${Number(order.total).toFixed(2)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>

          {/* Side Panel */}
          <div className="flex flex-col gap-8">
            {/* Health Check */}
            <div className="flex flex-col">
              <div className="flex items-center mb-4 h-6">
                <h2 className="text-xs font-semibold text-foreground uppercase tracking-[0.15em]">
                  Infrastructure
                </h2>
              </div>
              <div className="flex-1">
                <HealthCheckCard />
              </div>
            </div>

            {/* Realtime Status */}
            <div className="flex flex-col">
              <div className="flex items-center mb-4 h-6">
                <h2 className="text-xs font-semibold text-foreground uppercase tracking-[0.15em]">
                  Realtime
                </h2>
              </div>
              <div className="flex-1">
                <RealtimeStatusCard />
              </div>
            </div>
          </div>
        </section>
      </div>

    </AdminLayout>
  );
};

export default Dashboard;
