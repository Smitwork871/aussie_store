import React, { useEffect, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Search, Loader2, GripVertical, ChevronRight, FolderPlus } from "lucide-react";
import { Category } from "@/types/database";
import { ImageUpload } from "@/components/admin/ImageUpload";

const AdminCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [saving, setSaving] = useState(false);
  const [expandedParents, setExpandedParents] = useState<Set<string>>(new Set());

  const [formData, setFormData] = useState({
    name: "",
    slug: "",
    description: "",
    image_url: "",
    sort_order: "0",
    is_active: true,
    parent_id: "" as string,
  });

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('sort_order', { ascending: true });

    if (error) {
      toast.error('Failed to fetch categories');
    } else {
      setCategories((data as any[]) || []);
      // Auto-expand all parents
      const parentIds = new Set<string>();
      (data || []).forEach((c: any) => {
        if (c.parent_id) parentIds.add(c.parent_id);
      });
      setExpandedParents(parentIds);
    }
    setLoading(false);
  };

  const parentCategories = categories.filter(c => !c.parent_id);
  const getSubcategories = (parentId: string) => categories.filter(c => c.parent_id === parentId);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
      ...(name === 'name' ? { slug: value.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') } : {}),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const categoryData: any = {
      name: formData.name,
      slug: formData.slug,
      description: formData.description || null,
      image_url: formData.image_url || null,
      sort_order: parseInt(formData.sort_order),
      is_active: formData.is_active,
      parent_id: formData.parent_id || null,
    };

    try {
      if (editingCategory) {
        const { error } = await supabase
          .from('categories')
          .update(categoryData)
          .eq('id', editingCategory.id);
        if (error) throw error;
        toast.success('Category updated successfully');
      } else {
        const { error } = await supabase
          .from('categories')
          .insert(categoryData);
        if (error) throw error;
        toast.success('Category created successfully');
      }
      setIsDialogOpen(false);
      resetForm();
      fetchCategories();
    } catch (error: any) {
      toast.error(error.message || 'Failed to save category');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (category: Category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      slug: category.slug,
      description: category.description || "",
      image_url: category.image_url || "",
      sort_order: category.sort_order.toString(),
      is_active: category.is_active,
      parent_id: category.parent_id || "",
    });
    setIsDialogOpen(true);
  };

  const handleAddSubcategory = (parentId: string) => {
    resetForm();
    setFormData(prev => ({ ...prev, parent_id: parentId }));
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    const subs = getSubcategories(id);
    const msg = subs.length > 0
      ? 'This will also delete all subcategories. Are you sure?'
      : 'Are you sure you want to delete this category?';
    if (!confirm(msg)) return;

    const { error } = await supabase.from('categories').delete().eq('id', id);
    if (error) {
      toast.error('Failed to delete category');
    } else {
      toast.success('Category deleted');
      fetchCategories();
    }
  };

  const resetForm = () => {
    setEditingCategory(null);
    setFormData({ name: "", slug: "", description: "", image_url: "", sort_order: "0", is_active: true, parent_id: "" });
  };

  const toggleExpand = (id: string) => {
    setExpandedParents(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const filteredParents = parentCategories.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.slug.toLowerCase().includes(searchQuery.toLowerCase()) ||
    getSubcategories(c.id).some(s =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  const categoryFormContent = (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle>
          {editingCategory ? 'Edit Category' : formData.parent_id ? 'Add Subcategory' : 'Add New Category'}
        </DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="parent_id">Parent Category</Label>
          <Select
            value={formData.parent_id || "none"}
            onValueChange={(val) => setFormData(prev => ({ ...prev, parent_id: val === "none" ? "" : val }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="None (Top-level)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None (Top-level)</SelectItem>
              {parentCategories
                .filter(p => p.id !== editingCategory?.id)
                .map(p => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="slug">Slug *</Label>
            <Input id="slug" name="slug" value={formData.slug} onChange={handleInputChange} required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} rows={3} />
        </div>

        <div className="space-y-2">
          <Label>Cover Image</Label>
          <ImageUpload
            images={formData.image_url ? [formData.image_url] : []}
            onImagesChange={(images) => setFormData(prev => ({ ...prev, image_url: images[0] || "" }))}
            maxImages={1}
            bucket="product-images"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="sort_order">Sort Order</Label>
            <Input id="sort_order" name="sort_order" type="number" value={formData.sort_order} onChange={handleInputChange} />
          </div>
          <div className="space-y-2 flex items-end">
            <div className="flex items-center gap-2 pb-2">
              <Switch id="is_active" checked={formData.is_active} onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))} />
              <Label htmlFor="is_active">Active</Label>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {editingCategory ? 'Update' : 'Create'} Category
          </Button>
        </div>
      </form>
    </DialogContent>
  );

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Categories</h1>
            <p className="text-muted-foreground">Organize your product catalog with categories & subcategories</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) resetForm(); }}>
            <DialogTrigger asChild>
              <Button><Plus className="mr-2 h-4 w-4" /> Add Category</Button>
            </DialogTrigger>
            {categoryFormContent}
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search categories..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : filteredParents.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No categories found</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">Order</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Slug</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredParents.map((category) => {
                    const subs = getSubcategories(category.id);
                    const isExpanded = expandedParents.has(category.id);
                    return (
                      <React.Fragment key={category.id}>
                        <TableRow className="bg-muted/30">
                          <TableCell>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <GripVertical className="h-4 w-4" />
                              <span>{category.sort_order}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              {subs.length > 0 && (
                                <button onClick={() => toggleExpand(category.id)} className="p-0.5 hover:bg-muted rounded">
                                  <ChevronRight className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                                </button>
                              )}
                              {category.image_url ? (
                                <img src={category.image_url} alt={category.name} className="h-10 w-10 rounded object-cover" />
                              ) : (
                                <div className="h-10 w-10 rounded bg-muted flex items-center justify-center">
                                  <span className="text-xs text-muted-foreground">No img</span>
                                </div>
                              )}
                              <div>
                                <p className="font-semibold">{category.name}</p>
                                {subs.length > 0 && (
                                  <p className="text-xs text-muted-foreground">{subs.length} subcategories</p>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <code className="text-sm bg-muted px-2 py-1 rounded">{category.slug}</code>
                          </TableCell>
                          <TableCell>
                            <Badge variant={category.is_active ? "default" : "outline"}>
                              {category.is_active ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button variant="ghost" size="icon" onClick={() => handleAddSubcategory(category.id)} title="Add subcategory">
                                <FolderPlus className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleEdit(category)}>
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleDelete(category.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                        {isExpanded && subs.map((sub) => (
                          <TableRow key={sub.id}>
                            <TableCell>
                              <div className="flex items-center gap-2 text-muted-foreground pl-4">
                                <span>{sub.sort_order}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-3 pl-8">
                                {sub.image_url ? (
                                  <img src={sub.image_url} alt={sub.name} className="h-8 w-8 rounded object-cover" />
                                ) : (
                                  <div className="h-8 w-8 rounded bg-muted flex items-center justify-center">
                                    <span className="text-[10px] text-muted-foreground">—</span>
                                  </div>
                                )}
                                <p className="font-medium">{sub.name}</p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <code className="text-sm bg-muted px-2 py-1 rounded">{sub.slug}</code>
                            </TableCell>
                            <TableCell>
                              <Badge variant={sub.is_active ? "default" : "outline"}>
                                {sub.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-1">
                                <Button variant="ghost" size="icon" onClick={() => handleEdit(sub)}>
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" onClick={() => handleDelete(sub.id)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </React.Fragment>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminCategories;
