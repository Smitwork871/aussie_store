import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import PaymentVerificationTool from "@/components/admin/bulk/PaymentVerificationTool";
import ShippingTrackingUploadTool from "@/components/admin/bulk/ShippingTrackingUploadTool";
import { ArrowLeft, ChevronRight, ShieldCheck, Truck } from "lucide-react";
import { useParams, Link, useNavigate } from "react-router-dom";

/**
 * Bulk Operations hub.
 * To add a new bulk tool: build a self-contained component and append an entry
 * to this array — no other changes required.
 */
const bulkTools = [
  {
    slug: "payment-verification",
    label: "Payment Verification",
    description: "Verify payments and update order status in bulk.",
    icon: ShieldCheck,
    component: <PaymentVerificationTool />,
  },
  {
    slug: "shipping-tracking-upload",
    label: "Shipping & Tracking Upload",
    description: "Upload an Excel file to move orders to Shipped and add their tracking numbers.",
    icon: Truck,
    component: <ShippingTrackingUploadTool />,
  },
];


const BulkOperations = () => {
  const { toolSlug } = useParams();
  const navigate = useNavigate();
  const activeTool = bulkTools.find((t) => t.slug === toolSlug);

  if (toolSlug && !activeTool) {
    return (
      <AdminLayout>
        <div className="space-y-4">
          <h1 className="text-3xl font-bold">Tool not found</h1>
          <Button variant="outline" onClick={() => navigate("/admin/bulk-operations")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Bulk Operations
          </Button>
        </div>
      </AdminLayout>
    );
  }

  if (activeTool) {
    return (
      <AdminLayout>
        <div className="space-y-6">
          <Link
            to="/admin/bulk-operations"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Bulk Operations
          </Link>
          <div>
            <h1 className="text-3xl font-bold">{activeTool.label}</h1>
            <p className="text-muted-foreground">{activeTool.description}</p>
          </div>
          {activeTool.component}
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Bulk Operations</h1>
          <p className="text-muted-foreground">
            Run bulk actions across your store from one place.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {bulkTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Link key={tool.slug} to={`/admin/bulk-operations/${tool.slug}`} className="group">
                <Card className="h-full transition-colors hover:border-primary hover:shadow-md">
                  <CardHeader>
                    <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
                      <Icon className="h-5 w-5" />
                    </div>
                    <CardTitle className="flex items-center justify-between gap-2 text-lg">
                      {tool.label}
                      <ChevronRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
                    </CardTitle>
                    <CardDescription>{tool.description}</CardDescription>
                  </CardHeader>
                  <CardContent />
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </AdminLayout>
  );
};

export default BulkOperations;
