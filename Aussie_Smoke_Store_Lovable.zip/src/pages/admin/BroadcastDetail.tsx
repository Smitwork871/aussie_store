import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { ArrowLeft, Download, RefreshCw, Send as SendIcon } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Broadcast = {
  id: string;
  subject: string;
  html: string;
  status: string;
  total: number | null;
  sent: number | null;
  failed: number | null;
  skipped: number | null;
  created_at: string;
};

type Send = {
  id: string;
  email: string;
  status: string;
  error: string | null;
  sent_at: string | null;
};

const sendVariant = (s: string): "default" | "secondary" | "destructive" | "outline" => {
  if (s === "sent" || s === "delivered") return "default";
  if (s === "failed" || s === "error") return "destructive";
  if (s === "skipped" || s === "suppressed" || s === "unsubscribed") return "outline";
  return "secondary";
};

export default function BroadcastDetail() {
  const { id } = useParams<{ id: string }>();
  const [broadcast, setBroadcast] = useState<Broadcast | null>(null);
  const [sends, setSends] = useState<Send[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [resending, setResending] = useState(false);

  const failedCount = useMemo(
    () => sends.filter((r) => r.status === "failed").length,
    [sends],
  );

  const handleResendFailed = async () => {
    if (!id) return;
    setResending(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-bulk-broadcast", {
        body: { action: "resend_failed", broadcastId: id },
      });
      if (error) throw error;
      const r = data as { attempted: number; sent: number; failed: number };
      toast.success(`Resent ${r.sent}/${r.attempted} · ${r.failed} still failing`);
      await load();
    } catch (e: any) {
      toast.error(e?.message ?? "Resend failed");
    } finally {
      setResending(false);
    }
  };

  const load = async () => {
    if (!id) return;
    setLoading(true);
    const [b, s] = await Promise.all([
      supabase.from("broadcasts").select("*").eq("id", id).maybeSingle(),
      supabase
        .from("broadcast_sends")
        .select("id,email,status,error,sent_at")
        .eq("broadcast_id", id)
        .order("sent_at", { ascending: false, nullsFirst: false })
        .limit(5000),
    ]);
    if (b.error) toast.error(b.error.message);
    if (s.error) toast.error(s.error.message);
    setBroadcast((b.data as Broadcast) ?? null);
    setSends((s.data ?? []) as Send[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [id]);

  const statuses = useMemo(() => {
    const set = new Set<string>();
    sends.forEach((r) => set.add(r.status));
    return Array.from(set).sort();
  }, [sends]);

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    return sends.filter(
      (r) =>
        (statusFilter === "all" || r.status === statusFilter) &&
        (q === "" || r.email.toLowerCase().includes(q)),
    );
  }, [sends, filter, statusFilter]);

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    sends.forEach((r) => (c[r.status] = (c[r.status] ?? 0) + 1));
    return c;
  }, [sends]);

  const exportCsv = () => {
    const header = "email,status,sent_at,error\n";
    const body = filtered
      .map((r) =>
        [r.email, r.status, r.sent_at ?? "", (r.error ?? "").replace(/"/g, '""')]
          .map((v) => `"${v}"`)
          .join(","),
      )
      .join("\n");
    const blob = new Blob([header + body], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `broadcast-${id}-recipients.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AdminLayout>
      <div className="space-y-6 p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <Button asChild variant="ghost" size="sm" className="mb-2 -ml-2">
              <Link to="/admin/broadcasts/history">
                <ArrowLeft className="h-4 w-4 mr-1" /> Back to history
              </Link>
            </Button>
            <h1 className="text-2xl font-bold">Broadcast detail</h1>
            {broadcast && (
              <p className="text-sm text-muted-foreground">
                Sent {format(new Date(broadcast.created_at), "yyyy-MM-dd HH:mm:ss")}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={load} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="default"
                  size="sm"
                  disabled={failedCount === 0 || resending}
                >
                  <SendIcon className={`h-4 w-4 mr-2 ${resending ? "animate-pulse" : ""}`} />
                  {resending ? "Resending…" : `Resend failed (${failedCount})`}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Resend to failed recipients?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will retry the {failedCount} recipient{failedCount === 1 ? "" : "s"} whose
                    last attempt failed. Unsubscribed addresses will be skipped. Successful sends
                    won't be re-sent.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleResendFailed}>
                    Resend {failedCount}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        {broadcast && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {broadcast.subject}
                <Badge variant="secondary">{broadcast.status}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                <Stat label="Total targeted" value={broadcast.total ?? sends.length} />
                <Stat label="Sent" value={broadcast.sent ?? counts["sent"] ?? 0} tone="primary" />
                <Stat label="Failed" value={broadcast.failed ?? counts["failed"] ?? 0} tone="destructive" />
                <Stat label="Skipped" value={broadcast.skipped ?? 0} />
              </div>
              <div className="rounded-lg border p-4 bg-muted/30">
                <p className="text-xs font-semibold mb-2 text-muted-foreground">EMAIL PREVIEW</p>
                <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: broadcast.html }} />
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Recipients ({filtered.length} of {sends.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-3 items-center">
              <Input
                placeholder="Filter by email…"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="max-w-xs"
              />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="h-10 rounded-md border border-input bg-background px-3 text-sm"
              >
                <option value="all">All statuses ({sends.length})</option>
                {statuses.map((s) => (
                  <option key={s} value={s}>
                    {s} ({counts[s]})
                  </option>
                ))}
              </select>
              <Button variant="outline" size="sm" onClick={exportCsv} disabled={filtered.length === 0}>
                <Download className="h-4 w-4 mr-2" /> Export CSV
              </Button>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sent at</TableHead>
                  <TableHead>Error</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground">
                      {loading ? "Loading…" : "No recipients match."}
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono text-xs">{r.email}</TableCell>
                    <TableCell>
                      <Badge variant={sendVariant(r.status)}>{r.status}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-muted-foreground">
                      {r.sent_at ? format(new Date(r.sent_at), "yyyy-MM-dd HH:mm:ss") : "—"}
                    </TableCell>
                    <TableCell className="max-w-md truncate text-destructive text-xs">
                      {r.error ?? ""}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}

function Stat({ label, value, tone }: { label: string; value: number | string; tone?: "primary" | "destructive" }) {
  const color = tone === "primary" ? "text-primary" : tone === "destructive" ? "text-destructive" : "text-foreground";
  return (
    <div className="rounded-lg border p-4">
      <p className="text-xs uppercase text-muted-foreground">{label}</p>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
  );
}
