import { useEffect, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Search, Eye, Loader2, Printer, Plus, X, Copy, SlidersHorizontal } from "lucide-react";
import { OrderStatus, PaymentStatus } from "@/types/database";
import { Tables } from "@/integrations/supabase/types";

type DbOrder = Tables<"orders">;
type DbOrderItem = Tables<"order_items">;

const ORDER_STATUSES: OrderStatus[] = [
  'pending',
  'confirmed',
  'processing',
  'shipped',
  'awaiting_collection',
  'delivered',
  'cancelled',
  'refunded',
];

const formatStatusLabel = (status: string) =>
  status.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

const PAYMENT_STATUSES: PaymentStatus[] = [
  'pending',
  'paid',
  'failed',
  'refunded',
];

const AdminOrders = () => {
  const [orders, setOrders] = useState<DbOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [paymentStatusFilter, setPaymentStatusFilter] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState<string>("");
  const [dateTo, setDateTo] = useState<string>("");
  const [minAmount, setMinAmount] = useState<string>("");
  const [maxAmount, setMaxAmount] = useState<string>("");
  const [selectedOrder, setSelectedOrder] = useState<DbOrder | null>(null);
  const [orderItems, setOrderItems] = useState<DbOrderItem[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [trackingPrompt, setTrackingPrompt] = useState<{ open: boolean; orderId: string | null }>({ open: false, orderId: null });
  const [trackingInputs, setTrackingInputs] = useState<string[]>([""]);
  const [trackingSubmitting, setTrackingSubmitting] = useState(false);
  const [editTrackingOpen, setEditTrackingOpen] = useState(false);
  const [editTrackingInputs, setEditTrackingInputs] = useState<string[]>([""]);
  const [selectedCustomerEmail, setSelectedCustomerEmail] = useState<string | null>(null);
  const [selectedCustomerName, setSelectedCustomerName] = useState<string | null>(null);
  const [selectedCustomerNote, setSelectedCustomerNote] = useState<string | null>(null);
  const [view, setView] = useState<'all' | 'unpaid7'>('all');
  const [restockingId, setRestockingId] = useState<string | null>(null);





  const EMAIL_TYPE_MAP: Record<string, string> = {
    confirmed: 'order_confirmed',
    processing: 'processing',
    delivered: 'delivered',
    cancelled: 'cancellation',
    refunded: 'refunded',
  };

  useEffect(() => {
    fetchOrders();
    let t: ReturnType<typeof setTimeout> | null = null;
    const schedule = () => {
      if (t) clearTimeout(t);
      t = setTimeout(() => fetchOrders(), 300);
    };
    const channel = supabase
      .channel('admin-orders-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, schedule)
      .subscribe();
    return () => {
      if (t) clearTimeout(t);
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    const PAGE = 1000;
    const all: any[] = [];
    try {
      for (let from = 0; ; from += PAGE) {
        const { data, error } = await supabase
          .from('orders')
          .select('*')
          .order('created_at', { ascending: false })
          .range(from, from + PAGE - 1);
        if (error) throw error;
        if (!data || data.length === 0) break;
        all.push(...data);
        if (data.length < PAGE) break;
      }
      setOrders(all);
    } catch (err) {
      toast.error('Failed to fetch orders');
    }
    setLoading(false);
  };


  const fetchOrderItems = async (orderId: string) => {
    const { data, error } = await supabase
      .from('order_items')
      .select('*')
      .eq('order_id', orderId);

    if (error) {
      toast.error('Failed to fetch order items');
    } else {
      setOrderItems(data || []);
    }
  };

  const handleViewOrder = async (order: DbOrder) => {
    setSelectedOrder(order);
    setSelectedCustomerEmail(order.guest_email ?? null);
    setSelectedCustomerName((order.shipping_address as any)?.full_name ?? null);
    setSelectedCustomerNote(null);
    await fetchOrderItems(order.id);
    setIsDialogOpen(true);

    let email = order.guest_email ?? null;
    if (order.user_id) {
      const { data } = await supabase
        .from('profiles')
        .select('email, full_name')
        .eq('user_id', order.user_id)
        .maybeSingle();
      if (data?.email) email = data.email;
      if (data?.full_name) setSelectedCustomerName(data.full_name);
      setSelectedCustomerEmail(email);
    }

    if (email) {
      const { data: note } = await supabase
        .from('customer_notes')
        .select('note')
        .eq('email', email)
        .maybeSingle();
      setSelectedCustomerNote(note?.note?.trim() ? note.note : null);
    }
  };

  /** Total orders this customer has placed (matched by account or email). */
  const getCustomerOrderCount = (order: DbOrder, email: string | null) => {
    const lower = email?.toLowerCase() ?? null;
    return orders.filter((o) => {
      if (order.user_id && o.user_id === order.user_id) return true;
      if (lower && (o.guest_email || '').toLowerCase() === lower) return true;
      return false;
    }).length;
  };


  const sendUpdateEmail = async (orderId: string, emailType: string) => {
    try {
      const { error } = await supabase.functions.invoke('send-order-email', {
        body: { order_id: orderId, email_type: emailType },
      });
      if (error) {
        console.error('Failed to send update email:', error);
      }
    } catch (e) {
      console.error('Email send error:', e);
    }
  };

  const TRACKING_REGEX = /^[A-Za-z0-9]{10,35}$/;

  /** All tracking numbers stored against an order (falls back to the legacy single value). */
  const getTrackingList = (order: any): string[] => {
    const list = Array.isArray(order?.tracking_numbers) ? order.tracking_numbers.filter(Boolean) : [];
    if (list.length > 0) return list;
    const single = typeof order?.tracking_number === 'string' ? order.tracking_number.trim() : '';
    return single ? [single] : [];
  };

  /** Normalises the input fields: trims, uppercases, ignores blanks. Returns an error message when invalid. */
  const normaliseTrackingInputs = (inputs: string[]): { values: string[]; error: string | null } => {
    const cleaned = inputs.map(v => v.trim().toUpperCase()).filter(v => v.length > 0);
    if (cleaned.length === 0) {
      return { values: [], error: 'Enter at least one tracking number.' };
    }
    const invalid = cleaned.find(v => !TRACKING_REGEX.test(v));
    if (invalid) {
      return { values: [], error: `"${invalid}" is not a valid AusPost tracking number (10–35 letters/numbers).` };
    }
    const unique = Array.from(new Set(cleaned));
    if (unique.length !== cleaned.length) {
      return { values: [], error: 'The same tracking number was entered more than once.' };
    }
    return { values: unique, error: null };
  };

  const trackingFieldsValid = (inputs: string[]) => normaliseTrackingInputs(inputs).error === null;

  const copyTracking = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success('Tracking number copied');
    } catch {
      toast.error('Could not copy tracking number');
    }
  };

  const handleStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    // Intercept transition to "shipped": require at least one AusPost tracking number.
    if (newStatus === 'shipped') {
      const order = orders.find(o => o.id === orderId);
      const existing = getTrackingList(order);
      if (existing.length === 0) {
        setTrackingInputs([""]);
        setTrackingPrompt({ open: true, orderId });
        return;
      }
    }

    // "Awaiting Collection" requires a tracking number so the customer can pick up.
    if (newStatus === 'awaiting_collection') {
      const order = orders.find(o => o.id === orderId);
      const existing = getTrackingList(order);
      if (existing.length === 0) {
        toast.error('Add a tracking number first — mark the order as shipped before setting Awaiting Collection.');
        return;
      }
    }

    const { error } = await supabase
      .from('orders')
      .update({ 
        status: newStatus,
        ...(newStatus === 'shipped' ? { shipped_at: new Date().toISOString() } : {}),
        ...(newStatus === 'delivered' ? { delivered_at: new Date().toISOString() } : {}),
      })
      .eq('id', orderId);

    if (error) {
      toast.error(error.message || 'Failed to update order status');
    } else {
      toast.success('Order status updated');
      fetchOrders();
      if (selectedOrder?.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, status: newStatus } : null);
      }
      const emailTypeMap: Record<string, string> = {
        confirmed: 'order_confirmed',
        processing: 'processing',
        shipped: 'shipped',
        awaiting_collection: 'awaiting_collection',
        delivered: 'delivered',
        cancelled: 'cancellation',
        refunded: 'refunded',
      };
      if (emailTypeMap[newStatus]) {
        sendUpdateEmail(orderId, emailTypeMap[newStatus]);

      }
    }
  };

  const confirmTrackingAndShip = async () => {
    if (!trackingPrompt.orderId) return;
    const { values, error: validationError } = normaliseTrackingInputs(trackingInputs);
    if (validationError) {
      toast.error(validationError);
      return;
    }
    setTrackingSubmitting(true);
    const orderId = trackingPrompt.orderId;
    const { error } = await supabase
      .from('orders')
      .update({
        tracking_numbers: values,
        tracking_number: values[0],
        tracking_carrier: 'AusPost',
        status: 'shipped',
        shipped_at: new Date().toISOString(),
      })
      .eq('id', orderId);
    setTrackingSubmitting(false);
    if (error) {
      toast.error(error.message || 'Failed to mark as shipped');
      return;
    }
    toast.success(values.length > 1 ? `Order marked as shipped with ${values.length} tracking numbers` : 'Order marked as shipped with tracking number');
    setTrackingPrompt({ open: false, orderId: null });
    setTrackingInputs([""]);
    fetchOrders();
    if (selectedOrder?.id === orderId) {
      setSelectedOrder(prev => prev ? { ...prev, status: 'shipped', tracking_numbers: values, tracking_number: values[0], tracking_carrier: 'AusPost' } as DbOrder : null);
    }
    sendUpdateEmail(orderId, 'shipped');
  };

  const saveEditedTracking = async () => {
    if (!selectedOrder) return;
    const { values, error: validationError } = normaliseTrackingInputs(editTrackingInputs);
    if (validationError) {
      toast.error(validationError);
      return;
    }
    const { error } = await supabase
      .from('orders')
      .update({ tracking_numbers: values, tracking_number: values[0], tracking_carrier: 'AusPost' })
      .eq('id', selectedOrder.id);
    if (error) {
      toast.error(error.message || 'Failed to update tracking numbers');
      return;
    }
    toast.success('Tracking numbers updated');
    setEditTrackingOpen(false);
    fetchOrders();
    setSelectedOrder(prev => prev ? { ...prev, tracking_numbers: values, tracking_number: values[0], tracking_carrier: 'AusPost' } as DbOrder : null);
  };

  const handlePaymentStatusChange = async (orderId: string, newStatus: PaymentStatus) => {
    const { error } = await supabase
      .from('orders')
      .update({ payment_status: newStatus })
      .eq('id', orderId);

    if (error) {
      toast.error('Failed to update payment status');
    } else {
      toast.success('Payment status updated');
      fetchOrders();
      if (selectedOrder?.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, payment_status: newStatus } : null);
      }
      // Send payment update email to customer
      const emailTypeMap: Record<string, string> = {
        paid: 'payment_confirmed',
        failed: 'payment_failed',
        refunded: 'refunded',
      };
      if (emailTypeMap[newStatus]) {
        sendUpdateEmail(orderId, emailTypeMap[newStatus]);
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20';
      case 'confirmed': return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
      case 'processing': return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20';
      case 'shipped': return 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/20';
      case 'awaiting_collection': return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
      case 'delivered': return 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20';
      case 'cancelled': return 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20';
      case 'refunded': return 'bg-muted text-muted-foreground border-border';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getPaymentColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20';
      case 'pending': return 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20';
      case 'failed': return 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20';
      case 'refunded': return 'bg-muted text-muted-foreground border-border';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const filteredOrders = orders.filter(order => {
    const q = searchQuery.trim().toLowerCase();
    const customerName = ((order.shipping_address as any)?.full_name || '').toLowerCase();
    const matchesSearch =
      !q ||
      order.order_number.toLowerCase().includes(q) ||
      customerName.includes(q);
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    const matchesPayment = paymentStatusFilter === 'all' || order.payment_status === paymentStatusFilter;
    const createdAt = new Date(order.created_at).getTime();
    const fromOk = !dateFrom || createdAt >= new Date(dateFrom + 'T00:00:00').getTime();
    const toOk = !dateTo || createdAt <= new Date(dateTo + 'T23:59:59.999').getTime();
    const total = Number(order.total);
    const minOk = minAmount === '' || Number.isNaN(Number(minAmount)) || total >= Number(minAmount);
    const maxOk = maxAmount === '' || Number.isNaN(Number(maxAmount)) || total <= Number(maxAmount);
    return matchesSearch && matchesStatus && matchesPayment && fromOk && toOk && minOk && maxOk;
  });

  const activeFilterChips: { key: string; label: string; clear: () => void }[] = [
    ...(statusFilter !== 'all'
      ? [{ key: 'status', label: `Status: ${formatStatusLabel(statusFilter)}`, clear: () => setStatusFilter('all') }]
      : []),
    ...(paymentStatusFilter !== 'all'
      ? [{ key: 'payment', label: `Payment: ${formatStatusLabel(paymentStatusFilter)}`, clear: () => setPaymentStatusFilter('all') }]
      : []),
    ...(dateFrom ? [{ key: 'from', label: `From: ${dateFrom}`, clear: () => setDateFrom('') }] : []),
    ...(dateTo ? [{ key: 'to', label: `To: ${dateTo}`, clear: () => setDateTo('') }] : []),
    ...(minAmount ? [{ key: 'min', label: `Min: A$${minAmount}`, clear: () => setMinAmount('') }] : []),
    ...(maxAmount ? [{ key: 'max', label: `Max: A$${maxAmount}`, clear: () => setMaxAmount('') }] : []),
    ...(searchQuery.trim() ? [{ key: 'search', label: `Search: ${searchQuery.trim()}`, clear: () => setSearchQuery('') }] : []),
  ];

  const clearAllFilters = () => {
    setSearchQuery('');
    setStatusFilter('all');
    setPaymentStatusFilter('all');
    setDateFrom('');
    setDateTo('');
    setMinAmount('');
    setMaxAmount('');
  };

  /** Whole days since the order was placed. */
  const daysSincePlaced = (order: DbOrder) =>
    Math.floor((Date.now() - new Date(order.created_at).getTime()) / 86400000);

  /** Orders still pending + unpaid 7 or more days after being placed. */
  const flaggedUnpaidOrders = orders
    .filter(o => o.status === 'pending' && o.payment_status === 'pending' && daysSincePlaced(o) >= 7)
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

  const cancelAndRestock = async (order: DbOrder) => {
    setRestockingId(order.id);
    const { error } = await supabase
      .from('orders')
      .update({ status: 'cancelled' })
      .eq('id', order.id);
    setRestockingId(null);
    if (error) {
      toast.error(error.message || 'Failed to cancel order');
      return;
    }
    toast.success(`${order.order_number} cancelled and stock restored`);
    fetchOrders();
    sendUpdateEmail(order.id, 'cancellation');
  };






  const formatAddress = (address: any) => {
    if (!address) return 'N/A';
    return `${address.full_name}, ${address.address_line1}, ${address.city}, ${address.state} ${address.postal_code}`;
  };

  const handlePrintSticker = (order: DbOrder) => {
    const address = order.shipping_address as any;
    const esc = (v: unknown) =>
      String(v ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    const printWindow = window.open('', '_blank', 'width=400,height=600');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
      <head><title>Order Sticker - ${esc(order.order_number)}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; margin: 0; }
        .sticker { border: 2px dashed #333; padding: 20px; max-width: 350px; margin: 0 auto; }
        .logo { text-align: center; font-size: 18px; font-weight: bold; margin-bottom: 12px; border-bottom: 2px solid #333; padding-bottom: 8px; }
        .order-num { text-align: center; font-size: 14px; margin-bottom: 12px; color: #555; }
        .section { margin-bottom: 10px; }
        .label { font-weight: bold; font-size: 12px; color: #666; text-transform: uppercase; margin-bottom: 2px; }
        .value { font-size: 14px; line-height: 1.4; }
        .items { border-top: 1px solid #ccc; padding-top: 8px; margin-top: 8px; }
        .item { font-size: 12px; margin-bottom: 4px; }
        @media print { body { padding: 0; } .sticker { border: 2px dashed #333; } }
      </style>
      </head>
      <body>
        <div class="sticker">
          <div class="logo">Aussie Smoke Store</div>
          <div class="order-num">${esc(order.order_number)}</div>
          <div class="section">
            <div class="label">Ship To:</div>
            <div class="value">
              ${esc(address?.full_name || 'N/A')}<br>
              ${esc(address?.address_line1 || '')}<br>
              ${address?.address_line2 ? esc(address.address_line2) + '<br>' : ''}
              ${esc(address?.city || '')}, ${esc(address?.state || '')} ${esc(address?.postal_code || '')}<br>
              ${address?.phone ? 'Ph: ' + esc(address.phone) : ''}
            </div>
          </div>
          <div class="section">
            <div class="label">Payment:</div>
            <div class="value">${esc(String(order.payment_status).toUpperCase())} | ${esc(order.payment_method || 'N/A')}</div>
          </div>
          <div class="section">
            <div class="label">Total: A$${Number(order.total).toFixed(2)}</div>
          </div>
          <div class="section">
            <div class="label">Date: ${esc(new Date(order.created_at).toLocaleDateString())}</div>
          </div>

        </div>
        <script>window.print();</script>
      </body></html>
    `);
    printWindow.document.close();
  };

  const renderFilterFields = (idPrefix: string) => (
    <>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={`${idPrefix}-status`} className="text-xs font-medium text-muted-foreground">Order status</Label>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger id={`${idPrefix}-status`} className="w-full sm:w-44">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {ORDER_STATUSES.map(status => (
              <SelectItem key={status} value={status}>
                {formatStatusLabel(status)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={`${idPrefix}-payment`} className="text-xs font-medium text-muted-foreground">Payment status</Label>
        <Select value={paymentStatusFilter} onValueChange={setPaymentStatusFilter}>
          <SelectTrigger id={`${idPrefix}-payment`} className="w-full sm:w-44">
            <SelectValue placeholder="All payments" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All payments</SelectItem>
            {PAYMENT_STATUSES.map(ps => (
              <SelectItem key={ps} value={ps}>
                {formatStatusLabel(ps)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex flex-col gap-1.5">
        <Label className="text-xs font-medium text-muted-foreground">Date placed</Label>
        <div className="flex items-center gap-2">
          <Input
            aria-label="From date"
            type="date"
            value={dateFrom}
            max={dateTo || undefined}
            onChange={(e) => setDateFrom(e.target.value)}
            className="w-full sm:w-40"
          />
          <span className="text-xs text-muted-foreground">to</span>
          <Input
            aria-label="To date"
            type="date"
            value={dateTo}
            min={dateFrom || undefined}
            onChange={(e) => setDateTo(e.target.value)}
            className="w-full sm:w-40"
          />
        </div>
      </div>
      <div className="flex flex-col gap-1.5">
        <Label className="text-xs font-medium text-muted-foreground">Order total (A$)</Label>
        <div className="flex items-center gap-2">
          <Input
            aria-label="Minimum amount"
            type="number"
            min="0"
            inputMode="decimal"
            placeholder="Min"
            value={minAmount}
            onChange={(e) => setMinAmount(e.target.value)}
            className="w-full sm:w-24"
          />
          <span className="text-xs text-muted-foreground">to</span>
          <Input
            aria-label="Maximum amount"
            type="number"
            min="0"
            inputMode="decimal"
            placeholder="Max"
            value={maxAmount}
            onChange={(e) => setMaxAmount(e.target.value)}
            className="w-full sm:w-24"
          />
        </div>
      </div>
    </>
  );

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Orders</h1>
          <p className="text-muted-foreground">Manage customer orders</p>
        </div>

        {/* View tabs */}
        <div className="flex flex-wrap items-center gap-2">
          <Button variant={view === 'all' ? 'default' : 'outline'} size="sm" onClick={() => setView('all')}>
            All Orders
          </Button>
          <Button variant={view === 'unpaid7' ? 'default' : 'outline'} size="sm" onClick={() => setView('unpaid7')}>
            Unpaid Orders (7+ Days)
            {flaggedUnpaidOrders.length > 0 && (
              <Badge variant="outline" className="ml-2 bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20">
                {flaggedUnpaidOrders.length}
              </Badge>
            )}
          </Button>
        </div>

        {view === 'unpaid7' && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Unpaid Orders (7+ Days)</CardTitle>
              <p className="text-sm text-muted-foreground">
                Pending orders with no payment received 7 or more days after being placed. Cancelling one restores its stock automatically.
              </p>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2 py-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-12 w-full animate-pulse rounded-md bg-muted/50" />
                  ))}
                </div>
              ) : flaggedUnpaidOrders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No orders flagged — everything is up to date</p>
              ) : (
                <div className="rounded-lg border overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/40 hover:bg-muted/40">
                        <TableHead>Order</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Order Date</TableHead>
                        <TableHead className="text-right">Days Pending</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {flaggedUnpaidOrders.map((order) => (
                        <TableRow key={order.id} className="transition-colors hover:bg-muted/50">
                          <TableCell className="py-3 font-medium whitespace-nowrap">{order.order_number}</TableCell>
                          <TableCell className="py-3">
                            {(order.shipping_address as any)?.full_name || order.guest_email || 'N/A'}
                          </TableCell>
                          <TableCell className="py-3 whitespace-nowrap text-muted-foreground">
                            {new Date(order.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="py-3 text-right tabular-nums">{daysSincePlaced(order)}</TableCell>
                          <TableCell className="py-3 text-right tabular-nums font-medium">A${Number(order.total).toFixed(2)}</TableCell>
                          <TableCell className="py-3 text-right whitespace-nowrap">
                            <Button variant="ghost" size="icon" onClick={() => handleViewOrder(order)} aria-label="View order">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              className="ml-2"
                              disabled={restockingId === order.id}
                              onClick={() => cancelAndRestock(order)}
                            >
                              {restockingId === order.id && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                              Cancel &amp; Restock
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {view === 'all' && (
        <Card>

          <CardHeader>
            <div className="space-y-4">

              <div className="rounded-lg border bg-card p-3 sm:p-4 space-y-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-end md:flex-wrap">
                  <div className="relative flex-1 min-w-[220px] md:max-w-sm">
                    <Label htmlFor="orders-search" className="text-xs font-medium text-muted-foreground">Search</Label>
                    <Search className="absolute left-3 top-[2.15rem] h-4 w-4 text-muted-foreground" />
                    <Input
                      id="orders-search"
                      placeholder="Order number or customer name..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9 mt-1.5"
                    />
                  </div>

                  {/* Desktop / tablet inline filters */}
                  <div className="hidden lg:flex flex-wrap items-end gap-3">
                    {renderFilterFields('desktop')}
                  </div>

                  {/* Compact filters for narrow screens */}
                  <div className="lg:hidden">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full sm:w-auto">
                          <SlidersHorizontal className="h-4 w-4 mr-2" />
                          Filters
                          {activeFilterChips.filter(c => c.key !== 'search').length > 0 && (
                            <Badge variant="secondary" className="ml-2">
                              {activeFilterChips.filter(c => c.key !== 'search').length}
                            </Badge>
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent align="start" className="w-[min(20rem,90vw)] space-y-4">
                        {renderFilterFields('mobile')}
                      </PopoverContent>
                    </Popover>
                  </div>

                  {activeFilterChips.length > 0 && (
                    <Button variant="ghost" size="sm" onClick={clearAllFilters} className="md:ml-auto">
                      Clear filters
                    </Button>
                  )}
                </div>

                {activeFilterChips.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 border-t pt-3">
                    {activeFilterChips.map(chip => (
                      <button
                        key={chip.key}
                        type="button"
                        onClick={chip.clear}
                        className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-3 py-1 text-xs font-medium text-foreground transition-colors hover:bg-muted"
                      >
                        {chip.label}
                        <X className="h-3 w-3 text-muted-foreground" />
                      </button>
                    ))}
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-3">
                  <p className="text-xs text-muted-foreground">
                    Showing {filteredOrders.length} of {orders.length} orders
                  </p>
                  {flaggedUnpaidOrders.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setView('unpaid7')}
                      className="inline-flex items-center gap-1.5 rounded-full border border-red-500/20 bg-red-500/10 px-3 py-1 text-xs font-medium text-red-600 dark:text-red-400"
                    >
                      {flaggedUnpaidOrders.length} unpaid 7+ days
                    </button>
                  )}
                </div>

              </div>
            </div>

          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-2 py-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading orders...
                </div>
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-12 w-full animate-pulse rounded-md bg-muted/50" />
                ))}
              </div>
            ) : filteredOrders.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No orders found</p>
            ) : (
              <div className="rounded-lg border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead>Order</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead>Status</TableHead>


                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map((order) => (
                    <TableRow
                      key={order.id}
                      className="transition-colors hover:bg-muted/50"
                    >
                      <TableCell className="py-3 font-medium whitespace-nowrap">{order.order_number}</TableCell>
                      <TableCell className="py-3 whitespace-nowrap text-muted-foreground">
                        {new Date(order.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="py-3">
                        {(order.shipping_address as any)?.full_name || order.guest_email || 'N/A'}
                      </TableCell>
                      <TableCell className="py-3 text-right tabular-nums font-medium">A${Number(order.total).toFixed(2)}</TableCell>
                      <TableCell className="py-3">
                        <Badge variant="outline" className={getPaymentColor(order.payment_status)}>
                          {formatStatusLabel(order.payment_status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="py-3">
                        <Badge variant="outline" className={getStatusColor(order.status)}>
                          {formatStatusLabel(order.status)}
                        </Badge>
                      </TableCell>



                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleViewOrder(order)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              </div>
            )}
          </CardContent>
        </Card>
        )}





        {/* Order Details Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent 
            className="max-w-2xl max-h-[90vh] overflow-y-auto"
            onPointerDownOutside={(e) => e.preventDefault()}
            onInteractOutside={(e) => e.preventDefault()}
          >
            <DialogHeader>
              <DialogTitle>Order {selectedOrder?.order_number}</DialogTitle>
            </DialogHeader>
            {selectedOrder && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Order Date</p>
                    <p className="font-medium">
                      {new Date(selectedOrder.created_at).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <select
                      value={selectedOrder.status}
                      onChange={(e) => handleStatusChange(selectedOrder.id, e.target.value as OrderStatus)}
                      onPointerDown={(e) => e.stopPropagation()}
                      className="mt-1 w-40 h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 relative z-[100] cursor-pointer"
                    >
                      {ORDER_STATUSES.map(status => (
                        <option key={status} value={status}>
                          {formatStatusLabel(status)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Payment Status</p>
                    <select
                      value={selectedOrder.payment_status}
                      onChange={(e) => handlePaymentStatusChange(selectedOrder.id, e.target.value as PaymentStatus)}
                      onPointerDown={(e) => e.stopPropagation()}
                      className="mt-1 w-40 h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 relative z-[100] cursor-pointer"
                    >
                      {PAYMENT_STATUSES.map(status => (
                        <option key={status} value={status}>
                          {formatStatusLabel(status)}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="rounded-lg border border-border p-4 space-y-2">
                  <p className="text-sm text-muted-foreground mb-1">Customer</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Name</p>
                      <p className="text-sm font-medium break-words">
                        {selectedCustomerName || (selectedOrder.shipping_address as any)?.full_name || '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Email</p>
                      <p className="text-sm font-medium break-all">
                        {selectedCustomerEmail || '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Phone</p>
                      <p className="text-sm font-medium break-all">
                        {(selectedOrder.shipping_address as any)?.phone || '—'}
                      </p>
                    </div>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground">Address</p>
                    <p className="text-sm break-words">
                      {formatAddress(selectedOrder.shipping_address) || '—'}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground">Total Orders Placed</p>
                    <p className="text-sm font-medium">
                      {getCustomerOrderCount(selectedOrder, selectedCustomerEmail)}
                    </p>
                  </div>

                  {selectedCustomerNote && (
                    <div>
                      <p className="text-xs text-muted-foreground">Notes</p>
                      <p className="text-sm whitespace-pre-wrap break-words">{selectedCustomerNote}</p>
                    </div>
                  )}
                </div>



                {getTrackingList(selectedOrder).length > 0 && (
                  <div className="p-3 border border-indigo-500/30 bg-indigo-500/5 rounded-lg">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm text-muted-foreground mb-1">
                          Tracking Number{getTrackingList(selectedOrder).length > 1 ? 's' : ''} ({(selectedOrder as any).tracking_carrier || 'AusPost'})
                        </p>
                        <ul className="space-y-1.5">
                          {getTrackingList(selectedOrder).map((tn) => (
                            <li key={tn} className="flex items-center gap-2 flex-wrap">
                              <span className="font-mono font-semibold text-sm break-all">{tn}</span>
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                aria-label={`Copy tracking number ${tn}`}
                                onClick={() => copyTracking(tn)}
                              >
                                <Copy className="h-3.5 w-3.5" />
                              </Button>
                              <a
                                href={`https://auspost.com.au/mypost/track/#/details/${encodeURIComponent(tn)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-primary underline"
                              >
                                Track ↗
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const list = getTrackingList(selectedOrder);
                          setEditTrackingInputs(list.length > 0 ? list : [""]);
                          setEditTrackingOpen(true);
                        }}
                      >
                        Edit
                      </Button>
                    </div>
                  </div>
                )}


                <div>
                  <p className="text-sm text-muted-foreground mb-2">Order Items</p>
                  <div className="space-y-3">
                    {orderItems.map((item) => (
                      <div key={item.id} className="flex items-center gap-3 p-3 border rounded-lg">
                        <img
                          src={item.product_image || '/placeholder.svg'}
                          alt={item.product_name}
                          className="h-12 w-12 rounded object-cover"
                        />
                        <div className="flex-1">
                          <p className="font-medium">{item.product_name}</p>
                          <p className="text-sm text-muted-foreground">
                            Qty: {item.quantity} × A${Number(item.unit_price).toFixed(2)}
                          </p>
                        </div>
                        <p className="font-semibold">A${Number(item.total_price).toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>A${Number(selectedOrder.subtotal).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Shipping</span>
                    <span>A${Number(selectedOrder.shipping_amount).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>A${Number(selectedOrder.total).toFixed(2)}</span>
                  </div>
                </div>

                {selectedOrder.notes && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Order Notes</p>
                    <p className="text-sm">{selectedOrder.notes}</p>
                  </div>
                )}

                {(selectedOrder.status === 'confirmed' || selectedOrder.status === 'processing' || selectedOrder.status === 'shipped') && (
                  <Button onClick={() => handlePrintSticker(selectedOrder)} className="w-full">
                    <Printer className="mr-2 h-4 w-4" />
                    Print Order Sticker
                  </Button>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Tracking numbers prompt (required before shipping) */}
        <Dialog
          open={trackingPrompt.open}
          onOpenChange={(open) => {
            if (!open && !trackingSubmitting) {
              setTrackingPrompt({ open: false, orderId: null });
              setTrackingInputs([""]);
            }
          }}
        >
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add AusPost tracking number(s)</DialogTitle>
              <DialogDescription>
                At least one tracking number is required before this order can be marked as shipped. Add more if the order ships in multiple packages.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              <Label htmlFor="tracking-number-0">AusPost tracking numbers</Label>
              {trackingInputs.map((value, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    id={`tracking-number-${index}`}
                    placeholder="e.g. AP1234567890"
                    value={value}
                    onChange={(e) => setTrackingInputs(prev => prev.map((v, i) => (i === index ? e.target.value : v)))}
                    autoFocus={index === 0}
                  />
                  {trackingInputs.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label="Remove tracking number"
                      onClick={() => setTrackingInputs(prev => prev.filter((_, i) => i !== index))}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button
                type="button"
                variant="link"
                size="sm"
                className="px-0 h-auto"
                onClick={() => setTrackingInputs(prev => [...prev, ""])}
              >
                <Plus className="h-3.5 w-3.5 mr-1" /> Add another tracking number
              </Button>
              <p className="text-xs text-muted-foreground">10–35 letters/numbers each. No spaces. Blank fields are ignored.</p>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setTrackingPrompt({ open: false, orderId: null });
                  setTrackingInputs([""]);
                }}
                disabled={trackingSubmitting}
              >
                Cancel
              </Button>
              <Button onClick={confirmTrackingAndShip} disabled={trackingSubmitting || !trackingFieldsValid(trackingInputs)}>
                {trackingSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Confirm & Mark Shipped'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit tracking numbers */}
        <Dialog open={editTrackingOpen} onOpenChange={setEditTrackingOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit tracking numbers</DialogTitle>
              <DialogDescription>
                Updating tracking numbers will not re-send the shipped email automatically.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              <Label htmlFor="edit-tracking-number-0">AusPost tracking numbers</Label>
              {editTrackingInputs.map((value, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    id={`edit-tracking-number-${index}`}
                    placeholder="e.g. AP1234567890"
                    value={value}
                    onChange={(e) => setEditTrackingInputs(prev => prev.map((v, i) => (i === index ? e.target.value : v)))}
                    autoFocus={index === 0}
                  />
                  {editTrackingInputs.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label="Remove tracking number"
                      onClick={() => setEditTrackingInputs(prev => prev.filter((_, i) => i !== index))}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button
                type="button"
                variant="link"
                size="sm"
                className="px-0 h-auto"
                onClick={() => setEditTrackingInputs(prev => [...prev, ""])}
              >
                <Plus className="h-3.5 w-3.5 mr-1" /> Add another tracking number
              </Button>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditTrackingOpen(false)}>Cancel</Button>
              <Button onClick={saveEditedTracking} disabled={!trackingFieldsValid(editTrackingInputs)}>
                Save
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>

  );
};

export default AdminOrders;
