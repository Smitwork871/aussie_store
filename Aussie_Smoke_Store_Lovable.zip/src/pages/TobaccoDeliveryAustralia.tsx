import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight, Truck, Shield, Clock } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'How fast is tobacco delivery in Australia?', answer: 'Aussie Smoke Store processes orders within 1-3 business days. Delivery takes 3-7 business days depending on your location. Express options available for major cities.' },
  { question: 'Do you deliver tobacco to all Australian states?', answer: 'Yes! We deliver to NSW, VIC, QLD, WA, SA, TAS, NT and ACT — every state and territory including regional and remote areas.' },
  { question: 'Is tobacco delivery discreet?', answer: 'Absolutely. All orders are shipped in plain, unmarked packaging with no indication of contents for your privacy.' },
  { question: 'What is the free shipping threshold?', answer: 'Free shipping applies to all orders over A$50. Orders under A$50 incur a flat delivery fee of A$10.' },
  { question: 'Can I track my tobacco delivery?', answer: 'Yes, you\'ll receive tracking information via email once your order is dispatched so you can monitor delivery progress.' },
];

const TobaccoDeliveryAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Tobacco Delivery Australia — Fast & Discreet"
        description="Fast tobacco delivery across Australia. Cigarettes, rolling tobacco, vapes & nicotine pouches delivered to your door. Free shipping over A$50. Discreet packaging."
        canonical="/tobacco-delivery-australia"
        keywords="tobacco delivery Australia, cigarette delivery Australia, tobacco shipping Australia, buy tobacco online delivery, fast tobacco delivery, discreet tobacco delivery Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Tobacco Delivery Australia', url: '/tobacco-delivery-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Tobacco Delivery Australia
              <span className="text-primary block mt-2">Fast &amp; Discreet Shipping</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Get <strong>tobacco delivered to your door</strong> anywhere in Australia. Cigarettes, rolling tobacco, vapes &amp; nicotine pouches — all with <strong>free shipping over A$50</strong> and discreet packaging.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Delivery Features */}
      <section className="border-y bg-secondary/30 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center gap-3 justify-center">
              <Truck className="h-8 w-8 text-primary" />
              <div>
                <p className="font-semibold">Australia-Wide Delivery</p>
                <p className="text-sm text-muted-foreground">All states &amp; territories</p>
              </div>
            </div>
            <div className="flex items-center gap-3 justify-center">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <p className="font-semibold">Discreet Packaging</p>
                <p className="text-sm text-muted-foreground">Plain, unmarked boxes</p>
              </div>
            </div>
            <div className="flex items-center gap-3 justify-center">
              <Clock className="h-8 w-8 text-primary" />
              <div>
                <p className="font-semibold">3-7 Day Delivery</p>
                <p className="text-sm text-muted-foreground">Fast processing</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Australia-Wide Tobacco Delivery Service</h2>
            <p>
              Aussie Smoke Store provides fast, reliable <strong>tobacco delivery across Australia</strong>. Whether you're in Sydney, Melbourne, Brisbane, Perth, Adelaide, Gold Coast, Hobart, Darwin, or Canberra — we deliver cigarettes, rolling tobacco, vapes, nicotine pouches and accessories right to your door.
            </p>
            <h3>Delivery Areas We Cover</h3>
            <p>We deliver to every Australian state and territory:</p>
            <ul>
              <li><strong>New South Wales</strong> — Sydney, Newcastle, Wollongong, Central Coast</li>
              <li><strong>Victoria</strong> — Melbourne, Geelong, Ballarat, Bendigo</li>
              <li><strong>Queensland</strong> — Brisbane, Gold Coast, Sunshine Coast, Cairns, Townsville</li>
              <li><strong>Western Australia</strong> — Perth, Bunbury, Geraldton</li>
              <li><strong>South Australia</strong> — Adelaide, Mount Gambier</li>
              <li><strong>Tasmania</strong> — Hobart, Launceston</li>
              <li><strong>Northern Territory</strong> — Darwin, Alice Springs</li>
              <li><strong>ACT</strong> — Canberra</li>
            </ul>
            <h3>How Our Tobacco Delivery Works</h3>
            <ol>
              <li>Browse and select your products</li>
              <li>Add to cart and complete checkout</li>
              <li>We process your order within 1-3 business days</li>
              <li>Receive tracking details via email</li>
              <li>Your tobacco products arrive in discreet packaging</li>
            </ol>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
            <Link to="/nicotine-pouches-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Nicotine Pouches</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Shop Tobacco Products for Delivery</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Tobacco Delivery FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default TobaccoDeliveryAustralia;
