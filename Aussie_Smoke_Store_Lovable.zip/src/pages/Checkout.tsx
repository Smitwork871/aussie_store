import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { FreeShippingBanner } from '@/components/FreeShippingBanner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, Tag, X, Check } from 'lucide-react';
import { Tables } from '@/integrations/supabase/types';
import { imgSize } from '@/lib/imageUtils';
import { TrustStrip } from '@/components/TrustStrip';
import { SEOHead } from '@/components/SEOHead';
import { z } from 'zod';

const FREE_SHIPPING_THRESHOLD = 50;

const checkoutSchema = z.object({
  fullName: z.string().trim().min(2, 'Name must be at least 2 characters').max(100, 'Name too long'),
  email: z.string().trim().email('Invalid email address').max(255, 'Email too long'),
  phone: z.string().trim().min(8, 'Phone number too short').max(20, 'Phone number too long'),
  addressLine1: z.string().trim().min(3, 'Address too short').max(200, 'Address too long'),
  addressLine2: z.string().max(200, 'Address too long').optional().or(z.literal('')),
  city: z.string().trim().min(2, 'City too short').max(100, 'City too long'),
  state: z.string().trim().min(2, 'State too short').max(100, 'State too long'),
  postalCode: z.string().trim().min(3, 'Postal code too short').max(10, 'Postal code too long'),
  notes: z.string().max(500, 'Notes must be under 500 characters').optional().or(z.literal('')),
});


type Coupon = {
  id: string;
  code: string;
  description: string | null;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  min_order_amount: number | null;
  max_discount_amount: number | null;
};

interface AppliedCoupon {
  coupon: Coupon;
  discountAmount: number;
}

const Checkout = () => {
  const navigate = useNavigate();
  const { items, subtotal, clearCart, isLoading: cartLoading } = useCart();
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('bank_transfer');
  const [couponCode, setCouponCode] = useState('');
  const [isValidatingCoupon, setIsValidatingCoupon] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<AppliedCoupon | null>(null);
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    notes: '',
  });

  const abandonRecordedRef = useRef(false);

  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : 10;
  const discountAmount = appliedCoupon?.discountAmount || 0;
  const total = Math.max(0, subtotal + shipping - discountAmount);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Capture abandoned cart when shopper enters a valid email
  const recordAbandonedCart = async () => {
    if (abandonRecordedRef.current) return;
    const emailCheck = z.string().trim().email().safeParse(formData.email);
    if (!emailCheck.success || items.length === 0) return;
    abandonRecordedRef.current = true;
    try {
      await supabase.from('abandoned_carts').insert({
        email: emailCheck.data.toLowerCase(),
        user_id: user?.id || null,
        cart_snapshot: items.map((i) => ({
          product_id: i.product_id,
          name: i.product.name,
          slug: i.product.slug,
          price: i.product.price,
          quantity: i.quantity,
          image: i.product.images?.[0] || null,
        })),
        subtotal,
      });
    } catch {
      // non-blocking
    }
  };

  const calculateDiscount = (coupon: Coupon, orderSubtotal: number): number => {
    let discount = 0;
    
    if (coupon.discount_type === 'percentage') {
      discount = (orderSubtotal * Number(coupon.discount_value)) / 100;
      // Apply max discount cap if set
      if (coupon.max_discount_amount && discount > Number(coupon.max_discount_amount)) {
        discount = Number(coupon.max_discount_amount);
      }
    } else {
      // Fixed amount discount
      discount = Number(coupon.discount_value);
    }
    
    // Don't exceed the subtotal
    return Math.min(discount, orderSubtotal);
  };

  const validateCoupon = async () => {
    const code = couponCode.trim().toUpperCase();
    if (!code) {
      toast.error('Please enter a coupon code');
      return;
    }

    setIsValidatingCoupon(true);

    try {
      // Validate coupon via secure RPC (does not expose full coupon table)
      const { data, error } = await supabase
        .rpc('validate_coupon', { p_code: code, p_subtotal: subtotal });

      const coupon = Array.isArray(data) ? data[0] : null;
      if (error || !coupon) {
        toast.error('Invalid or expired coupon code');
        return;
      }

      // Calculate discount
      const discountAmount = calculateDiscount(coupon as Coupon, subtotal);

      setAppliedCoupon({ coupon: coupon as Coupon, discountAmount });
      setCouponCode('');
      toast.success(`Coupon applied! You save A$${discountAmount.toFixed(2)}`);
    } catch (error) {
      toast.error('Failed to validate coupon');
    } finally {
      setIsValidatingCoupon(false);
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    toast.success('Coupon removed');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (items.length === 0) {
      toast.error('Your cart is empty');
      return;
    }

    // Validate form data with zod
    const validation = checkoutSchema.safeParse(formData);
    if (!validation.success) {
      toast.error(validation.error.issues[0].message);
      return;
    }

    setIsSubmitting(true);

    try {
      // Place order atomically via secure RPC (handles order + items + coupon)
      const { data: rpcData, error: orderError } = await supabase.rpc('place_order', {
        p_guest_email: formData.email,
        p_payment_method: paymentMethod,
        p_shipping_amount: shipping,
        p_discount_amount: discountAmount,
        p_shipping_address: {
          full_name: formData.fullName,
          phone: formData.phone,
          address_line1: formData.addressLine1,
          address_line2: formData.addressLine2,
          city: formData.city,
          state: formData.state,
          postal_code: formData.postalCode,
          country: 'Australia',
        },
        p_notes: formData.notes || null,
        p_items: items.map((i) => ({ product_id: i.product_id, quantity: i.quantity })),
        p_coupon_id: appliedCoupon?.coupon.id || null,
      });

      if (orderError) throw orderError;
      const result = Array.isArray(rpcData) ? rpcData[0] : rpcData;
      if (!result?.order_id) throw new Error('Order creation failed');

      const orderId: string = result.order_id;
      const verificationToken: string | null = result.verification_token || null;

      // Set verification token in this client session so subsequent guest reads work
      if (verificationToken) {
        await supabase.rpc('set_verification_token', { token: verificationToken });
      }

      // Record attribution (UTM + referrer) - non-blocking
      try {
        const url = new URL(window.location.href);
        const recoveryToken = sessionStorage.getItem('recovery_token');
        await supabase.rpc('record_order_attribution', {
          p_order_id: orderId,
          p_token: verificationToken,
          p_source: url.searchParams.get('utm_source') || (recoveryToken ? 'abandoned_cart_recovery' : (document.referrer ? new URL(document.referrer).hostname : 'direct')),
          p_medium: url.searchParams.get('utm_medium') || (recoveryToken ? 'email' : null),
          p_campaign: url.searchParams.get('utm_campaign'),
          p_referrer: document.referrer || null,
          p_landing_page: sessionStorage.getItem('landing_page'),
          p_recovery_token: recoveryToken,
        });
        if (recoveryToken) sessionStorage.removeItem('recovery_token');
      } catch (e) {
        console.warn('Attribution insert failed:', e);
      }

      // Clear cart
      await clearCart();

      // Send confirmation email (fire-and-forget)
      supabase.functions.invoke('send-order-email', {
        body: { order_id: orderId, email_type: 'confirmation', ...(verificationToken ? { verification_token: verificationToken } : {}) },
      }).catch((err) => console.warn('Confirmation email failed:', err));

      toast.success('Order placed successfully.');
      const confirmationUrl = verificationToken
        ? `/order-confirmation/${orderId}?token=${verificationToken}`
        : `/order-confirmation/${orderId}`;
      navigate(confirmationUrl);
    } catch (error: any) {
      toast.error(error.message || 'Failed to place order');
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    if (!cartLoading && !isSubmitting && items.length === 0) {
      navigate('/cart', { replace: true });
    }
  }, [cartLoading, isSubmitting, items.length, navigate]);

  if (items.length === 0) {
    return null;
  }

  return (
    <Layout>
      <SEOHead title="Checkout" canonical="/checkout" noindex />
      <div className="container py-6 sm:py-8 pb-24 lg:pb-8">
        <h1 className="text-2xl sm:text-3xl font-bold mb-3">Checkout</h1>
        <FreeShippingBanner className="mb-5" />


        {/* Mobile-only top summary */}
        <div className="lg:hidden mb-4 rounded-lg border bg-card px-4 py-3 flex items-center justify-between">
          <span className="text-sm text-muted-foreground">{items.reduce((s, i) => s + i.quantity, 0)} items</span>
          <span className="text-lg font-bold text-primary">A${total.toFixed(2)}</span>
        </div>

        <TrustStrip variant="compact" className="mb-4 justify-center" />

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Shipping Info */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Shipping Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        autoComplete="name"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        inputMode="tel"
                        autoComplete="tel"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        inputMode="email"
                        autoComplete="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        onBlur={recordAbandonedCart}
                        required
                        placeholder="We'll send your order confirmation here"
                      />
                    </div>
                  <div className="space-y-2">
                    <Label htmlFor="addressLine1">Address Line 1 *</Label>
                    <Input
                      id="addressLine1"
                      name="addressLine1"
                      autoComplete="address-line1"
                      value={formData.addressLine1}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="addressLine2">Address Line 2</Label>
                    <Input
                      id="addressLine2"
                      name="addressLine2"
                      autoComplete="address-line2"
                      value={formData.addressLine2}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="grid sm:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City *</Label>
                      <Input
                        id="city"
                        name="city"
                        autoComplete="address-level2"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">State *</Label>
                      <Input
                        id="state"
                        name="state"
                        autoComplete="address-level1"
                        value={formData.state}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="postalCode">Postal Code *</Label>
                      <Input
                        id="postalCode"
                        name="postalCode"
                        inputMode="numeric"
                        autoComplete="postal-code"
                        value={formData.postalCode}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Order Notes</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      placeholder="Any special instructions for delivery..."
                      value={formData.notes}
                      onChange={handleInputChange}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Payment Instructions (bank details revealed after order placement) */}
              <Card className="border-primary/30 bg-primary/5">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Payment: Bank Transfer</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    Once you place your order, we'll show you a <span className="font-semibold text-foreground">unique reference code</span> and our bank account details on the confirmation page, and email them to you.
                  </p>
                  <p>
                    Please add that reference code as the description on your bank transfer and pay the exact order total — this lets us match your payment quickly and dispatch your order.
                  </p>
                </CardContent>
              </Card>
            </div>



            {/* Order Summary */}
            <div>
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <img
                        src={imgSize.cartItem(item.product.images?.[0])}
                        alt={item.product.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm line-clamp-1">{item.product.name}</p>
                        <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                        <p className="text-sm font-medium">A${(item.product.price * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                  
                  <Separator />

                  {/* Coupon Code Section */}
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Tag className="h-4 w-4" />
                      Discount Code
                    </Label>
                    
                    {appliedCoupon ? (
                      <div className="flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg">
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-primary" />
                          <span className="font-medium text-sm">{appliedCoupon.coupon.code}</span>
                          <span className="text-xs text-muted-foreground">
                            (-A${appliedCoupon.discountAmount.toFixed(2)})
                          </span>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={removeCoupon}
                          className="h-8 w-8 p-0"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <Input
                          placeholder="Enter code"
                          value={couponCode}
                          onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                          className="flex-1"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={validateCoupon}
                          disabled={isValidatingCoupon || !couponCode.trim()}
                        >
                          {isValidatingCoupon ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            'Apply'
                          )}
                        </Button>
                      </div>
                    )}
                  </div>

                  <Separator />
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>A${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Shipping</span>
                      <span>{shipping === 0 ? 'Free' : `A$${shipping.toFixed(2)}`}</span>
                    </div>
                    {discountAmount > 0 && (
                      <div className="flex justify-between text-sm text-primary">
                        <span>Discount</span>
                        <span>-A${discountAmount.toFixed(2)}</span>
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total</span>
                      <span className="text-primary">A${total.toFixed(2)}</span>
                    </div>
                  </div>
                  <Button type="submit" className="w-full hidden lg:flex" size="lg" disabled={isSubmitting}>
                    {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Place Order
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Sticky mobile place-order button */}
          <div className="lg:hidden fixed bottom-0 inset-x-0 z-40 border-t bg-background/95 backdrop-blur px-4 py-3 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <div className="text-xs text-muted-foreground">Total</div>
                <div className="text-lg font-bold text-primary leading-tight">A${total.toFixed(2)}</div>
              </div>
              <Button type="submit" size="lg" disabled={isSubmitting} className="flex-1">
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Place Order
              </Button>
            </div>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default Checkout;
