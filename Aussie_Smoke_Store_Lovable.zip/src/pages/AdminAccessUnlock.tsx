import { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { SEOHead } from '@/components/SEOHead';

const AdminAccessUnlock = () => {
  useEffect(() => {
    try {
      localStorage.setItem('maintenance_bypass', 'true');
    } catch {
      // ignore
    }
  }, []);

  return (
    <>
      <SEOHead title="Admin Access" noindex />
      <Navigate to="/login" replace />
    </>
  );
};

export default AdminAccessUnlock;

export const AdminAccessLock = () => {
  useEffect(() => {
    try {
      localStorage.removeItem('maintenance_bypass');
    } catch {
      // ignore
    }
  }, []);
  return (
    <>
      <SEOHead title="Admin Access Lock" noindex />
      <Navigate to="/" replace />
    </>
  );
};
