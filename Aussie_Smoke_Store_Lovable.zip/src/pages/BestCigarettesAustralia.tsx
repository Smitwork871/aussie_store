import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What are the best cigarettes to buy online in Australia?', answer: 'Aussie Smoke Store stocks Australia\'s most popular cigarette brands including Marlboro, Manchester, Winfield, Peter Stuyvesant, Camel, and Dunhill — all at the cheapest online prices with free shipping over A$50.' },
  { question: 'Which cigarette brands are cheapest in Australia?', answer: 'Manchester cigarettes are among the most affordable, followed by Peter Stuyvesant and Winfield. Aussie Smoke Store offers all major brands at wholesale-style prices online.' },
  { question: 'Can I buy premium cigarettes online in Australia?', answer: 'Yes! We stock premium brands like Marlboro Red, Marlboro Gold, Dunhill, and Camel alongside budget-friendly options. All delivered discreetly Australia-wide.' },
  { question: 'How do I choose the best cigarettes for me?', answer: 'It depends on your taste — full-flavour smokers love Marlboro Red and Manchester Red, while lighter options include Marlboro Gold and Manchester Lights. Browse our range and read product descriptions for guidance.' },
];

const BestCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Best Cigarettes Australia — Top Brands"
        description="Discover the best cigarettes in Australia at the cheapest prices. Marlboro, Manchester, Winfield, Dunhill & more. Free shipping over A$50. Shop Aussie Smoke Store."
        canonical="/best-cigarettes-australia"
        keywords="best cigarettes Australia, best cigarettes online Australia, top cigarette brands Australia, cheapest cigarettes Australia, best smokes Australia, popular cigarettes Australia, Marlboro Australia, Manchester cigarettes Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Best Cigarettes Australia', url: '/best-cigarettes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Best Cigarettes in Australia
              <span className="text-primary block mt-2">Top Brands, Lowest Prices</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Find the <strong>best cigarettes in Australia</strong> from premium and budget brands. All at the <strong>cheapest prices online</strong> with free shipping over A$50.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Shop All Cigarettes <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-cigarettes-online">Cheap Cigarettes Online</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Australia's Best Cigarette Brands Online</h2>
            <p>
              Looking for the <strong>best cigarettes in Australia</strong>? Aussie Smoke Store stocks every major brand at prices far below retail. Whether you prefer full-flavour, lights, or menthol, we have the perfect cigarette for you.
            </p>
            <h3>Our Top Cigarette Brands</h3>
            <ul>
              <li><strong>Marlboro</strong> — The world's #1 cigarette. Red, Gold, and Swiss editions available</li>
              <li><strong>Manchester</strong> — Premium quality at unbeatable prices. Red, Lights, Sapphire Blue, Royal Red, Special Edition</li>
              <li><strong>Winfield</strong> — An Australian classic loved for decades</li>
              <li><strong>Peter Stuyvesant</strong> — Smooth, refined taste at affordable prices</li>
              <li><strong>Camel</strong> — Rich Turkish blend for the discerning smoker</li>
              <li><strong>Dunhill</strong> — Premium cigarettes for those who appreciate quality</li>
            </ul>
            <h3>Why Buy Cigarettes from Aussie Smoke Store?</h3>
            <p>
              We offer the <strong>best cigarettes at the cheapest prices</strong> in Australia. Bulk discounts, <strong>free shipping over A$50</strong>, and discreet delivery to every Australian postcode — metro, regional, and remote.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes Online</Link>
            <Link to="/buy-cigarettes-online-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Buy Cigarettes Australia</Link>
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/discount-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Discount Tobacco Online</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Best Selling Cigarettes in Australia</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions — Best Cigarettes Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BestCigarettesAustralia;
