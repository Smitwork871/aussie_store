import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap darts online in Australia?', answer: 'Aussie Smoke Store is Australia\'s top online shop for cheap darts. We stock all major cigarette brands at the lowest prices with free shipping on orders over A$50.' },
  { question: 'What does "darts" mean in Australia?', answer: 'In Australian slang, "darts" refers to cigarettes. At Aussie Smoke Store, we sell cheap darts (cigarettes) from top brands like Marlboro, Manchester, Benson & Hedges and more.' },
  { question: 'Are cheap darts the same quality as retail cigarettes?', answer: 'Yes! All our darts are genuine, brand-name cigarettes sourced from authorised distributors. You get the exact same product at a much cheaper price.' },
  { question: 'How fast do you deliver darts Australia-wide?', answer: 'We process orders within 1-3 business days. Delivery takes 3-7 business days depending on your location in Australia. Free shipping on orders over A$50.' },
];

const CheapDartsOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Darts Online Australia — Buy Cigarettes at Best Prices"
        description="Buy cheap darts online in Australia. Cheapest cigarettes (darts) from Marlboro, Manchester & more. Free shipping over A$50. Australia's #1 online dart shop."
        canonical="/cheap-darts-online"
        keywords="cheap darts, cheap darts online, cheap darts Australia, buy darts online Australia, darts online Australia, cheap cigarettes darts, cheapest darts Australia, darts delivery Australia"
        jsonLd={[
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Darts Online', url: '/cheap-darts-online' }]),
          faqJsonLd(FAQS),
          localBusinessJsonLd(),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16">
        <div className="container max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-center">
            Cheap Darts Online Australia
          </h1>
          <p className="text-lg text-muted-foreground text-center mb-8 max-w-2xl mx-auto">
            Looking for <strong>cheap darts online</strong>? Aussie Smoke Store is Australia's favourite online cigarette shop. Buy <strong>cheap darts</strong> (cigarettes) from top brands at unbeatable prices with free Australia-wide shipping on orders over A$50.
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" asChild>
              <Link to="/products">Shop All Darts <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8 text-center">Cheapest Darts in Australia</h2>
          <ProductGrid products={products} isLoading={isLoading} />
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">Buy Cheap Darts Online — Why Aussie Smoke Store?</h2>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
            <p>If you're searching for <strong>cheap darts online in Australia</strong>, you've come to the right place. "Darts" is the iconic Aussie slang for cigarettes, and at Aussie Smoke Store we've made it our mission to offer the <strong>cheapest darts</strong> available anywhere online.</p>
            <p>We stock all the brands Australians love — <strong>Marlboro</strong>, <strong>Manchester</strong>, <strong>Benson &amp; Hedges</strong>, <strong>Peter Jackson</strong>, <strong>Winfield</strong> and many more. Every packet is genuine, factory-sealed, and delivered discreetly to your door anywhere in Australia.</p>
            <p>Whether you're in <Link to="/cheap-smokes-sydney" className="text-primary hover:underline">Sydney</Link>, <Link to="/cheap-smokes-melbourne" className="text-primary hover:underline">Melbourne</Link>, <Link to="/cheap-smokes-brisbane" className="text-primary hover:underline">Brisbane</Link>, <Link to="/cheap-smokes-perth" className="text-primary hover:underline">Perth</Link>, or regional Australia — we deliver cheap darts right to your doorstep with <strong>free shipping on orders over A$50</strong>.</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">Frequently Asked Questions — Cheap Darts Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl text-center">
          <h2 className="text-2xl font-bold mb-4">Related Searches</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/cheap-smokes-online" className="text-primary hover:underline">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="text-primary hover:underline">Cheap Cigarettes Online</Link>
            <Link to="/cheap-durries-online" className="text-primary hover:underline">Cheap Durries Online</Link>
            <Link to="/buy-cigarettes-online-australia" className="text-primary hover:underline">Buy Cigarettes Online Australia</Link>
            <Link to="/discount-tobacco-online" className="text-primary hover:underline">Discount Tobacco Online</Link>
            <Link to="/cheapest-cigarettes-australia" className="text-primary hover:underline">Cheapest Cigarettes Australia</Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapDartsOnline;
