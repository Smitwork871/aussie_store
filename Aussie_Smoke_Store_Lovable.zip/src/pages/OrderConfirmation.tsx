import React, { useEffect, useState } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { Order, OrderItem } from '@/types/database';
import { CheckCircle, Package, ArrowRight, ShieldX } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { ReorderButton } from '@/components/ReorderButton';
import BankDetailsCard from '@/components/checkout/BankDetailsCard';
import { SEOHead } from '@/components/SEOHead';

const OrderConfirmation = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const [order, setOrder] = useState<Order | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [accessDenied, setAccessDenied] = useState(false);

  useEffect(() => {
    const fetchOrder = async () => {
      if (!orderId) return;

      const verificationToken = searchParams.get('token');

      // Single round-trip: SECURITY DEFINER RPC validates ownership / admin / guest token
      // and returns the order plus its items atomically.
      const { data, error } = await supabase.rpc('get_order_with_items', {
        p_order_id: orderId,
        p_token: verificationToken,
      });

      if (error || !data) {
        setAccessDenied(true);
        setIsLoading(false);
        return;
      }

      const payload = data as unknown as { order: Order; items: OrderItem[] } | null;
      if (!payload || !payload.order) {
        setAccessDenied(true);
        setIsLoading(false);
        return;
      }

      setOrder(payload.order);
      setOrderItems(payload.items || []);
      setIsLoading(false);
    };

    fetchOrder();
  }, [orderId, searchParams, user]);

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-16">
          <div className="animate-pulse space-y-4 max-w-2xl mx-auto">
            <div className="h-16 bg-secondary rounded-lg" />
            <div className="h-48 bg-secondary rounded-lg" />
          </div>
        </div>
      </Layout>
    );
  }

  if (accessDenied) {
    return (
      <Layout>
        <SEOHead title="Access Denied" noindex />
        <div className="container py-16 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-destructive/10 mb-4">
            <ShieldX className="h-8 w-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-muted-foreground mb-6">
            You don't have permission to view this order. Please check your order confirmation email for the correct link.
          </p>
          <Button asChild>
            <Link to="/">Go Home</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  if (!order) {
    return (
      <Layout>
        <SEOHead title="Order Not Found" noindex />
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Order not found</h1>
          <Button asChild>
            <Link to="/">Go Home</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const shippingAddress = order.shipping_address as any;

  return (
    <Layout>
      <SEOHead title="Order Confirmation" noindex />
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* Success Message */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-success/10 mb-4">
              <CheckCircle className="h-8 w-8 text-success" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
            <p className="text-muted-foreground">
              Thank you for your order. Please use your 6-digit reference code <span className="font-bold text-primary text-lg">{order.order_number}</span> as the description when making your bank transfer.
            </p>
          </div>

          {/* Order Details */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Order Details</CardTitle>
                <Badge variant="secondary">{order.status}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Reference Code</p>
                  <p className="font-mono font-bold text-xl text-primary">{order.order_number}</p>
                  <p className="text-xs text-muted-foreground mt-1">Use this as your bank transfer reference</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Date</p>
                  <p className="font-medium">
                    {new Date(order.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Payment Method</p>
                  <p className="font-medium capitalize">{order.payment_method}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Payment Status</p>
                  <Badge variant={order.payment_status === 'paid' ? 'default' : 'secondary'}>
                    {order.payment_status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Bank Transfer Details — only shown to authorized order viewer */}
          {order.payment_status !== 'paid' && (
            <div className="mb-6">
              <BankDetailsCard orderNumber={order.order_number} amount={Number(order.total)} />
            </div>
          )}

          {/* Items */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Order Items
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {orderItems.map((item) => (
                <div key={item.id} className="flex gap-4">
                  <img
                    src={item.product_image || '/placeholder.svg'}
                    alt={item.product_name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div className="flex-1">
                    <p className="font-medium">{item.product_name}</p>
                    <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                  </div>
                  <p className="font-medium">A${item.total_price.toFixed(2)}</p>
                </div>
              ))}
              <Separator />
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>A${order.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>{order.shipping_amount === 0 ? 'Free' : `A$${order.shipping_amount.toFixed(2)}`}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span className="text-primary">A${order.total.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Shipping Address */}
          {shippingAddress && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Shipping Address</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-medium">{shippingAddress.full_name}</p>
                <p className="text-muted-foreground">
                  {shippingAddress.address_line1}
                  {shippingAddress.address_line2 && <>, {shippingAddress.address_line2}</>}
                </p>
                <p className="text-muted-foreground">
                  {shippingAddress.city}, {shippingAddress.state} {shippingAddress.postal_code}
                </p>
                <p className="text-muted-foreground">{shippingAddress.country}</p>
                {shippingAddress.phone && (
                  <p className="text-muted-foreground mt-2">Phone: {shippingAddress.phone}</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4">
            <ReorderButton items={orderItems} className="flex-1" />
            <Button variant="outline" asChild className="flex-1">
              <Link to="/products">
                Continue Shopping <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" asChild className="flex-1">
              <Link to="/profile">View All Orders</Link>
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default OrderConfirmation;
