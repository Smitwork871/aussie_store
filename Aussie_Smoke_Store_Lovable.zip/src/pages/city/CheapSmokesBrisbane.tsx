import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Brisbane?', answer: 'Yes! Aussie Smoke Store delivers cigarettes across all Brisbane suburbs and South East Queensland — from the CBD to Logan, Ipswich, Redcliffe, and the Gold Coast.' },
  { question: 'How fast is cigarette delivery in Brisbane?', answer: 'Brisbane orders typically arrive within 3-5 business days. Free shipping on orders over A$50.' },
  { question: 'Are your prices cheaper than Brisbane tobacconists?', answer: 'Yes, significantly. Our online prices are well below what Brisbane tobacco shops charge. You\'ll save on every purchase.' },
  { question: 'Do you deliver to the Gold Coast and Sunshine Coast?', answer: 'Absolutely! We deliver to the Gold Coast, Sunshine Coast, Toowoomba, and all of Queensland.' },
];

const CheapSmokesBrisbane = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Brisbane — Cigarettes Online"
        description="Buy cheap smokes and cigarettes online in Brisbane. Lowest prices on tobacco, vapes & accessories. Fast Brisbane & QLD delivery. Free shipping over A$50."
        canonical="/cheap-smokes-brisbane"
        keywords="cheap smokes Brisbane, buy cigarettes online Brisbane, cheap cigarettes Brisbane, tobacco delivery Brisbane, cigarettes online Brisbane, tobacconist Brisbane online, buy smokes Brisbane, cheap tobacco Brisbane, Gold Coast cigarettes"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Brisbane', url: '/cheap-smokes-brisbane' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Brisbane
              <span className="text-primary block mt-2">Buy Cigarettes Online — Brisbane &amp; QLD Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in Brisbane</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered anywhere in Brisbane and Queensland.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Brisbane</h2>
            <p>
              Brisbane and South East Queensland smokers can now skip expensive tobacconists. <strong>Buy cigarettes online in Brisbane</strong> from Aussie Smoke Store at prices you won't find in any local shop — delivered to Fortitude Valley, South Bank, Chermside, Carindale, Mt Gravatt, and beyond.
            </p>
            <h3>Why Brisbane &amp; QLD Smokers Choose Us</h3>
            <ul>
              <li><strong>Unbeatable prices</strong> — cheaper than any Brisbane tobacconist</li>
              <li><strong>Brisbane &amp; QLD-wide delivery</strong> — CBD, northside, southside, Gold Coast, Sunshine Coast</li>
              <li><strong>Top brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet packaging</strong> — plain parcels for your privacy</li>
            </ul>
            <h3>Brisbane Areas We Deliver To</h3>
            <p>
              We deliver to every Brisbane and QLD postcode — Toowong, Woolloongabba, Nundah, Stafford, Inala, Springfield, Logan, Ipswich, Redcliffe, Caboolture, Gold Coast, and Sunshine Coast.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-sydney" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Sydney</Link>
            <Link to="/cheap-smokes-melbourne" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Melbourne</Link>
            <Link to="/cheap-smokes-perth" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Perth</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Brisbane</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Brisbane</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesBrisbane;
