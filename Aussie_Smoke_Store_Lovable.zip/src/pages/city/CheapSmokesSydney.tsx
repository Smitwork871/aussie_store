import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Sydney?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes, tobacco, and vapes directly to your door across all Sydney suburbs — from the CBD to Western Sydney, North Shore, and the Eastern Suburbs.' },
  { question: 'How long does cigarette delivery take in Sydney?', answer: 'Sydney orders are typically delivered within 3-5 business days. Orders over A$50 qualify for free shipping.' },
  { question: 'Is it cheaper to buy cigarettes online than at a Sydney tobacconist?', answer: 'Absolutely. Our online prices are significantly lower than Sydney retail shops. You\'ll save on every pack and carton compared to local tobacconists.' },
  { question: 'What cigarette brands can I buy online in Sydney?', answer: 'We stock Marlboro, Manchester, Bond Street, Peter Jackson, and many more popular brands — all at the cheapest prices in Australia.' },
];

const CheapSmokesSydney = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Sydney — Buy Cigarettes Online Sydney Delivery"
        description="Buy cheap smokes and cigarettes online in Sydney. Cheapest prices on Marlboro, tobacco, vapes & more. Fast Sydney delivery. Free shipping over A$50."
        canonical="/cheap-smokes-sydney"
        keywords="cheap smokes Sydney, buy cigarettes online Sydney, cheap cigarettes Sydney, tobacco delivery Sydney, cigarettes online Sydney, tobacconist Sydney online, buy smokes Sydney, cheap tobacco Sydney"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Sydney', url: '/cheap-smokes-sydney' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Sydney
              <span className="text-primary block mt-2">Buy Cigarettes Online — Sydney Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in Sydney</strong>? Aussie Smoke Store delivers the cheapest cigarettes, rolling tobacco &amp; vapes to every Sydney suburb. Save big vs retail prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Sydney</h2>
            <p>
              Sydney smokers are paying some of the highest prices in Australia at local tobacconists. With Aussie Smoke Store, you can <strong>buy cigarettes online in Sydney</strong> at a fraction of the retail cost — delivered discreetly to your door across all Sydney areas including Parramatta, Bondi, Manly, Liverpool, Penrith, and the Inner West.
            </p>
            <h3>Why Sydney Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Cheapest prices in Australia</strong> — far below Sydney retail</li>
              <li><strong>Sydney-wide delivery</strong> — CBD, Western Sydney, North Shore, Eastern Suburbs</li>
              <li><strong>Huge selection</strong> — Marlboro, Manchester, rolling tobacco, vapes &amp; more</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet packaging</strong> — plain parcels for your privacy</li>
            </ul>
            <h3>Popular Sydney Suburbs We Deliver To</h3>
            <p>
              We deliver to every Sydney postcode — Surry Hills, Newtown, Chatswood, Hurstville, Blacktown, Campbelltown, Cronulla, Hornsby, Dee Why, Bankstown, Strathfield, and hundreds more.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-melbourne" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Melbourne</Link>
            <Link to="/cheap-smokes-brisbane" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Brisbane</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Sydney</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Sydney</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesSydney;
