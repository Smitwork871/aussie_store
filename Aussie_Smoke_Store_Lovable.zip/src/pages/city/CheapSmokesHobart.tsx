import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Hobart?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes across Tasmania — Hobart CBD, Sandy Bay, Glenorchy, Kingston, and all surrounding areas.' },
  { question: 'How long does cigarette delivery take to Hobart?', answer: 'Hobart orders typically arrive within 5-7 business days. Free shipping on orders over A$50.' },
  { question: 'Do you deliver to all of Tasmania?', answer: 'Yes! We deliver to Hobart, Launceston, Devonport, Burnie, and all regional Tasmania.' },
  { question: 'Are online cigarette prices cheaper than Hobart shops?', answer: 'Much cheaper. Tasmania has very high retail tobacco prices — our online prices save you significantly on every purchase.' },
];

const CheapSmokesHobart = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Hobart — Cigarettes Online"
        description="Buy cheap smokes and cigarettes online in Hobart. Lowest prices on tobacco, vapes & accessories. Tasmania-wide delivery. Free shipping over A$50."
        canonical="/cheap-smokes-hobart"
        keywords="cheap smokes Hobart, buy cigarettes online Hobart, cheap cigarettes Hobart, tobacco delivery Hobart, cigarettes online Tasmania, tobacconist Hobart online, cheap tobacco Tasmania"
        jsonLd={[localBusinessJsonLd(), breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Hobart', url: '/cheap-smokes-hobart' }]), faqJsonLd(FAQS)]}
      />
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container"><div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">Cheap Smokes Hobart<span className="text-primary block mt-2">Buy Cigarettes Online — Tasmania Delivery</span></h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8">Looking for <strong>cheap smokes in Hobart</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered anywhere in Tasmania.</p>
          <Button size="lg" asChild><Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link></Button>
        </div></div>
      </section>
      <section className="py-12 md:py-16"><div className="container"><div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
        <h2>Buy Cheap Cigarettes Online in Hobart</h2>
        <p>Hobart and Tasmania smokers can save big by ordering online. <strong>Buy cigarettes online in Hobart</strong> from Aussie Smoke Store — delivered to Sandy Bay, Battery Point, Glenorchy, New Town, Moonah, and all Tasmanian towns.</p>
        <h3>Why Tasmanian Smokers Choose Aussie Smoke Store</h3>
        <ul>
          <li><strong>Cheapest prices in Tasmania</strong> — far below Hobart retail</li>
          <li><strong>Tasmania-wide delivery</strong> — Hobart, Launceston, Devonport, Burnie &amp; more</li>
          <li><strong>All major brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
          <li><strong>Free shipping</strong> on orders over A$50</li>
          <li><strong>Discreet plain packaging</strong></li>
        </ul>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
        <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
        <Link to="/cheap-smokes-melbourne" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Melbourne</Link>
        <Link to="/cheap-smokes-adelaide" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Adelaide</Link>
        <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
      </div></div></section>
      <section className="py-12 bg-secondary/30"><div className="container">
        <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Hobart</h2>
        <ProductGrid products={products} isLoading={isLoading} />
        <div className="text-center mt-8"><Button size="lg" asChild><Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link></Button></div>
      </div></section>
      <section className="py-12 md:py-16"><div className="container max-w-4xl">
        <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Hobart</h2>
        <div className="space-y-6">{FAQS.map((faq, i) => (<div key={i} className="border rounded-lg p-6"><h3 className="font-semibold text-lg mb-2">{faq.question}</h3><p className="text-muted-foreground">{faq.answer}</p></div>))}</div>
      </div></section>
    </Layout>
  );
};

export default CheapSmokesHobart;
