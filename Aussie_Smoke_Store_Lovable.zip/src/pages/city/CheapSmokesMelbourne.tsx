import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Melbourne?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes across all Melbourne suburbs — from the CBD to the outer suburbs, Geelong, and the Mornington Peninsula.' },
  { question: 'How fast is cigarette delivery in Melbourne?', answer: 'Melbourne orders typically arrive within 3-5 business days. Free shipping is available on orders over A$50.' },
  { question: 'Are online cigarette prices cheaper than Melbourne shops?', answer: 'Much cheaper. Our prices beat any Melbourne tobacconist. You\'ll save significantly on every carton compared to retail.' },
  { question: 'What brands do you stock for Melbourne customers?', answer: 'We carry Marlboro Red, Marlboro Gold, Manchester, Bond Street, rolling tobacco, nicotine pouches, and a wide range of vapes.' },
];

const CheapSmokesMelbourne = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Melbourne — Cigarettes Online"
        description="Buy cheap smokes and cigarettes online in Melbourne. Lowest prices on tobacco, vapes & accessories. Fast Melbourne delivery. Free shipping over A$50."
        canonical="/cheap-smokes-melbourne"
        keywords="cheap smokes Melbourne, buy cigarettes online Melbourne, cheap cigarettes Melbourne, tobacco delivery Melbourne, cigarettes online Melbourne, tobacconist Melbourne online, buy smokes Melbourne, cheap tobacco Melbourne"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Melbourne', url: '/cheap-smokes-melbourne' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Melbourne
              <span className="text-primary block mt-2">Buy Cigarettes Online — Melbourne Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in Melbourne</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered to any Melbourne suburb. Save hundreds vs retail prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Melbourne</h2>
            <p>
              Melbourne tobacconists charge a premium. With Aussie Smoke Store, you can <strong>buy cigarettes online in Melbourne</strong> at unbeatable prices — delivered to your door across all Melbourne areas including St Kilda, Footscray, Richmond, Dandenong, Frankston, and the CBD.
            </p>
            <h3>Why Melbourne Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Rock-bottom prices</strong> — cheaper than any Melbourne tobacco shop</li>
              <li><strong>Melbourne-wide delivery</strong> — inner city, northern, southern, eastern &amp; western suburbs</li>
              <li><strong>Premium brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet plain packaging</strong> for privacy</li>
            </ul>
            <h3>Melbourne Suburbs We Deliver To</h3>
            <p>
              We deliver to every Melbourne postcode — Carlton, South Yarra, Brunswick, Preston, Box Hill, Cranbourne, Werribee, Sunbury, Ringwood, Glen Waverley, and hundreds more across Greater Melbourne.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-sydney" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Sydney</Link>
            <Link to="/cheap-smokes-brisbane" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Brisbane</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Melbourne</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Melbourne</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesMelbourne;
