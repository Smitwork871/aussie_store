import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Canberra?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes across the ACT — Canberra CBD, Belconnen, Woden, Tuggeranong, Gungahlin, and all surrounding areas.' },
  { question: 'How long does cigarette delivery take to Canberra?', answer: 'Canberra orders typically arrive within 3-5 business days. Free shipping on orders over A$50.' },
  { question: 'Are your prices cheaper than Canberra tobacconists?', answer: 'Significantly cheaper. ACT tobacco prices are among the highest in Australia — our online prices will save you hundreds per year.' },
  { question: 'Do you deliver to Queanbeyan and surrounding NSW areas?', answer: 'Yes! We deliver to Queanbeyan, Yass, Batemans Bay, and all surrounding regions near the ACT.' },
];

const CheapSmokesCanberra = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Canberra — Buy Cigarettes Online ACT Delivery"
        description="Buy cheap smokes and cigarettes online in Canberra. Lowest prices on tobacco, vapes & accessories. Fast ACT delivery. Free shipping over A$50."
        canonical="/cheap-smokes-canberra"
        keywords="cheap smokes Canberra, buy cigarettes online Canberra, cheap cigarettes Canberra, tobacco delivery Canberra, cigarettes online ACT, tobacconist Canberra online, cheap tobacco Canberra"
        jsonLd={[localBusinessJsonLd(), breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Canberra', url: '/cheap-smokes-canberra' }]), faqJsonLd(FAQS)]}
      />
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container"><div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">Cheap Smokes Canberra<span className="text-primary block mt-2">Buy Cigarettes Online — ACT Delivery</span></h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8">Looking for <strong>cheap smokes in Canberra</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered anywhere in the ACT.</p>
          <Button size="lg" asChild><Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link></Button>
        </div></div>
      </section>
      <section className="py-12 md:py-16"><div className="container"><div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
        <h2>Buy Cheap Cigarettes Online in Canberra</h2>
        <p>Canberra smokers pay premium prices at local tobacconists. <strong>Buy cigarettes online in Canberra</strong> from Aussie Smoke Store at unbeatable prices — delivered to Civic, Braddon, Kingston, Manuka, Belconnen, Woden, and all ACT suburbs.</p>
        <h3>Why Canberra Smokers Choose Aussie Smoke Store</h3>
        <ul>
          <li><strong>Cheapest prices in the ACT</strong> — far below Canberra retail</li>
          <li><strong>ACT-wide delivery</strong> — all Canberra districts and surrounding regions</li>
          <li><strong>All major brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
          <li><strong>Free shipping</strong> on orders over A$50</li>
          <li><strong>Discreet plain packaging</strong></li>
        </ul>
        <h3>Canberra Areas We Deliver To</h3>
        <p>We deliver to every ACT postcode — Belconnen, Woden, Tuggeranong, Gungahlin, Weston Creek, Molonglo Valley, Queanbeyan, and all surrounding areas.</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
        <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
        <Link to="/cheap-smokes-sydney" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Sydney</Link>
        <Link to="/cheap-smokes-melbourne" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Melbourne</Link>
        <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
      </div></div></section>
      <section className="py-12 bg-secondary/30"><div className="container">
        <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Canberra</h2>
        <ProductGrid products={products} isLoading={isLoading} />
        <div className="text-center mt-8"><Button size="lg" asChild><Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link></Button></div>
      </div></section>
      <section className="py-12 md:py-16"><div className="container max-w-4xl">
        <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Canberra</h2>
        <div className="space-y-6">{FAQS.map((faq, i) => (<div key={i} className="border rounded-lg p-6"><h3 className="font-semibold text-lg mb-2">{faq.question}</h3><p className="text-muted-foreground">{faq.answer}</p></div>))}</div>
      </div></section>
    </Layout>
  );
};

export default CheapSmokesCanberra;
