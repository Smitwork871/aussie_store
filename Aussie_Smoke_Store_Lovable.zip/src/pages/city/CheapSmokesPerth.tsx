import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Perth?', answer: 'Yes! Aussie Smoke Store delivers cigarettes across all Perth suburbs and Western Australia — from the CBD to Fremantle, Joondalup, Rockingham, and Mandurah.' },
  { question: 'How long does cigarette delivery take to Perth?', answer: 'Perth orders typically arrive within 5-7 business days. Free shipping is available on orders over A$50.' },
  { question: 'Are your prices cheaper than Perth tobacconists?', answer: 'Significantly cheaper. Perth has some of the highest retail tobacco prices in Australia — our online prices will save you hundreds per year.' },
  { question: 'Do you deliver to regional WA?', answer: 'Yes! We deliver to all of Western Australia including Bunbury, Geraldton, Kalgoorlie, Albany, and Broome.' },
];

const CheapSmokesPerth = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Perth — Buy Cigarettes Online Perth Delivery"
        description="Buy cheap smokes and cigarettes online in Perth. Lowest prices on tobacco, vapes & accessories. Fast Perth & WA delivery. Free shipping over A$50."
        canonical="/cheap-smokes-perth"
        keywords="cheap smokes Perth, buy cigarettes online Perth, cheap cigarettes Perth, tobacco delivery Perth, cigarettes online Perth, tobacconist Perth online, buy smokes Perth, cheap tobacco Perth, WA cigarettes online"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Perth', url: '/cheap-smokes-perth' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Perth
              <span className="text-primary block mt-2">Buy Cigarettes Online — Perth &amp; WA Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in Perth</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered anywhere in Perth and Western Australia.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Perth</h2>
            <p>
              Perth smokers are tired of paying premium retail prices. <strong>Buy cigarettes online in Perth</strong> from Aussie Smoke Store and save — delivered to Northbridge, Subiaco, Scarborough, Cannington, Armadale, and all Perth metro areas.
            </p>
            <h3>Why Perth Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Lowest prices in WA</strong> — far cheaper than Perth retail shops</li>
              <li><strong>Perth &amp; WA-wide delivery</strong> — metro, regional, and remote areas</li>
              <li><strong>All major brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet plain packaging</strong></li>
            </ul>
            <h3>Perth Areas We Deliver To</h3>
            <p>
              We deliver to every Perth postcode — Fremantle, Joondalup, Rockingham, Midland, Ellenbrook, Baldivis, Mandurah, and all suburbs across the Perth metro area.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-sydney" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Sydney</Link>
            <Link to="/cheap-smokes-melbourne" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Melbourne</Link>
            <Link to="/cheap-smokes-adelaide" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Adelaide</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Perth</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Perth</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesPerth;
