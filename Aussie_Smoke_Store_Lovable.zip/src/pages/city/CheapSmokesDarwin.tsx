import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Darwin?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes across the Northern Territory — Darwin CBD, Palmerston, Casuarina, and all surrounding areas.' },
  { question: 'How long does cigarette delivery take to Darwin?', answer: 'Darwin orders typically arrive within 5-7 business days due to distance. Free shipping on orders over A$50.' },
  { question: 'Do you deliver to remote NT areas?', answer: 'Yes! We deliver to all of the Northern Territory including Alice Springs, Katherine, and Tennant Creek.' },
  { question: 'Are your prices cheaper than Darwin tobacconists?', answer: 'Much cheaper. The NT has very high retail tobacco prices — our online prices save you significantly.' },
];

const CheapSmokesDarwin = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Darwin — Buy Cigarettes Online NT Delivery"
        description="Buy cheap smokes and cigarettes online in Darwin. Lowest prices on tobacco, vapes & accessories. NT-wide delivery. Free shipping over A$50."
        canonical="/cheap-smokes-darwin"
        keywords="cheap smokes Darwin, buy cigarettes online Darwin, cheap cigarettes Darwin, tobacco delivery Darwin, cigarettes online NT, tobacconist Darwin online, cheap tobacco Northern Territory"
        jsonLd={[localBusinessJsonLd(), breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Darwin', url: '/cheap-smokes-darwin' }]), faqJsonLd(FAQS)]}
      />
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container"><div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">Cheap Smokes Darwin<span className="text-primary block mt-2">Buy Cigarettes Online — NT Delivery</span></h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8">Looking for <strong>cheap smokes in Darwin</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered anywhere in the Northern Territory.</p>
          <Button size="lg" asChild><Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link></Button>
        </div></div>
      </section>
      <section className="py-12 md:py-16"><div className="container"><div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
        <h2>Buy Cheap Cigarettes Online in Darwin</h2>
        <p>Darwin and NT smokers pay some of the highest prices in the country. <strong>Buy cigarettes online in Darwin</strong> from Aussie Smoke Store and save — delivered to the CBD, Stuart Park, Nightcliff, Palmerston, and all NT areas.</p>
        <h3>Why NT Smokers Choose Aussie Smoke Store</h3>
        <ul>
          <li><strong>Cheapest prices in the NT</strong> — far below Darwin retail</li>
          <li><strong>NT-wide delivery</strong> — Darwin, Alice Springs, Katherine &amp; more</li>
          <li><strong>All major brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
          <li><strong>Free shipping</strong> on orders over A$50</li>
          <li><strong>Discreet plain packaging</strong></li>
        </ul>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
        <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
        <Link to="/cheap-smokes-perth" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Perth</Link>
        <Link to="/cheap-smokes-brisbane" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Brisbane</Link>
        <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
      </div></div></section>
      <section className="py-12 bg-secondary/30"><div className="container">
        <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Darwin</h2>
        <ProductGrid products={products} isLoading={isLoading} />
        <div className="text-center mt-8"><Button size="lg" asChild><Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link></Button></div>
      </div></section>
      <section className="py-12 md:py-16"><div className="container max-w-4xl">
        <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Darwin</h2>
        <div className="space-y-6">{FAQS.map((faq, i) => (<div key={i} className="border rounded-lg p-6"><h3 className="font-semibold text-lg mb-2">{faq.question}</h3><p className="text-muted-foreground">{faq.answer}</p></div>))}</div>
      </div></section>
    </Layout>
  );
};

export default CheapSmokesDarwin;
