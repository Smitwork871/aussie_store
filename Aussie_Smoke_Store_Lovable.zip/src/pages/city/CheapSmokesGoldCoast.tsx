import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online on the Gold Coast?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes across the Gold Coast — Surfers Paradise, Broadbeach, Southport, Robina, Coolangatta, and all surrounding areas.' },
  { question: 'How fast is cigarette delivery to the Gold Coast?', answer: 'Gold Coast orders typically arrive within 3-5 business days. Free shipping on orders over A$50.' },
  { question: 'Are online prices cheaper than Gold Coast tobacconists?', answer: 'Much cheaper. Our online prices beat any Gold Coast tobacco shop. Save significantly on every carton.' },
  { question: 'Do you deliver to the Gold Coast hinterland?', answer: 'Yes! We deliver to all Gold Coast postcodes including Tamborine Mountain, Nerang, Mudgeeraba, and the hinterland.' },
];

const CheapSmokesGoldCoast = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Gold Coast — Cigarettes Online"
        description="Buy cheap smokes and cigarettes online on the Gold Coast. Lowest prices on tobacco, vapes & accessories. Fast Gold Coast delivery. Free shipping over A$50."
        canonical="/cheap-smokes-gold-coast"
        keywords="cheap smokes Gold Coast, buy cigarettes online Gold Coast, cheap cigarettes Gold Coast, tobacco delivery Gold Coast, cigarettes online Gold Coast, tobacconist Gold Coast online, Surfers Paradise cigarettes"
        jsonLd={[localBusinessJsonLd(), breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Gold Coast', url: '/cheap-smokes-gold-coast' }]), faqJsonLd(FAQS)]}
      />
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container"><div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">Cheap Smokes Gold Coast<span className="text-primary block mt-2">Buy Cigarettes Online — Gold Coast Delivery</span></h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8">Looking for <strong>cheap smokes on the Gold Coast</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered to your door.</p>
          <Button size="lg" asChild><Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link></Button>
        </div></div>
      </section>
      <section className="py-12 md:py-16"><div className="container"><div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
        <h2>Buy Cheap Cigarettes Online on the Gold Coast</h2>
        <p>Gold Coast smokers can skip expensive tobacconists. <strong>Buy cigarettes online on the Gold Coast</strong> from Aussie Smoke Store at unbeatable prices — delivered to Surfers Paradise, Broadbeach, Southport, Robina, Burleigh Heads, and all Gold Coast suburbs.</p>
        <h3>Why Gold Coast Smokers Choose Aussie Smoke Store</h3>
        <ul>
          <li><strong>Cheapest prices on the Gold Coast</strong> — far below retail tobacconists</li>
          <li><strong>Gold Coast-wide delivery</strong> — all suburbs from Coolangatta to Coomera</li>
          <li><strong>All major brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
          <li><strong>Free shipping</strong> on orders over A$50</li>
          <li><strong>Discreet plain packaging</strong></li>
        </ul>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
        <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
        <Link to="/cheap-smokes-brisbane" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Brisbane</Link>
        <Link to="/cheap-smokes-sydney" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Sydney</Link>
        <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
      </div></div></section>
      <section className="py-12 bg-secondary/30"><div className="container">
        <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Gold Coast</h2>
        <ProductGrid products={products} isLoading={isLoading} />
        <div className="text-center mt-8"><Button size="lg" asChild><Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link></Button></div>
      </div></section>
      <section className="py-12 md:py-16"><div className="container max-w-4xl">
        <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online on the Gold Coast</h2>
        <div className="space-y-6">{FAQS.map((faq, i) => (<div key={i} className="border rounded-lg p-6"><h3 className="font-semibold text-lg mb-2">{faq.question}</h3><p className="text-muted-foreground">{faq.answer}</p></div>))}</div>
      </div></section>
    </Layout>
  );
};

export default CheapSmokesGoldCoast;
