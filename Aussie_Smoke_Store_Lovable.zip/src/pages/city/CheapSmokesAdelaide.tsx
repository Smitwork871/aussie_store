import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Adelaide?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes across all Adelaide suburbs and South Australia — from the CBD to Elizabeth, Salisbury, Marion, and the Adelaide Hills.' },
  { question: 'How long does cigarette delivery take to Adelaide?', answer: 'Adelaide orders typically arrive within 3-5 business days. Free shipping on orders over A$50.' },
  { question: 'Are your prices cheaper than Adelaide tobacconists?', answer: 'Much cheaper. Our online prices consistently beat Adelaide retail tobacco shops. Save on every pack and carton.' },
  { question: 'Do you deliver to regional South Australia?', answer: 'Yes! We deliver to all of South Australia including Mount Gambier, Murray Bridge, Port Augusta, and Whyalla.' },
];

const CheapSmokesAdelaide = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes Adelaide — Cigarettes Online"
        description="Buy cheap smokes and cigarettes online in Adelaide. Lowest prices on tobacco, vapes & accessories. Fast Adelaide & SA delivery. Free shipping over A$50."
        canonical="/cheap-smokes-adelaide"
        keywords="cheap smokes Adelaide, buy cigarettes online Adelaide, cheap cigarettes Adelaide, tobacco delivery Adelaide, cigarettes online Adelaide, tobacconist Adelaide online, buy smokes Adelaide, cheap tobacco Adelaide, SA cigarettes online"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Adelaide', url: '/cheap-smokes-adelaide' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Adelaide
              <span className="text-primary block mt-2">Buy Cigarettes Online — Adelaide &amp; SA Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in Adelaide</strong>? Get the cheapest cigarettes, tobacco &amp; vapes delivered anywhere in Adelaide and South Australia.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Adelaide</h2>
            <p>
              Adelaide smokers can now save big by shopping online. <strong>Buy cigarettes online in Adelaide</strong> from Aussie Smoke Store at prices well below what local tobacconists charge — delivered to Rundle Mall, Norwood, Glenelg, Modbury, Morphett Vale, and beyond.
            </p>
            <h3>Why Adelaide Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Cheapest prices in SA</strong> — far below Adelaide retail</li>
              <li><strong>Adelaide &amp; SA-wide delivery</strong> — metro and regional areas</li>
              <li><strong>All top brands</strong> — Marlboro, Manchester, Bond Street, rolling tobacco, vapes</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet plain packaging</strong></li>
            </ul>
            <h3>Adelaide Areas We Deliver To</h3>
            <p>
              We deliver to every Adelaide postcode — North Adelaide, Prospect, Unley, Mitcham, Tea Tree Gully, Salisbury, Elizabeth, Semaphore, Henley Beach, and all Greater Adelaide suburbs.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-sydney" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Sydney</Link>
            <Link to="/cheap-smokes-melbourne" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Melbourne</Link>
            <Link to="/cheap-smokes-perth" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Perth</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Adelaide</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Adelaide</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesAdelaide;
