import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/mac-cool-blast-cigarettes-australia',
  metaTitle: 'MAC Cool Blast Cigarettes Australia — Buy Online',
  metaDescription: 'Buy MAC Cool Blast cigarettes online in Australia. Menthol superslim cigarettes at cheap carton prices. Free shipping over A$50, 48h dispatch.',
  metaKeywords: 'mac cigarettes, mac cool blast, mac cool blast superslims, mac superslim, mac cigarettes australia, buy mac cigarettes online',
  breadcrumbName: 'MAC Cool Blast Australia',
  h1Line1: 'MAC Cool Blast Superslims',
  h1Line2: 'Australia — Cheapest Online',
  heroParagraph:
    '<strong>MAC Cool Blast Superslim</strong> menthol cigarettes — delivered Australia-wide at the lowest carton prices. Smooth, slim, refreshing. Free shipping over A$50.',
  subject: 'MAC Cool Blast',
  productFilter: { column: 'name', pattern: '%mac%' },
  bodyHtml: `
    <h2>MAC Cool Blast Superslims — slim, smooth, menthol</h2>
    <p><strong>MAC Cool Blast</strong> are popular superslim menthol cigarettes — known for the elegant slim format and crisp menthol blast on draw. We keep MAC in regular Australian stock with fast dispatch.</p>
    <h3>MAC Cool Blast — at a glance</h3>
    <ul>
      <li>Superslim format — narrower stick, lighter draw</li>
      <li>Menthol blast flavour</li>
      <li>Carton: 10 packets × 20 cigarettes</li>
    </ul>
    <h3>Why buy MAC Cool Blast from Aussie Smoke Store?</h3>
    <ul>
      <li>Cheapest MAC carton prices in Australia</li>
      <li>48h dispatch from Australian warehouse</li>
      <li>Free shipping over A$50</li>
      <li>Discreet, tracked delivery</li>
    </ul>
    <h3>Other menthol & slim options</h3>
    <p>Also see <a href="/esse-menthol-cigarettes-australia">Esse menthol cigarettes</a> and <a href="/marlboro-ice-blast-australia">Marlboro Ice Blast</a> (menthol capsule).</p>
  `,
  faqs: [
    { question: 'What is MAC Cool Blast?', answer: 'MAC Cool Blast is a superslim menthol cigarette — slim stick format with a menthol-blast flavour. Popular for a lighter, smoother draw than standard king-size.' },
    { question: 'How much is a MAC Cool Blast carton?', answer: 'Live pricing is on the product cards above. We re-price weekly to remain the cheapest MAC retailer in Australia.' },
    { question: 'Are MAC cigarettes available in Australia?', answer: "Yes — Aussie Smoke Store stocks MAC Cool Blast Superslims in Australian-based stock with 48-hour dispatch." },
    { question: 'Is MAC a menthol cigarette?', answer: 'MAC Cool Blast is the menthol variant. Standard MAC variants are non-menthol.' },
    { question: 'How fast does MAC Cool Blast ship?', answer: 'We dispatch within 48 hours. Metro 3–5 business days, regional 5–7 business days, all tracked.' },
  ],
};

const MacCoolBlastCigarettesAustralia = () => <BrandLandingPage config={config} />;
export default MacCoolBlastCigarettesAustralia;
