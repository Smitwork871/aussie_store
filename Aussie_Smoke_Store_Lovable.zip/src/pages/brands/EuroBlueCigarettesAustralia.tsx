import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/euro-blue-cigarettes-australia',
  metaTitle: 'Euro Blue Cigarettes Australia — Buy Online Cheap',
  metaDescription: 'Buy Euro Blue cigarettes online in Australia. Smooth, smoother European blend at cheap carton prices. Free shipping over A$50, 48h dispatch.',
  metaKeywords: 'euro blue, euro blue cigarettes, euro blue australia, buy euro blue online, euro blue carton price',
  breadcrumbName: 'Euro Blue Australia',
  h1Line1: 'Euro Blue Cigarettes',
  h1Line2: 'Australia — Cheapest Online',
  heroParagraph:
    '<strong>Euro Blue</strong> — smooth European-style blend — delivered Australia-wide at the lowest carton prices online. Free shipping over A$50.',
  subject: 'Euro Blue',
  productFilter: { column: 'name', pattern: '%euro%' },
  bodyHtml: `
    <h2>Euro Blue — smooth, European-style cigarettes</h2>
    <p><strong>Euro Blue</strong> is a smoother, European-style blend — popular with Australian smokers looking for a milder alternative to traditional full-flavour kings. We stock Euro Blue cartons with same-week dispatch.</p>
    <h3>Euro Blue carton format</h3>
    <ul>
      <li>10 packets × 20 cigarettes per carton</li>
      <li>Sealed manufacturer packaging</li>
      <li>Australian-held stock — no overseas delay</li>
    </ul>
    <h3>Why buy Euro Blue from Aussie Smoke Store?</h3>
    <ul>
      <li>Cheapest Euro Blue carton prices in Australia</li>
      <li>Free shipping on orders over A$50</li>
      <li>48-hour dispatch from Australian warehouse</li>
      <li>Discreet, tracked delivery to every postcode</li>
    </ul>
    <h3>Related smooth blends</h3>
    <p>Also try <a href="/manchester-sapphire-blue-australia">Manchester Sapphire Blue</a> or <a href="/dunhill-blue-cigarettes-australia">Dunhill Blue</a> for similar smoother blends.</p>
  `,
  faqs: [
    { question: 'Where can I buy Euro Blue cigarettes in Australia?', answer: 'Aussie Smoke Store stocks Euro Blue cartons for Australia-wide delivery with 48-hour dispatch.' },
    { question: 'How much is a carton of Euro Blue?', answer: 'Live carton pricing is shown on the product cards above. We re-price every week to remain the cheapest in Australia.' },
    { question: 'Is Euro Blue a light or full-flavour cigarette?', answer: 'Euro Blue is a smoother, lighter European-style blend.' },
    { question: 'Do you ship Euro Blue to all of Australia?', answer: 'Yes — every Australian postcode, including regional and remote. Tracked delivery as standard.' },
    { question: 'Are these genuine Euro Blue cigarettes?', answer: 'Yes — 100% genuine product in sealed manufacturer cartons.' },
  ],
};

const EuroBlueCigarettesAustralia = () => <BrandLandingPage config={config} />;
export default EuroBlueCigarettesAustralia;
