import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/esse-menthol-cigarettes-australia',
  metaTitle: 'Esse Menthol Cigarettes Australia — Buy Online',
  metaDescription: 'Buy Esse menthol cigarettes online in Australia. Superslim menthol cigarettes at cheap carton prices. Free shipping over A$50, 48h dispatch.',
  metaKeywords: 'menthol cigarettes, esse menthol, esse cigarettes australia, menthol cigarettes australia, buy menthol cigarettes online, esse superslim menthol',
  breadcrumbName: 'Esse Menthol Australia',
  h1Line1: 'Esse Menthol Cigarettes',
  h1Line2: 'Australia — Cheap Online',
  heroParagraph:
    'Buy <strong>Esse menthol cigarettes</strong> online in Australia — the popular Korean superslim menthol — at unbeatable carton prices. Free shipping over A$50.',
  subject: 'Esse Menthol',
  productFilter: { column: 'name', pattern: '%esse%' },
  bodyHtml: `
    <h2>Esse Menthol — Korea's most popular superslim menthol</h2>
    <p><strong>Esse Menthol</strong> is the iconic superslim menthol cigarette from KT&G. Known for its crisp menthol flavour and elegant slim format, Esse is a top choice for Australian smokers wanting a lighter menthol draw.</p>
    <h3>Esse Menthol carton format</h3>
    <ul>
      <li>10 packets × 20 cigarettes per carton</li>
      <li>Superslim format — slim, light draw</li>
      <li>Sealed manufacturer cartons, Australian stock</li>
    </ul>
    <h3>Why Aussie Smoke Store?</h3>
    <ul>
      <li>Australia's cheapest Esse Menthol carton prices</li>
      <li>48-hour dispatch from AU warehouse</li>
      <li>Free shipping on orders over A$50</li>
      <li>Tracked, discreet delivery to every postcode</li>
    </ul>
    <h3>Other menthol cigarettes in Australia</h3>
    <p>Also browse <a href="/marlboro-ice-blast-australia">Marlboro Ice Blast</a> and <a href="/mac-cool-blast-cigarettes-australia">MAC Cool Blast Superslims</a> for more menthol options.</p>
  `,
  faqs: [
    { question: 'Are menthol cigarettes legal in Australia?', answer: 'Yes — menthol cigarettes remain legal to buy and sell in Australia. Esse Menthol is available through Aussie Smoke Store.' },
    { question: 'What is Esse Menthol?', answer: "Esse is KT&G's premium superslim cigarette range. Esse Menthol is the menthol variant — slim stick, crisp menthol flavour." },
    { question: 'How much is a carton of Esse Menthol?', answer: 'Live carton pricing shows on the product cards above. We re-price weekly to remain the cheapest Esse retailer in Australia.' },
    { question: 'How does Esse compare to other menthol cigarettes?', answer: 'Esse is a superslim — narrower stick than Marlboro Ice Blast or MAC Cool Blast, with a smoother, lighter draw.' },
    { question: 'How fast does Esse Menthol ship?', answer: 'We dispatch within 48 hours of payment. Metro 3–5 business days, regional 5–7 business days.' },
  ],
};

const EsseMentholCigarettesAustralia = () => <BrandLandingPage config={config} />;
export default EsseMentholCigarettesAustralia;
