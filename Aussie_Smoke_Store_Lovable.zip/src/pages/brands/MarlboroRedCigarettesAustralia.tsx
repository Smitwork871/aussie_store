import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/marlboro-red-cigarettes-australia',
  metaTitle: 'Marlboro Red Cigarettes Australia — Cheapest Online',
  metaDescription: 'Buy Marlboro Red cigarettes online in Australia. Cheapest carton prices, free shipping over A$50, dispatched within 48 hours from Australian stock.',
  metaKeywords: 'marlboro red, marlboro red cigarettes, marlboro red australia, buy marlboro red online, marlboro red carton price, cheap marlboro',
  breadcrumbName: 'Marlboro Red Australia',
  h1Line1: 'Marlboro Red Cigarettes',
  h1Line2: 'Australia — Best Online Price',
  heroParagraph:
    '<strong>Marlboro Red</strong> — the iconic full-flavour classic — delivered Australia-wide at the cheapest carton prices. 48h dispatch, free shipping over A$50.',
  subject: 'Marlboro Red',
  productFilter: { column: 'name', pattern: '%marlboro red%' },
  bodyHtml: `
    <h2>Marlboro Red — the world's most iconic cigarette</h2>
    <p><strong>Marlboro Red</strong> is the original full-flavour Marlboro — bold, rich tobacco taste in the unmistakable red pack. We stock genuine Marlboro Red cartons in Australia and dispatch within 48 hours.</p>
    <h3>Marlboro Red carton format</h3>
    <ul>
      <li>10 packets × 20 cigarettes (200 sticks per carton)</li>
      <li>Sealed manufacturer cartons</li>
      <li>Held in Australian stock — no overseas customs delays</li>
    </ul>
    <h3>Why Aussie Smoke Store for Marlboro Red?</h3>
    <ul>
      <li>Cheapest Marlboro Red carton prices in Australia — verified weekly</li>
      <li>Free shipping on orders over A$50</li>
      <li>Discreet, tracked delivery to every Australian postcode</li>
      <li>Dispatched in 48 hours of payment confirmation</li>
    </ul>
    <h3>Other Marlboro options</h3>
    <p>Browse <a href="/marlboro-ice-blast-australia">Marlboro Ice Blast</a> (menthol capsule) or the full <a href="/marlboro-cigarettes-australia">Marlboro range in Australia</a>.</p>
  `,
  faqs: [
    { question: 'How much is a carton of Marlboro Red in Australia?', answer: 'Carton pricing changes weekly. See live pricing on the product cards above — we re-price every week to remain the cheapest in Australia.' },
    { question: 'Are these genuine Marlboro Red cigarettes?', answer: 'Yes — 100% genuine Marlboro Red in sealed manufacturer cartons, sourced through legitimate supply channels.' },
    { question: 'Do you stock Marlboro Red in packs as well as cartons?', answer: 'Carton stock is most common (10 × 20s). Pack-level stock varies — check the product cards above for currently available options.' },
    { question: 'How fast is Marlboro Red delivery?', answer: 'We dispatch within 48 hours. Metro Australia 3–5 business days, regional 5–7 business days, all tracked.' },
    { question: 'Is Marlboro Red stronger than Marlboro Gold?', answer: 'Yes — Marlboro Red is the full-flavour variant. Marlboro Gold is the lighter blend.' },
  ],
};

const MarlboroRedCigarettesAustralia = () => <BrandLandingPage config={config} />;
export default MarlboroRedCigarettesAustralia;
