import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/dunhill-blue-cigarettes-australia',
  metaTitle: 'Dunhill Blue Cigarettes Australia — Buy Online Cheap',
  metaDescription: 'Buy Dunhill Blue cigarettes online in Australia. Premium Dunhill cartons at the cheapest prices online. Free shipping over A$50, 48h dispatch.',
  metaKeywords: 'dunhill cigarettes, dunhill blue, dunhill blue australia, dunhill cigarettes australia, buy dunhill online, dunhill carton price, premium cigarettes',
  breadcrumbName: 'Dunhill Blue Australia',
  h1Line1: 'Dunhill Blue Cigarettes',
  h1Line2: 'Australia — Cheapest Online',
  heroParagraph:
    'Buy <strong>Dunhill Blue</strong> — the smooth premium British blend — at the cheapest carton prices in Australia. Free shipping over A$50, dispatched in 48 hours.',
  subject: 'Dunhill Blue',
  productFilter: { column: 'name', pattern: '%dunhill%' },
  bodyHtml: `
    <h2>Dunhill Blue — refined, smooth, premium</h2>
    <p><strong>Dunhill Blue</strong> is the smoother, lighter variant of the iconic British Dunhill range. Refined tobacco blend, distinctive premium pack, and a smooth draw that's earned Dunhill its global premium reputation.</p>
    <h3>Dunhill Blue carton format</h3>
    <ul>
      <li>10 packets × 20 cigarettes per carton</li>
      <li>Sealed manufacturer cartons</li>
      <li>Australian-held stock — no overseas customs delay</li>
    </ul>
    <h3>Why Aussie Smoke Store for Dunhill Blue?</h3>
    <ul>
      <li>Australia's cheapest Dunhill Blue carton prices — premium taste at budget pricing</li>
      <li>48-hour dispatch from AU warehouse</li>
      <li>Free shipping over A$50</li>
      <li>Discreet, tracked Australia-wide delivery</li>
    </ul>
    <h3>Other premium cigarettes</h3>
    <p>Also browse <a href="/bensons-hedges-gold-cigarettes-australia">B&amp;H Gold</a>, <a href="/marlboro-red-cigarettes-australia">Marlboro Red</a>, or the <a href="/best-cigarettes-australia">best premium cigarettes in Australia</a>.</p>
  `,
  faqs: [
    { question: 'How much is a carton of Dunhill Blue in Australia?', answer: 'Carton pricing is on the product cards above. We re-price weekly to remain the cheapest Dunhill retailer in Australia.' },
    { question: 'Is Dunhill Blue stronger or smoother than Dunhill Red?', answer: 'Dunhill Blue is the smoother, lighter variant. Dunhill Red is the full-flavour Dunhill.' },
    { question: 'Are these genuine Dunhill Blue cigarettes?', answer: 'Yes — 100% genuine Dunhill product in sealed manufacturer cartons sourced through legitimate supply channels.' },
    { question: 'Do you stock other Dunhill variants?', answer: 'Stock varies week to week. Browse our product cards above for currently available Dunhill variants.' },
    { question: 'How fast does Dunhill Blue ship?', answer: '48-hour dispatch from Australian warehouse. Metro 3–5 business days, regional 5–7 business days, all tracked.' },
  ],
};

const DunhillBlueCigarettesAustralia = () => <BrandLandingPage config={config} />;
export default DunhillBlueCigarettesAustralia;
