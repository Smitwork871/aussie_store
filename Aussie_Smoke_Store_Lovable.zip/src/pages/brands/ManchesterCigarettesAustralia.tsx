import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy Manchester cigarettes online in Australia?', answer: 'Aussie Smoke Store is Australia\'s go-to online store for Manchester cigarettes. We stock Manchester Red, Gold, Lights, Sapphire Blue, Double Drive, Green Crush, and more — all at the cheapest prices with Australia-wide delivery.' },
  { question: 'How much do Manchester cigarettes cost online?', answer: 'Manchester cigarettes at Aussie Smoke Store are priced well below Australian retail. We offer cartons of 10 packets (200 cigarettes) at bulk-discount prices, plus free shipping on orders over A$50.' },
  { question: 'What Manchester varieties do you stock?', answer: 'We carry the full Manchester range: Red, Royal Red, Classic Gold, Lights, Sapphire Blue, Reserve, Special Edition, Double Drive, Green Crush, and Blue Crush.' },
  { question: 'Are Manchester cigarettes good quality?', answer: 'Manchester is one of the most popular budget cigarette brands worldwide, known for smooth flavour at an affordable price. They are a favourite among Australian smokers looking for quality without the premium price tag.' },
];

const ManchesterCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .ilike('brand', '%MANCHESTER%')
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase
          .from('public_products')
          .select('*')
          .eq('is_active', true)
          .order('is_featured', { ascending: false })
          .limit(12);
        if (fallback) setProducts(fallback as Product[]);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Manchester Cigarettes Australia"
        description="Buy Manchester cigarettes online in Australia at the cheapest prices. Manchester Red, Gold, Lights, Sapphire Blue & more. Free shipping over A$50. Fast delivery Australia-wide."
        canonical="/manchester-cigarettes-australia"
        keywords="Manchester cigarettes Australia, buy Manchester cigarettes online, cheap Manchester cigarettes, Manchester Red Australia, Manchester Gold cigarettes, Manchester carton price Australia, budget cigarettes Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Manchester Cigarettes Australia', url: '/manchester-cigarettes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Manchester Cigarettes Online
              <span className="text-primary block mt-2">Cheapest Prices in Australia</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Australia's biggest range of <strong>Manchester cigarettes</strong> at unbeatable prices. Manchester Red, Gold, Lights, Sapphire Blue &amp; more — delivered discreetly to your door.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Manchester <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Manchester Cigarettes — Australia's Best Value Smokes</h2>
            <p>
              <strong>Manchester cigarettes</strong> are one of the most popular budget brands among Australian smokers. At Aussie Smoke Store, we stock the complete Manchester range at prices far below what you'd pay at a local tobacconist — including <strong>Manchester Red</strong>, <strong>Manchester Classic Gold</strong>, <strong>Manchester Lights</strong>, and specialty varieties like <strong>Sapphire Blue</strong> and <strong>Double Drive</strong>.
            </p>
            <h3>Manchester Range Available</h3>
            <ul>
              <li><strong>Manchester Red</strong> — full-flavour classic</li>
              <li><strong>Manchester Royal Red</strong> — rich, bold taste</li>
              <li><strong>Manchester Classic Gold</strong> — smooth and balanced</li>
              <li><strong>Manchester Lights</strong> — lighter option</li>
              <li><strong>Manchester Sapphire Blue</strong> — cool menthol flavour</li>
              <li><strong>Manchester Double Drive</strong> — dual capsule</li>
              <li><strong>Manchester Green Crush</strong> — menthol crush</li>
              <li><strong>Manchester Blue Crush</strong> — ice-cool menthol</li>
              <li><strong>Manchester Reserve</strong> — premium blend</li>
              <li><strong>Manchester Special Edition</strong> — limited edition</li>
            </ul>
            <h3>Why Buy Manchester from Aussie Smoke Store?</h3>
            <ul>
              <li><strong>Cheapest prices in Australia</strong> — save up to 70% vs retail</li>
              <li><strong>Buy by the carton</strong> — 10 packets × 20 cigarettes per carton</li>
              <li><strong>Free shipping</strong> over A$50</li>
              <li><strong>Discreet packaging</strong> — plain parcels for your privacy</li>
              <li><strong>Australia-wide delivery</strong> — every state and territory</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/marlboro-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Marlboro Australia</Link>
            <Link to="/benson-hedges-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Benson &amp; Hedges</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/bulk-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Bulk Cigarettes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Manchester Cigarettes — Our Range</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Manchester Cigarettes FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default ManchesterCigarettesAustralia;
