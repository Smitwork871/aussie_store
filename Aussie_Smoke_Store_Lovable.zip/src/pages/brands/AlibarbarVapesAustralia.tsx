import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy Alibarbar vapes online in Australia?', answer: 'Aussie Smoke Store stocks the full range of Alibarbar PRO 12000 Ice Adjust disposable vapes with 15+ flavours available for fast delivery across Australia.' },
  { question: 'How many puffs does an Alibarbar PRO 12000 last?', answer: 'The Alibarbar PRO 12000 delivers approximately 12,000 puffs per device with adjustable ice/cooling levels, making it one of the longest-lasting disposable vapes on the market.' },
  { question: 'What is the Ice Adjust feature on Alibarbar vapes?', answer: 'The Ice Adjust feature lets you control the cooling intensity of your vape — from no ice to maximum chill — giving you a customised vaping experience with every puff.' },
  { question: 'What Alibarbar flavours are available?', answer: 'We stock 15+ flavours including Blueberry, Grape, Mango, Watermelon Ice, Strawberry Kiwi, Skittles, Chupa Chups Strawberry, Passionfruit Mango Lime, and many more.' },
];

const AlibarbarVapesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .ilike('brand', '%Alibarbar%')
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
        if (fallback) setProducts(fallback as Product[]);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Buy Alibarbar Vapes Online Australia — PRO 12000 Ice Adjust"
        description="Buy Alibarbar PRO 12000 Ice Adjust disposable vapes online in Australia. 15+ flavours, adjustable cooling. Cheapest prices, free shipping over A$50."
        canonical="/alibarbar-vapes-australia"
        keywords="Alibarbar vapes Australia, buy Alibarbar PRO 12000, Alibarbar Ice Adjust, cheap Alibarbar vapes, disposable vapes Australia, 12000 puff vape Australia, Alibarbar flavours"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Alibarbar Vapes Australia', url: '/alibarbar-vapes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Alibarbar Vapes Online Australia
              <span className="text-primary block mt-2">PRO 12000 Ice Adjust — 15+ Flavours</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Get the <strong>Alibarbar PRO 12000 Ice Adjust</strong> at Australia's cheapest prices. Adjustable cooling, 12,000 puffs, and 15+ delicious flavours — delivered fast &amp; discreetly.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Alibarbar <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Alibarbar PRO 12000 — Australia's Best Ice Adjust Vape</h2>
            <p>
              The <strong>Alibarbar PRO 12000 Ice Adjust</strong> is one of the most popular disposable vapes in Australia. With its unique adjustable cooling system and massive 12,000 puff capacity, it delivers exceptional value and flavour.
            </p>
            <h3>All Alibarbar Flavours</h3>
            <ul>
              <li>Blueberry · Blueberry-Blackberry · Blackberry Cherry Pomegranate</li>
              <li>Grape · Raspberry Grape · Mango</li>
              <li>Watermelon Ice · Strawberry Watermelon · Strawberry Kiwi</li>
              <li>Strawberry Raspberry · Kiwi Pineapple · Passionfruit Mango Lime</li>
              <li>Orange Fanta Soda · Chupa Chups Strawberry · Skittles</li>
            </ul>
            <h3>Why Buy Alibarbar from Aussie Smoke Store?</h3>
            <ul>
              <li><strong>12,000 puffs</strong> — longest-lasting disposable</li>
              <li><strong>Ice Adjust</strong> — control your cooling level</li>
              <li><strong>Cheapest prices</strong> in Australia</li>
              <li><strong>Free shipping</strong> over A$50</li>
              <li><strong>15+ flavours</strong> always in stock</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/uwell-vapes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">UWELL Vapes</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes Online</Link>
            <Link to="/vape-guide-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Vape Guide</Link>
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Alibarbar Vapes — Our Range</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Alibarbar Vapes FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default AlibarbarVapesAustralia;
