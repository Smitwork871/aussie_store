import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/marlboro-ice-blast-australia',
  metaTitle: 'Marlboro Ice Blast Australia — Buy Online Cheap',
  metaDescription: 'Buy Marlboro Ice Blast cigarettes online in Australia. Menthol capsule cigarettes at the cheapest carton prices. Free shipping over A$50, 48h dispatch.',
  metaKeywords: 'marlboro ice blast, marlboro ice blast australia, buy marlboro ice blast online, marlboro menthol australia, marlboro capsule cigarettes, marlboro ice blast price',
  breadcrumbName: 'Marlboro Ice Blast Australia',
  h1Line1: 'Marlboro Ice Blast',
  h1Line2: 'Cigarettes — Australia\'s Best Price',
  heroParagraph:
    'Get <strong>Marlboro Ice Blast</strong> — the famous menthol capsule cigarette — delivered Australia-wide at the cheapest carton prices online. Free shipping over A$50.',
  subject: 'Marlboro Ice Blast',
  productFilter: { column: 'name', pattern: '%ice blast%' },
  bodyHtml: `
    <h2>Marlboro Ice Blast — the menthol capsule classic</h2>
    <p><strong>Marlboro Ice Blast</strong> features Marlboro's signature crushable menthol capsule — crush for an instant fresh menthol burst, leave for a classic Marlboro draw. It's the most-searched Marlboro variant in Australia and we keep it in regular stock.</p>
    <h3>Why Marlboro Ice Blast?</h3>
    <ul>
      <li>Switchable taste — classic Marlboro or menthol on demand</li>
      <li>Premium tobacco, signature Marlboro quality</li>
      <li>Carton format: 10 packets × 20 cigarettes</li>
    </ul>
    <h3>Cheapest Marlboro Ice Blast carton prices in Australia</h3>
    <p>We re-price weekly to remain the cheapest Marlboro Ice Blast retailer online. Click any product above for live carton pricing and stock levels.</p>
    <h3>Other Marlboro variants</h3>
    <ul>
      <li><a href="/marlboro-red-cigarettes-australia">Marlboro Red</a> — full-flavour classic</li>
      <li><a href="/marlboro-cigarettes-australia">Marlboro Gold & all variants</a></li>
    </ul>
  `,
  faqs: [
    { question: 'Are Marlboro Ice Blast menthol cigarettes?', answer: 'Yes — Marlboro Ice Blast contains a crushable menthol capsule in the filter. Crush it for a menthol burst, leave it intact for a classic Marlboro taste.' },
    { question: 'How much is a Marlboro Ice Blast carton?', answer: 'Live pricing appears on the product cards above. Our Marlboro Ice Blast carton is consistently the cheapest in Australia.' },
    { question: 'Are these genuine Marlboro cigarettes?', answer: 'Yes — all Marlboro products at Aussie Smoke Store are 100% genuine, supplied in sealed manufacturer cartons.' },
    { question: 'How fast does Marlboro Ice Blast ship?', answer: '48-hour dispatch from our AU warehouse. Metro 3–5 business days, regional 5–7 business days.' },
    { question: 'Do you offer free shipping on Marlboro Ice Blast?', answer: 'Yes — free shipping on all orders over A$50. Smaller orders ship for a flat A$10.' },
  ],
};

const MarlboroIceBlastAustralia = () => <BrandLandingPage config={config} />;
export default MarlboroIceBlastAustralia;
