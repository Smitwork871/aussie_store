import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy Benson & Hedges cigarettes online in Australia?', answer: 'Yes! Aussie Smoke Store stocks Benson & Hedges Gold and Benson & Hedges Gold Special Filter at Australia\'s cheapest online prices with fast, discreet delivery.' },
  { question: 'How much are Benson & Hedges cigarettes online?', answer: 'Our Benson & Hedges cigarettes are priced significantly below Australian retail. Buy by the carton (10 packets × 20 cigarettes) for maximum savings, plus free shipping over A$50.' },
  { question: 'What Benson & Hedges varieties do you stock?', answer: 'We currently stock Benson & Hedges Gold and Benson & Hedges Gold Special Filter in cartons of 10 packets.' },
  { question: 'Is Benson & Hedges a premium cigarette brand?', answer: 'Yes, Benson & Hedges (B&H) is one of the world\'s most recognised premium cigarette brands, known for its smooth, refined taste and iconic gold packaging.' },
];

const BensonHedgesCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .ilike('brand', '%B & H%')
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
        if (fallback) setProducts(fallback as Product[]);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Benson & Hedges Cigarettes Australia"
        description="Buy Benson & Hedges cigarettes online in Australia at the cheapest prices. B&H Gold & Special Filter. Free shipping over A$50. Discreet delivery Australia-wide."
        canonical="/benson-hedges-cigarettes-australia"
        keywords="Benson and Hedges cigarettes Australia, buy B&H cigarettes online, Benson Hedges Gold Australia, cheap Benson Hedges, B&H cigarettes price Australia, premium cigarettes Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Benson & Hedges Australia', url: '/benson-hedges-cigarettes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Benson &amp; Hedges Online
              <span className="text-primary block mt-2">Premium Cigarettes — Cheapest Prices</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Get <strong>Benson &amp; Hedges cigarettes</strong> delivered Australia-wide at unbeatable prices. B&amp;H Gold and Special Filter — the premium choice at a budget price.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop B&amp;H <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Benson &amp; Hedges Cigarettes — Premium Quality, Budget Price</h2>
            <p>
              <strong>Benson &amp; Hedges</strong> is one of the world's most iconic premium cigarette brands. At Aussie Smoke Store, we bring this luxury brand to Australian smokers at a fraction of the retail cost. Whether you prefer the smooth <strong>B&amp;H Gold</strong> or the refined <strong>Gold Special Filter</strong>, we've got you covered.
            </p>
            <h3>B&amp;H Range Available</h3>
            <ul>
              <li><strong>Benson &amp; Hedges Gold</strong> — smooth, classic premium taste</li>
              <li><strong>Benson &amp; Hedges Gold Special Filter</strong> — refined filtration for a lighter draw</li>
            </ul>
            <h3>Why Buy B&amp;H from Aussie Smoke Store?</h3>
            <ul>
              <li><strong>Premium brand at budget prices</strong> — save up to 70% vs retail</li>
              <li><strong>Carton deals</strong> — 10 packets × 20 cigarettes</li>
              <li><strong>Free shipping</strong> over A$50</li>
              <li><strong>Australia-wide delivery</strong> — all states and territories</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/marlboro-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Marlboro Australia</Link>
            <Link to="/manchester-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Manchester Cigarettes</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/best-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Best Cigarettes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Benson &amp; Hedges — Our Range</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Benson &amp; Hedges FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BensonHedgesCigarettesAustralia;
