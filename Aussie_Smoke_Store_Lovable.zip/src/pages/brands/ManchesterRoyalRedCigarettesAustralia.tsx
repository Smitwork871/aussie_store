import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/manchester-royal-red-cigarettes-australia',
  metaTitle: 'Manchester Royal Red Cigarettes Australia — Buy Online',
  metaDescription: 'Buy Manchester Royal Red cigarettes online in Australia. Cheapest carton prices, free shipping over A$50, 48h dispatch. Genuine AU stock.',
  metaKeywords: 'manchester royal red, manchester royal red cigarettes, manchester red australia, buy manchester red online, manchester royal red price',
  breadcrumbName: 'Manchester Royal Red Australia',
  h1Line1: 'Manchester Royal Red',
  h1Line2: 'Cigarettes — Best Price Online',
  heroParagraph:
    '<strong>Manchester Royal Red</strong> — full-flavour, classic blend — delivered Australia-wide. Cheapest carton prices online, free shipping over A$50, dispatched in 48 hours.',
  subject: 'Manchester Royal Red',
  productFilter: { column: 'name', pattern: '%royal red%' },
  bodyHtml: `
    <h2>Manchester Royal Red — the full-flavour classic</h2>
    <p><strong>Manchester Royal Red</strong> is the brand's flagship full-flavour cigarette — rich, smooth, and consistent pack to pack. It's one of the most-searched Manchester variants in Australia and we keep it in regular stock to dispatch within 48 hours.</p>
    <h3>What's in a carton?</h3>
    <ul>
      <li>10 packets × 20 cigarettes (200 sticks total)</li>
      <li>Sealed manufacturer carton</li>
      <li>Tracked Australia-wide delivery</li>
    </ul>
    <h3>Why buy Manchester Royal Red from Aussie Smoke Store?</h3>
    <ul>
      <li>Lowest carton prices in Australia — verified against major competitors weekly</li>
      <li>48-hour dispatch from Australian warehouse</li>
      <li>Free shipping on orders over A$50</li>
      <li>Discreet packaging, tracked delivery</li>
    </ul>
    <h3>Other Manchester variants</h3>
    <p>Browse the full <a href="/manchester-cigarettes-australia">Manchester range</a>, or compare with <a href="/manchester-double-drive-australia">Manchester Double Drive</a> and <a href="/manchester-sapphire-blue-australia">Manchester Sapphire Blue</a>.</p>
  `,
  faqs: [
    { question: 'How much is a carton of Manchester Royal Red?', answer: 'Carton pricing updates weekly. See live pricing on the product cards above — our Royal Red price is consistently the lowest in Australia.' },
    { question: 'Is Manchester Royal Red full-flavour or light?', answer: 'Royal Red is the full-flavour Manchester variant. For a milder blend, look at Manchester Sapphire Blue.' },
    { question: 'Can I order Manchester Royal Red from anywhere in Australia?', answer: 'Yes — we ship to every Australian postcode, metro and regional, with tracked delivery.' },
    { question: 'How long does delivery take?', answer: 'We dispatch within 48 hours. Metro 3–5 business days, regional 5–7 business days.' },
    { question: 'Are these the genuine Manchester Royal Red product?', answer: 'Yes. 100% genuine, sealed manufacturer cartons sourced through legitimate channels.' },
  ],
};

const ManchesterRoyalRedCigarettesAustralia = () => <BrandLandingPage config={config} />;
export default ManchesterRoyalRedCigarettesAustralia;
