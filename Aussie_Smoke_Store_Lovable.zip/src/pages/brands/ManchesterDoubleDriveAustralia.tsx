import { BrandLandingPage, BrandLandingConfig } from '@/components/seo/BrandLandingPage';

const config: BrandLandingConfig = {
  path: '/manchester-double-drive-australia',
  metaTitle: 'Manchester Double Drive Cigarettes Australia — Cheapest Online',
  metaDescription: 'Buy Manchester Double Drive cigarettes online in Australia. Cheapest carton prices, free shipping over A$50, 48h dispatch from AU stock. Order now.',
  metaKeywords: 'manchester double drive, manchester double drive cigarettes, manchester double drive australia, buy manchester double drive online, manchester double drive price, cheap manchester cigarettes',
  breadcrumbName: 'Manchester Double Drive Australia',
  h1Line1: 'Manchester Double Drive',
  h1Line2: 'Cigarettes — Cheapest in Australia',
  heroParagraph:
    'Buy <strong>Manchester Double Drive</strong> cigarettes online in Australia at the lowest prices anywhere. Genuine product, fast 48-hour dispatch, free shipping on orders over A$50.',
  subject: 'Manchester Double Drive',
  productFilter: { column: 'name', pattern: '%double drive%' },
  bodyHtml: `
    <h2>Why Manchester Double Drive?</h2>
    <p><strong>Manchester Double Drive</strong> is one of the most popular Manchester variants in Australia — known for its rich, full-bodied flavour and smooth crushable capsule. At Aussie Smoke Store we sell Double Drive by the carton (10 packets × 20 cigarettes) at prices well below tobacconist retail.</p>
    <h3>Manchester Double Drive carton price</h3>
    <p>Carton pricing changes weekly based on stock. Click through to a product page above for live pricing. Most cartons ship the same business day from our Australian warehouse.</p>
    <h3>Authentic Australian stock</h3>
    <ul>
      <li>100% genuine Manchester Double Drive — sealed cartons</li>
      <li>Held in Australian-based stock — no overseas customs delay</li>
      <li>Dispatched within 48 hours of payment confirmation</li>
      <li>Tracked, discreet delivery to every Australian postcode</li>
    </ul>
    <h3>Compare Manchester Double Drive vs other variants</h3>
    <p>Also worth considering: <a href="/manchester-cigarettes-australia">Manchester (all variants)</a>, <a href="/manchester-royal-red-cigarettes-australia">Manchester Royal Red</a>, and <a href="/manchester-sapphire-blue-australia">Manchester Sapphire Blue</a>. All three sit in the same price bracket and ship from the same warehouse.</p>
  `,
  faqs: [
    { question: 'Can I buy Manchester Double Drive online in Australia?', answer: "Yes — Aussie Smoke Store stocks Manchester Double Drive cartons (10 × 20s) for delivery to every Australian postcode with free shipping on orders over A$50." },
    { question: 'How much is a carton of Manchester Double Drive?', answer: 'Carton pricing varies week to week. Click any product above for live pricing — our Manchester carton prices are consistently below tobacconist and supermarket retail.' },
    { question: 'How fast does Manchester Double Drive ship?', answer: 'We dispatch within 48 hours of payment. Metro areas typically receive within 3–5 business days; regional Australia 5–7 business days.' },
    { question: 'Are these genuine Manchester cigarettes?', answer: 'Yes. All Manchester products at Aussie Smoke Store are 100% genuine, supplied in sealed manufacturer cartons.' },
    { question: 'Do you offer bulk discounts on Manchester Double Drive?', answer: 'Orders over A$50 ship free. For very large orders (multiple cartons), contact us via the contact form for a custom quote.' },
  ],
};

const ManchesterDoubleDriveAustralia = () => <BrandLandingPage config={config} />;
export default ManchesterDoubleDriveAustralia;
