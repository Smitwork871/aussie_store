import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy Double Happiness cigarettes in Australia?', answer: 'Aussie Smoke Store stocks Double Happiness and Double Happiness Red cigarettes in cartons of 10 packets at Australia\'s cheapest online prices with fast, discreet delivery.' },
  { question: 'What is Double Happiness?', answer: 'Double Happiness (双喜) is one of China\'s oldest and most iconic cigarette brands, established in 1906. Known for its smooth taste and affordable price, it has become popular with Australian smokers seeking quality at a budget price.' },
  { question: 'What Double Happiness varieties do you stock?', answer: 'We stock Double Happiness Classic and Double Happiness Red, both available in cartons of 10 packets × 20 cigarettes.' },
  { question: 'How much do Double Happiness cigarettes cost?', answer: 'Double Happiness cigarettes at Aussie Smoke Store are priced well below Australian retail. Buy by the carton for the best savings, plus free shipping on orders over A$50.' },
];

const DoubleHappinessCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .ilike('brand', '%Double Happiness%')
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
        if (fallback) setProducts(fallback as Product[]);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Double Happiness Cigarettes Australia"
        description="Buy Double Happiness cigarettes online in Australia. Classic & Red varieties at cheapest prices. Free shipping over A$50. Fast, discreet delivery Australia-wide."
        canonical="/double-happiness-cigarettes-australia"
        keywords="Double Happiness cigarettes Australia, buy Double Happiness online, cheap Double Happiness cigarettes, Double Happiness Red Australia, Chinese cigarettes Australia, budget cigarettes Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Double Happiness Cigarettes', url: '/double-happiness-cigarettes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Double Happiness Cigarettes
              <span className="text-primary block mt-2">Cheapest Prices in Australia</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Get <strong>Double Happiness cigarettes</strong> — one of the world's most iconic brands — delivered to your door at Australia's lowest online prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Double Happiness — A Legendary Cigarette Brand</h2>
            <p>
              <strong>Double Happiness</strong> (双喜) has been a household name since 1906, making it one of the oldest cigarette brands in the world. Known for its smooth, satisfying taste and exceptional value, it has become a favourite among Australian smokers looking for quality without the premium price tag.
            </p>
            <h3>Varieties Available</h3>
            <ul>
              <li><strong>Double Happiness Classic</strong> — timeless, smooth flavour</li>
              <li><strong>Double Happiness Red</strong> — bolder, richer taste</li>
            </ul>
            <h3>Why Buy Double Happiness from Aussie Smoke Store?</h3>
            <ul>
              <li><strong>Cheapest prices</strong> — far below Australian retail</li>
              <li><strong>Carton deals</strong> — 10 packets × 20 cigarettes</li>
              <li><strong>Free shipping</strong> over A$50</li>
              <li><strong>Discreet packaging</strong> for your privacy</li>
              <li><strong>Australia-wide delivery</strong> — all states and territories</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/manchester-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Manchester Cigarettes</Link>
            <Link to="/marlboro-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Marlboro Australia</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/bulk-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Bulk Cigarettes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Double Happiness — Our Range</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Double Happiness FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default DoubleHappinessCigarettesAustralia;
