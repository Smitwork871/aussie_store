import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy UWELL vapes online in Australia?', answer: 'Aussie Smoke Store stocks a huge range of UWELL vapes including the UWELL 7000 and UWELL VANSEBAR series. Order online for fast, discreet delivery across Australia.' },
  { question: 'How many puffs does a UWELL 7000 last?', answer: 'The UWELL 7000 delivers approximately 7,000 puffs per device, making it one of the best value disposable vapes available in Australia.' },
  { question: 'What UWELL VANSEBAR flavours do you stock?', answer: 'We stock a wide range of UWELL VANSEBAR 12000 flavours including Berry Boost, Blue Razz Ice, Grape Ice, Mango Ice, Strawberry Watermelon, Watermelon Ice, and many more.' },
  { question: 'Are UWELL vapes good quality?', answer: 'UWELL is one of the world\'s leading vape manufacturers, known for excellent flavour production, long battery life, and reliable performance. Their disposable range is a top seller in Australia.' },
];

const UwellVapesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .ilike('brand', '%UWELL%')
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase.from('public_products').select('*').eq('is_active', true).order('is_featured', { ascending: false }).limit(12);
        if (fallback) setProducts(fallback as Product[]);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Buy UWELL Vapes Online Australia — UWELL 7000 & VANSEBAR"
        description="Buy UWELL vapes online in Australia. UWELL 7000 puff & VANSEBAR 12000 puff disposable vapes at cheapest prices. 30+ flavours. Free shipping over A$50."
        canonical="/uwell-vapes-australia"
        keywords="UWELL vapes Australia, buy UWELL 7000 online, UWELL VANSEBAR Australia, cheap UWELL vapes, disposable vapes Australia, UWELL 7000 puffs, best vapes Australia, UWELL vape flavours"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'UWELL Vapes Australia', url: '/uwell-vapes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy UWELL Vapes Online Australia
              <span className="text-primary block mt-2">UWELL 7000 &amp; VANSEBAR 12000</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Australia's biggest range of <strong>UWELL disposable vapes</strong> at the cheapest prices. 30+ flavours in the UWELL 7000 and VANSEBAR 12000 series — delivered fast &amp; discreetly.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop UWELL Vapes <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>UWELL Vapes — Australia's Favourite Disposable Vapes</h2>
            <p>
              <strong>UWELL</strong> is a global leader in vape technology, and their disposable range is hugely popular in Australia. At Aussie Smoke Store, we stock the full range of <strong>UWELL 7000</strong> (7,000 puffs) and <strong>UWELL VANSEBAR 12000</strong> (12,000 puffs) at the cheapest prices online.
            </p>
            <h3>UWELL 7000 — Popular Flavours</h3>
            <ul>
              <li>Banana Ice, Blueberry Ice, Grape Ice, Mango Ice</li>
              <li>Strawberry Watermelon, Watermelon Melon Ice</li>
              <li>Blue Razz Ice, Cherry Pomegranate, Dragon Fruit Berry</li>
              <li>Chupa Chups Strawberry, Hubba Bubba Grape</li>
              <li>Miami Mint, Tropical Rainbow Blast, and more</li>
            </ul>
            <h3>UWELL VANSEBAR 12000 — Extended Puff Range</h3>
            <ul>
              <li>Berry Boost, Blue Razz Ice, Grape Ice</li>
              <li>Mango Ice, Strawberry Watermelon, Watermelon Ice</li>
              <li>Berry Cherry Pom, Blackberry Breeze, and more</li>
            </ul>
            <h3>Why Buy UWELL from Aussie Smoke Store?</h3>
            <ul>
              <li><strong>Cheapest prices</strong> — guaranteed lowest online prices</li>
              <li><strong>30+ flavours</strong> in stock</li>
              <li><strong>Free shipping</strong> over A$50</li>
              <li><strong>Discreet delivery</strong> — plain packaging Australia-wide</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/alibarbar-vapes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Alibarbar Vapes</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes Online</Link>
            <Link to="/vape-guide-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Vape Guide</Link>
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">UWELL Vapes — Our Range</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">UWELL Vapes FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default UwellVapesAustralia;
