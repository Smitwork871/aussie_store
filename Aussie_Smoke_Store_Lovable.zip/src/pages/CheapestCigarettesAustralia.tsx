import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What are the cheapest cigarettes in Australia?', answer: 'Aussie Smoke Store offers the cheapest cigarettes in Australia from brands like Manchester, Marlboro, Benson & Hedges and more. Our prices are significantly lower than retail tobacco shops.' },
  { question: 'How much do the cheapest cigarettes cost online in Australia?', answer: 'Prices vary by brand, but our cheapest cigarettes start from just a fraction of retail price. Check our products page for current pricing — we update regularly to ensure the best deals.' },
  { question: 'Can I buy the cheapest cigarettes in bulk?', answer: 'Yes! We offer bulk pricing on cartons and multi-packs. The more you buy, the more you save. Plus free shipping Australia-wide on orders over A$50.' },
  { question: 'Which Australian city has the cheapest cigarette prices?', answer: 'With Aussie Smoke Store, you get the same cheap prices no matter where you are in Australia — Sydney, Melbourne, Brisbane, Perth, Adelaide, or anywhere else. We deliver nationwide.' },
];

const CheapestCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('price', { ascending: true })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheapest Cigarettes in Australia 2026 — Lowest Prices Online"
        description="Find the cheapest cigarettes in Australia at Aussie Smoke Store. Compare prices on Marlboro, Manchester, Benson & Hedges and more. Free shipping over A$50."
        canonical="/cheapest-cigarettes-australia"
        keywords="cheapest cigarettes Australia, cheapest cigarettes in Australia, cheapest smokes Australia, cheapest cigarettes online Australia, cheapest cigarettes Australia 2026, lowest price cigarettes Australia, cheapest cigarette brand Australia, cheapest darts Australia"
        jsonLd={[
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheapest Cigarettes Australia', url: '/cheapest-cigarettes-australia' }]),
          faqJsonLd(FAQS),
          localBusinessJsonLd(),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16">
        <div className="container max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-center">
            Cheapest Cigarettes in Australia — 2026
          </h1>
          <p className="text-lg text-muted-foreground text-center mb-8 max-w-2xl mx-auto">
            Looking for the <strong>cheapest cigarettes in Australia</strong>? Aussie Smoke Store has the lowest prices on all major cigarette brands — delivered anywhere in Australia with <strong>free shipping over A$50</strong>.
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" asChild>
              <Link to="/products">See All Prices <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/cigarette-prices-australia">Price Guide 2026</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Cheapest Cigarettes — Sorted by Price</h2>
          <ProductGrid products={products} isLoading={isLoading} />
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">Finding the Cheapest Cigarettes in Australia in 2026</h2>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
            <p>With cigarette prices in Australia among the highest in the world thanks to excise taxes, finding the <strong>cheapest cigarettes</strong> is a top priority for Australian smokers. Aussie Smoke Store offers prices significantly below retail.</p>
            <p>Our range covers every popular brand: <strong>Marlboro Red</strong>, <strong>Marlboro Gold</strong>, <strong>Manchester</strong>, <strong>Benson &amp; Hedges</strong>, <strong>Peter Jackson</strong>, <strong>Winfield</strong> and more. We also carry <Link to="/cheap-rolling-tobacco-online" className="text-primary hover:underline">cheap rolling tobacco</Link> and <Link to="/cheap-vapes-online" className="text-primary hover:underline">cheap vapes</Link> for those looking for alternatives.</p>
            <p>Whether you call them cigarettes, <Link to="/cheap-darts-online" className="text-primary hover:underline">darts</Link>, <Link to="/cheap-durries-online" className="text-primary hover:underline">durries</Link> or smokes — we guarantee the <strong>cheapest prices in Australia</strong>.</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">FAQ — Cheapest Cigarettes Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl text-center">
          <h2 className="text-2xl font-bold mb-4">Related Searches</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/cheap-smokes-online" className="text-primary hover:underline">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="text-primary hover:underline">Cheap Cigarettes Online</Link>
            <Link to="/cigarette-prices-australia" className="text-primary hover:underline">Cigarette Prices Australia 2026</Link>
            <Link to="/best-cigarettes-australia" className="text-primary hover:underline">Best Cigarettes Australia</Link>
            <Link to="/discount-tobacco-online" className="text-primary hover:underline">Discount Tobacco Online</Link>
            <Link to="/buy-cigarettes-online-australia" className="text-primary hover:underline">Buy Cigarettes Online Australia</Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapestCigarettesAustralia;
