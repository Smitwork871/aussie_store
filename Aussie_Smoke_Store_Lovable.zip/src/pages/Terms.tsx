import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { SEOHead } from '@/components/SEOHead';

const Terms = () => {
  return (
    <Layout>
      <SEOHead
        title="Terms of Service"
        description="Aussie Smoke Store terms of service. Read our terms and conditions for using our website and purchasing tobacco products."
        canonical="/terms"
      />
      <div className="container py-12">
        <div className="max-w-3xl mx-auto prose prose-gray">
          <h1>Terms of Service</h1>
          <p className="lead">
            Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>

          <h2>1. Age Requirement</h2>
          <p>
            You must be at least 21 years of age to use this website and purchase products.
            By using our services, you confirm that you meet this age requirement.
            We reserve the right to verify your age at any time.
          </p>

          <h2>2. Account Registration</h2>
          <p>
            When you create an account, you must provide accurate and complete information.
            You are responsible for maintaining the security of your account and password.
            You agree to notify us immediately of any unauthorized access to your account.
          </p>

          <h2>3. Products and Pricing</h2>
          <p>
            All products are subject to availability. Prices are subject to change without notice.
            We reserve the right to limit quantities and refuse any order at our discretion.
          </p>

          <h2>4. Orders and Payment</h2>
          <p>
            By placing an order, you agree to pay the total amount including applicable taxes
            and shipping charges. We accept various payment methods as displayed during checkout.
            Orders are subject to verification and acceptance.
          </p>

          <h2>5. Shipping and Delivery</h2>
          <p>
            We ship to addresses within Australia. Delivery times are estimates and may vary.
            Risk of loss passes to you upon delivery. Adult signature may be required.
          </p>

          <h2>6. Returns and Refunds</h2>
          <p>
            Due to the nature of our products, we have specific return policies.
            Unopened products in original packaging may be returned within 7 days
            of delivery. Refunds will be processed to the original payment method.
          </p>

          <h2>7. Health Warnings</h2>
          <p>
            <strong>Statutory Warning:</strong> Cigarette smoking is injurious to health.
            Tobacco causes cancer. By purchasing our products, you acknowledge the health
            risks associated with tobacco use.
          </p>

          <h2>8. Intellectual Property</h2>
          <p>
            All content on this website, including text, graphics, logos, and images,
            is our property or the property of our licensors and is protected by
            intellectual property laws.
          </p>

          <h2>9. Limitation of Liability</h2>
          <p>
            To the maximum extent permitted by law, we shall not be liable for any
            indirect, incidental, special, or consequential damages arising from
            your use of our services or products.
          </p>

          <h2>10. Governing Law</h2>
          <p>
            These terms are governed by the laws of Australia. Any disputes shall be
            subject to the exclusive jurisdiction of the courts in Australia.
          </p>

          <h2>11. Contact Information</h2>
          <p>
            For questions about these Terms, please reach out via our{' '}
            <a href="/contact">contact form</a>.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Terms;
