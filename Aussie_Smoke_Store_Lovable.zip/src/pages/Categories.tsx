import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { Category } from '@/types/database';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { SEOHead, breadcrumbJsonLd } from '@/components/SEOHead';

const Categories = () => {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const { data: categories, isLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order', { ascending: true });

      if (error) throw error;
      return data as (Category & { parent_id: string | null })[];
    },
  });

  const parentCategories = categories?.filter(c => !c.parent_id) || [];
  const getSubcategories = (parentId: string) => categories?.filter(c => c.parent_id === parentId) || [];

  return (
    <Layout>
      <SEOHead
        title="Shop Cheap Cigarettes, Vapes & Tobacco by Category | Australia"
        description="Browse cheap cigarettes, vapes, rolling tobacco, tobacco pouches & smoking accessories by category. Best prices in Australia. Free shipping over A$50 at Aussie Smoke Store."
        canonical="/categories"
        keywords="cheap cigarettes categories, cheap smokes Australia, vapes online, rolling tobacco, tobacco pouches, smoking accessories"
        jsonLd={breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Categories', url: '/categories' }])}
      />
      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-2">Browse Categories</h1>
        <p className="text-muted-foreground mb-8">
          Explore our wide range of premium tobacco products
        </p>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i}>
                <CardHeader><Skeleton className="h-6 w-32" /></CardHeader>
                <CardContent>
                  <Skeleton className="h-40 w-full mb-4" />
                  <Skeleton className="h-4 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : parentCategories.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {parentCategories.map((category) => {
              const subs = getSubcategories(category.id);
              const isExpanded = expandedCategory === category.id;

              return (
                <Card key={category.id} className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <h2 className="text-2xl font-semibold leading-none tracking-tight flex items-center justify-between">
                      <Link to={`/products?category=${category.slug}`} className="hover:text-primary transition-colors flex-1">
                        {category.name}
                      </Link>
                      {subs.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setExpandedCategory(isExpanded ? null : category.id)}
                          aria-label={isExpanded ? `Collapse ${category.name} subcategories` : `Expand ${category.name} subcategories`}
                          aria-expanded={isExpanded}
                          className="p-1 hover:bg-muted rounded"
                        >
                          <ChevronDown className={`h-5 w-5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                        </button>
                      )}
                      {subs.length === 0 && (
                        <Link to={`/products?category=${category.slug}`} aria-label={`Shop ${category.name}`}>
                          <ArrowRight className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </Link>
                      )}
                    </h2>
                  </CardHeader>
                  <CardContent>
                    {category.image_url && (
                      <img src={category.image_url} alt={`${category.name} products available at Aussie Smoke Store`} className="w-full h-40 object-cover rounded-lg mb-4" loading="lazy" />
                    )}
                    {category.description && (
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-3">{category.description}</p>
                    )}
                    {subs.length > 0 && isExpanded && (
                      <div className="space-y-1 border-t pt-3">
                        {subs.map(sub => (
                          <Link
                            key={sub.id}
                            to={`/products?category=${sub.slug}`}
                            className="flex items-center justify-between py-2 px-3 rounded-md hover:bg-muted transition-colors text-sm"
                          >
                            <span>{sub.name}</span>
                            <ArrowRight className="h-4 w-4 text-muted-foreground" />
                          </Link>
                        ))}
                      </div>
                    )}
                    {subs.length > 0 && !isExpanded && (
                      <p className="text-xs text-muted-foreground">{subs.length} subcategories</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No categories available at the moment.</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Categories;
