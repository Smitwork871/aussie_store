import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { BookOpen, Grid2X2, Package, Search } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { SEOHead } from '@/components/SEOHead';
import { supabase } from '@/integrations/supabase/client';
import type { Product } from '@/types/database';

const shortcuts = [
  { to: '/categories', icon: Grid2X2, title: 'Categories', detail: 'Browse the catalogue by type' },
  { to: '/profile', icon: Package, title: 'My orders', detail: 'View your order history' },
  { to: '/contact', icon: BookOpen, title: 'Customer support', detail: 'Get help with an order' },
];

export default function Index() {
  const featured = useQuery({
    queryKey: ['home-featured'],
    retry: false,
    queryFn: async () => {
      const { data, error } = await supabase.from('public_products').select('*').eq('is_active', true).eq('is_featured', true).limit(8);
      if (error) throw error;
      return data as Product[];
    },
  });

  return (
    <Layout>
      <SEOHead title="Aussie Smoke Store | Store catalogue" description="Browse the catalogue, manage orders and contact customer support." canonical="/" />
      <section className="store-hero">
        <div className="container store-hero-inner">
          <div className="hero-copy">
            <p className="store-kicker">Aussie Smoke Store</p>
            <h1>The store<br /><em>catalogue.</em></h1>
            <form action="/products" role="search" className="catalogue-search">
              <Search size={20} aria-hidden="true" />
              <input type="search" name="search" aria-label="Search the catalogue" placeholder="Product name or brand" />
              <button>Search</button>
            </form>
          </div>
          <div className="catalogue-art" aria-hidden="true"><img src="/aussie-mark.png" className="catalogue-emblem" width="256" height="256" alt="" /></div>
        </div>
      </section>
      <div className="container">
        <nav aria-label="Store shortcuts" className="store-shortcuts">
          {shortcuts.map(({ to, icon: Icon, title, detail }) => (
            <Link key={to} to={to}><Icon size={24} strokeWidth={1.5} /><span><strong>{title}</strong><small>{detail}</small></span></Link>
          ))}
        </nav>
        <section className="py-12 md:py-16">
          <div className="flex items-center justify-between gap-4 mb-8">
            <h2 className="store-title">Featured products</h2><Link className="store-link" to="/products">View catalogue</Link>
          </div>
          {featured.isError ? <div role="status" className="catalogue-status"><p>Featured products are temporarily unavailable.</p><Button variant="outline" onClick={() => featured.refetch()}>Try again</Button></div> :
            <ProductGrid isLoading={featured.isLoading} products={featured.data ?? []} />}
        </section>
      </div>
    </Layout>
  );
}
