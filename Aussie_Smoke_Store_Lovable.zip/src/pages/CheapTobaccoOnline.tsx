import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap tobacco online in Australia?', answer: 'Aussie Smoke Store offers the widest range of cheap tobacco online in Australia — including rolling tobacco, cigarettes, tobacco pouches, and accessories. Free shipping on orders over A$50.' },
  { question: 'What types of tobacco do you sell online?', answer: 'We sell rolling tobacco (premium and regular), cigarettes from all major brands, tobacco pouches (Velo, ZYN), and tobacco accessories like filters, papers, lighters, tubes, and pipes.' },
  { question: 'Is buying tobacco online cheaper than retail?', answer: 'Yes! Buying tobacco online from Aussie Smoke Store saves you significantly compared to retail prices. We offer bulk discounts and free shipping on orders over A$50.' },
  { question: 'Do you ship tobacco to all of Australia?', answer: 'We ship to every Australian postcode — metro, regional, and remote. Standard delivery takes 3-7 business days with free shipping over A$50.' },
];

const CheapTobaccoOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Tobacco Online Australia — Buy Tobacco at Best Prices"
        description="Buy cheap tobacco online in Australia. Rolling tobacco, cigarettes, tobacco pouches & accessories at the lowest prices. Free shipping over A$50. Shop cheap tobacco online at Aussie Smoke Store."
        canonical="/cheap-tobacco-online"
        keywords="cheap tobacco online, buy tobacco online Australia, cheap tobacco Australia, rolling tobacco online, tobacco online Australia, cheap rolling tobacco, tobacco delivery Australia, bulk tobacco online Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Tobacco Online', url: '/cheap-tobacco-online' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Tobacco Online Australia
              <span className="text-primary block mt-2">All Types, Best Prices</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Shop <strong>cheap tobacco online</strong> — rolling tobacco, cigarettes, pouches & more. Australia's best prices with <strong>free shipping over A$50</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Shop All Tobacco <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-smokes-online">Cheap Smokes Online</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Tobacco Online in Australia</h2>
            <p>
              Aussie Smoke Store is your one-stop shop for <strong>cheap tobacco online</strong> in Australia. We carry everything from premium rolling tobacco to cigarettes and modern tobacco pouches — all at the lowest prices you'll find anywhere online.
            </p>
            <h3>Our Tobacco Product Range</h3>
            <ul>
              <li><strong>Cigarettes</strong> — All major brands including Marlboro, Winfield, Peter Stuyvesant, Camel, Dunhill</li>
              <li><strong>Rolling Tobacco</strong> — Premium and regular blends for the perfect roll-your-own experience</li>
              <li><strong>Tobacco Pouches</strong> — Velo and ZYN nicotine pouches for a smoke-free alternative</li>
              <li><strong>Vapes & E-cigarettes</strong> — U Well, Alibabar, Iget, Kuz disposable vapes</li>
              <li><strong>Accessories</strong> — Filters, rolling papers, lighters, tubes, and pipes</li>
            </ul>
            <h3>Why Choose Aussie Smoke Store for Tobacco?</h3>
            <p>
              We offer the <strong>cheapest tobacco prices</strong> in Australia with bulk savings, <strong>free shipping on orders over A$50</strong>, and fast, discreet delivery to every Australian postcode.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes Online</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes Online</Link>
            <Link to="/buy-cigarettes-online-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Buy Cigarettes Australia</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheap Tobacco — Best Sellers</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions — Cheap Tobacco Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapTobaccoOnline;
