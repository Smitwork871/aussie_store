import React, { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { supabase } from '@/integrations/supabase/client';
import { Product, Category } from '@/types/database';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd } from '@/components/SEOHead';

const Products = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [loadFailed, setLoadFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);

  const categorySlug = searchParams.get('category');
  const searchQuery = searchParams.get('search') || '';
  const sortBy = searchParams.get('sort') || 'newest';
  const featured = searchParams.get('featured') === 'true';

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order');
      
      if (data) setCategories(data as Category[]);
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    let current = true;
    const fetchProducts = async () => {
      setIsLoading(true);
      setLoadFailed(false);
      
      let query = supabase
        .from('public_products')
        .select('*, categories(*)')
        .eq('is_active', true);

      if (searchQuery) {
        // Sanitize search input to prevent PostgREST filter injection.
        // Strip characters with special meaning in .or() filter strings.
        const safeSearch = searchQuery
          .replace(/[,()*%\\]/g, ' ')
          .trim()
          .slice(0, 100);
        if (safeSearch) {
          query = query.or(`name.ilike.%${safeSearch}%,description.ilike.%${safeSearch}%,brand.ilike.%${safeSearch}%`);
        }
      }

      if (categorySlug) {
        const category = categories.find(c => c.slug === categorySlug);
        if (category) {
          // Check if this is a parent category - if so, include all subcategories
          const subcategoryIds = categories.filter(c => c.parent_id === category.id).map(c => c.id);
          if (subcategoryIds.length > 0 && !category.parent_id) {
            // Parent category: filter by parent + all its subcategories
            query = query.in('category_id', [category.id, ...subcategoryIds]);
          } else {
            query = query.eq('category_id', category.id);
          }
        }
      }

      if (featured) {
        query = query.eq('is_featured', true);
      }

      switch (sortBy) {
        case 'price-asc':
          query = query.order('price', { ascending: true });
          break;
        case 'price-desc':
          query = query.order('price', { ascending: false });
          break;
        case 'name':
          query = query.order('name', { ascending: true });
          break;
        default:
          query = query.order('created_at', { ascending: false });
      }

      const { data, error } = await query;
      if (!current) return;
      setLoadFailed(Boolean(error));
      
      if (data) {
        setProducts(data as Product[]);
      }
      setIsLoading(false);
    };

    fetchProducts();
    return () => { current = false; };
  }, [attempt, searchQuery, categorySlug, sortBy, featured, categories]);

  const handleSearch = (value: string) => {
    if (value) {
      searchParams.set('search', value);
    } else {
      searchParams.delete('search');
    }
    setSearchParams(searchParams);
  };

  const handleCategoryChange = (slug: string | null) => {
    if (slug) {
      searchParams.set('category', slug);
    } else {
      searchParams.delete('category');
    }
    setSearchParams(searchParams);
  };

  const handleSortChange = (value: string) => {
    searchParams.set('sort', value);
    setSearchParams(searchParams);
  };

  const clearFilters = () => {
    setSearchParams({});
  };

  const activeFiltersCount = [categorySlug, searchQuery, featured].filter(Boolean).length;

  return (
    <Layout>
      <SEOHead
        title={featured ? 'Featured Cheap Smokes Online' : categorySlug ? `Buy ${categories.find(c => c.slug === categorySlug)?.name || 'Products'} Online Australia — Cheap Prices` : 'Buy Cheap Cigarettes, Vapes & Tobacco Online Australia'}
        description={`Buy cheap ${categorySlug ? categories.find(c => c.slug === categorySlug)?.name?.toLowerCase() || 'tobacco products' : 'smokes, cigarettes, vapes and tobacco'} online in Australia at the best prices. Free shipping over A$50. Shop at Aussie Smoke Store.`}
        canonical="/products"
        keywords="cheap smokes online, cheap cigarettes online, buy cigarettes online Australia, cheap tobacco, cheap vapes online Australia"
        jsonLd={breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Products', url: '/products' }])}
      />
      <div className="container py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {featured ? 'Featured Products' : categorySlug ? categories.find(c => c.slug === categorySlug)?.name || 'Products' : 'All Products'}
          </h1>
          <p className="text-muted-foreground">
            {products.length} products found
          </p>
        </div>

        {/* Filters Bar */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              aria-label="Search products"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            {/* Main Category Dropdown */}
            <Select
              value={(() => {
                if (!categorySlug) return "all";
                const cat = categories.find(c => c.slug === categorySlug);
                if (cat?.parent_id) return categories.find(c => c.id === cat.parent_id)?.slug || "all";
                return categorySlug;
              })()}
              onValueChange={(value) => {
                if (value === "all") {
                  handleCategoryChange(null);
                } else {
                  handleCategoryChange(value);
                }
              }}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.filter(c => !c.parent_id).map((cat) => (
                  <SelectItem key={cat.id} value={cat.slug}>{cat.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Subcategory Dropdown */}
            {(() => {
              const mainSlug = (() => {
                if (!categorySlug) return null;
                const cat = categories.find(c => c.slug === categorySlug);
                if (cat?.parent_id) return categories.find(c => c.id === cat.parent_id)?.slug || null;
                return categorySlug;
              })();
              const mainCat = mainSlug ? categories.find(c => c.slug === mainSlug) : null;
              const subs = mainCat ? categories.filter(c => c.parent_id === mainCat.id) : [];
              if (subs.length === 0) return null;
              const currentIsSubSlug = categories.find(c => c.slug === categorySlug)?.parent_id ? categorySlug : "all_sub";
              return (
                <Select
                  value={currentIsSubSlug || "all_sub"}
                  onValueChange={(value) => {
                    if (value === "all_sub") {
                      handleCategoryChange(mainSlug);
                    } else {
                      handleCategoryChange(value);
                    }
                  }}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Subcategories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all_sub">All {mainCat?.name}</SelectItem>
                    {subs.map((sub) => (
                      <SelectItem key={sub.id} value={sub.slug}>{sub.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              );
            })()}

            <Select value={sortBy} onValueChange={handleSortChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-asc">Price: Low to High</SelectItem>
                <SelectItem value="price-desc">Price: High to Low</SelectItem>
                <SelectItem value="name">Name: A-Z</SelectItem>
              </SelectContent>
            </Select>

            <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="relative">
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  Filters
                  {activeFiltersCount > 0 && (
                    <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                      {activeFiltersCount}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  {/* Main Category */}
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">Main Category</Label>
                    <Select
                      value={(() => {
                        if (!categorySlug) return "all";
                        const cat = categories.find(c => c.slug === categorySlug);
                        if (cat?.parent_id) return categories.find(c => c.id === cat.parent_id)?.slug || "all";
                        return categorySlug;
                      })()}
                      onValueChange={(value) => {
                        if (value === "all") handleCategoryChange(null);
                        else handleCategoryChange(value);
                        setFiltersOpen(false);
                      }}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {categories.filter(c => !c.parent_id).map((cat) => (
                          <SelectItem key={cat.id} value={cat.slug}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Subcategory */}
                  {(() => {
                    const mainSlug = (() => {
                      if (!categorySlug) return null;
                      const cat = categories.find(c => c.slug === categorySlug);
                      if (cat?.parent_id) return categories.find(c => c.id === cat.parent_id)?.slug || null;
                      return categorySlug;
                    })();
                    const mainCat = mainSlug ? categories.find(c => c.slug === mainSlug) : null;
                    const subs = mainCat ? categories.filter(c => c.parent_id === mainCat.id) : [];
                    if (subs.length === 0) return null;
                    const currentIsSubSlug = categories.find(c => c.slug === categorySlug)?.parent_id ? categorySlug : "all_sub";
                    return (
                      <div className="space-y-2">
                        <Label className="text-base font-semibold">Subcategory</Label>
                        <Select
                          value={currentIsSubSlug || "all_sub"}
                          onValueChange={(value) => {
                            if (value === "all_sub") handleCategoryChange(mainSlug);
                            else handleCategoryChange(value);
                            setFiltersOpen(false);
                          }}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Subcategories" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all_sub">All {mainCat?.name}</SelectItem>
                            {subs.map((sub) => (
                              <SelectItem key={sub.id} value={sub.slug}>{sub.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    );
                  })()}

                  {activeFiltersCount > 0 && (
                    <Button variant="outline" onClick={clearFilters} className="w-full">
                      <X className="h-4 w-4 mr-2" />
                      Clear All Filters
                    </Button>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Active Filters */}
        {activeFiltersCount > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {categorySlug && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => handleCategoryChange(null)}
              >
                {categories.find(c => c.slug === categorySlug)?.name}
                <X className="h-3 w-3 ml-2" />
              </Button>
            )}
            {searchQuery && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => handleSearch('')}
              >
                Search: {searchQuery}
                <X className="h-3 w-3 ml-2" />
              </Button>
            )}
          </div>
        )}

        {/* Products Grid */}
        {loadFailed ? <div role="status" className="catalogue-status"><p>The catalogue could not be loaded.</p><Button variant="outline" onClick={() => setAttempt(n => n + 1)}>Try again</Button></div> : <ProductGrid products={products} isLoading={isLoading} />}
      </div>
    </Layout>
  );
};

export default Products;
