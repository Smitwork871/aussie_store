import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What is the best online smoke shop in Australia?', answer: 'Aussie Smoke Store is Australia\'s best online smoke shop, offering the cheapest cigarettes, rolling tobacco, vapes and smoking accessories with free shipping on orders over A$50.' },
  { question: 'Is it safe to buy from an online smoke shop in Australia?', answer: 'Yes! Aussie Smoke Store uses secure payment processing and discreet packaging. All products are genuine and sourced from authorised distributors.' },
  { question: 'What products does your online smoke shop sell?', answer: 'We sell cigarettes (Marlboro, Manchester, Benson & Hedges, etc.), rolling tobacco, vapes, nicotine pouches, tobacco pouches and smoking accessories.' },
];

const OnlineSmokeShopAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .eq('is_featured', true)
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Online Smoke Shop Australia — Cheapest Cigarettes & Tobacco"
        description="Australia's #1 online smoke shop. Buy cheap cigarettes, rolling tobacco, vapes & accessories online. Free shipping over A$50. Shop Aussie Smoke Store now."
        canonical="/online-smoke-shop-australia"
        keywords="online smoke shop Australia, smoke shop online Australia, cigarette shop online Australia, tobacco shop online Australia, buy smokes online Australia, online cigarette store Australia, online dart shop Australia"
        jsonLd={[
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Online Smoke Shop Australia', url: '/online-smoke-shop-australia' }]),
          faqJsonLd(FAQS),
          localBusinessJsonLd(),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16">
        <div className="container max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-center">
            Online Smoke Shop Australia
          </h1>
          <p className="text-lg text-muted-foreground text-center mb-8 max-w-2xl mx-auto">
            Welcome to Aussie Smoke Store — Australia's premier <strong>online smoke shop</strong>. Browse the cheapest cigarettes, rolling tobacco, vapes and accessories, all delivered to your door.
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/categories">Browse Categories</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8 text-center">Featured Products — Online Smoke Shop</h2>
          <ProductGrid products={products} isLoading={isLoading} />
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">Why Choose Our Online Smoke Shop?</h2>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
            <p>Aussie Smoke Store is not just another <strong>online smoke shop</strong> — we're Australia's most trusted destination for affordable tobacco products. Our <strong>online cigarette store</strong> offers:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Cheapest prices</strong> on cigarettes, rolling tobacco, and vapes in Australia</li>
              <li><strong>Free shipping</strong> Australia-wide on orders over A$50</li>
              <li><strong>All major brands</strong>: Marlboro, Manchester, Benson &amp; Hedges, Peter Jackson, Winfield</li>
              <li><strong>Fast delivery</strong>: 3-7 business days to any address in Australia</li>
              <li><strong>Secure payment</strong> and discreet packaging</li>
            </ul>
            <p>Whether you're after <Link to="/cheap-smokes-online" className="text-primary hover:underline">cheap smokes</Link>, <Link to="/cheap-vapes-online" className="text-primary hover:underline">cheap vapes</Link>, or <Link to="/cheap-rolling-tobacco-online" className="text-primary hover:underline">rolling tobacco</Link> — our online smoke shop has it all at the best prices in Australia.</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">FAQ — Online Smoke Shop Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl text-center">
          <h2 className="text-2xl font-bold mb-4">Related Searches</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/cheap-smokes-online" className="text-primary hover:underline">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="text-primary hover:underline">Cheap Cigarettes Online</Link>
            <Link to="/online-tobacco-shop-australia" className="text-primary hover:underline">Online Tobacco Shop Australia</Link>
            <Link to="/cheapest-cigarettes-australia" className="text-primary hover:underline">Cheapest Cigarettes Australia</Link>
            <Link to="/tobacco-delivery-australia" className="text-primary hover:underline">Tobacco Delivery Australia</Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default OnlineSmokeShopAustralia;
