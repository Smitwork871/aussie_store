import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What is the best online tobacco shop in Australia?', answer: 'Aussie Smoke Store is Australia\'s top-rated online tobacco shop. We offer the widest range of cigarettes, rolling tobacco, vapes, nicotine pouches, and accessories at the cheapest prices online.' },
  { question: 'What products can I buy from your online tobacco shop?', answer: 'Our online tobacco shop stocks cigarettes (Marlboro, Manchester, Winfield, Dunhill, Camel), rolling tobacco, nicotine pouches (Velo, ZYN), disposable vapes (U Well, Alibabar, Iget, Kuz), filters, papers, lighters, and more.' },
  { question: 'Is your online tobacco shop safe and discreet?', answer: 'Yes! We use secure payment methods and discreet packaging for all deliveries. Your privacy is our top priority, and all orders are shipped in plain packaging.' },
  { question: 'Do you have a minimum order for free shipping?', answer: 'Orders over A$50 qualify for free shipping to anywhere in Australia. Orders under A$50 have a flat-rate shipping fee displayed at checkout.' },
];

const OnlineTobaccoShopAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Online Tobacco Shop Australia"
        description="Australia's #1 online tobacco shop. Buy cigarettes, rolling tobacco, vapes, nicotine pouches & accessories at the cheapest prices. Free shipping over A$50. Aussie Smoke Store."
        canonical="/online-tobacco-shop-australia"
        keywords="online tobacco shop Australia, tobacco shop online, online smoke shop Australia, buy tobacco online Australia, cigarette shop online Australia, vape shop online Australia, tobacco store online, online tobacconist Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Online Tobacco Shop Australia', url: '/online-tobacco-shop-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Online Tobacco Shop Australia
              <span className="text-primary block mt-2">Your #1 Online Smoke Shop</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Welcome to Aussie Smoke Store — Australia's favourite <strong>online tobacco shop</strong>. Cigarettes, tobacco, vapes & more at the <strong>cheapest prices</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Shop Our Store <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/categories">Browse Categories</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Australia's Premier Online Tobacco Shop</h2>
            <p>
              Aussie Smoke Store is more than just an <strong>online tobacco shop</strong> — we're your one-stop destination for everything tobacco and nicotine in Australia. From premium cigarettes to budget-friendly rolling tobacco, we have it all.
            </p>
            <h3>Shop by Category</h3>
            <ul>
              <li><strong>Cigarettes</strong> — Full range of international and local brands at discount prices</li>
              <li><strong>Rolling Tobacco</strong> — Premium and regular blends for the perfect roll</li>
              <li><strong>Vapes & E-Cigarettes</strong> — Latest disposable vapes from top brands</li>
              <li><strong>Nicotine Pouches</strong> — Smoke-free alternatives from Velo and ZYN</li>
              <li><strong>Accessories</strong> — Papers, filters, lighters, tubes, pipes, and more</li>
            </ul>
            <h3>Why Shop at Aussie Smoke Store?</h3>
            <ul>
              <li>✅ <strong>Cheapest prices</strong> — guaranteed lowest prices online</li>
              <li>✅ <strong>Free shipping</strong> — on all orders over A$50</li>
              <li>✅ <strong>Australia-wide delivery</strong> — every postcode covered</li>
              <li>✅ <strong>Discreet packaging</strong> — plain packaging for your privacy</li>
              <li>✅ <strong>Secure payments</strong> — safe and encrypted transactions</li>
            </ul>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes Online</Link>
            <Link to="/discount-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Discount Tobacco</Link>
            <Link to="/buy-cheap-smokes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Buy Cheap Smokes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Featured Products from Our Store</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions — Online Tobacco Shop</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default OnlineTobaccoShopAustralia;
