import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight, MapPin, Truck, Shield, Clock } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const CITIES = [
  'Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide',
  'Gold Coast', 'Canberra', 'Hobart', 'Darwin', 'Cairns',
  'Newcastle', 'Wollongong', 'Geelong', 'Townsville', 'Toowoomba',
];

const FAQS = [
  { question: 'Can I buy cigarettes online in Australia?', answer: 'Yes! Aussie Smoke Store makes it easy to buy cigarettes online in Australia. We offer a huge range of premium cigarette brands at the cheapest prices with discreet, Australia-wide delivery.' },
  { question: 'How much does shipping cost for cigarettes in Australia?', answer: 'We offer FREE shipping on all orders over A$50. For orders under A$50, a flat shipping fee of A$10 applies. We deliver to every city and town across Australia.' },
  { question: 'What cigarette brands can I buy online?', answer: 'We stock all major cigarette brands including Marlboro, Winfield, Peter Stuyvesant, Camel, Lucky Strike, Dunhill, and many more. Browse our full range for the best selection.' },
  { question: 'How long does cigarette delivery take in Australia?', answer: 'Orders are dispatched within 1-3 business days. Standard delivery takes 3-7 business days depending on your location. Major cities like Sydney, Melbourne, and Brisbane typically receive orders faster.' },
  { question: 'Is it safe to buy cigarettes online?', answer: 'Absolutely. Aussie Smoke Store uses secure payment methods, discreet packaging, and ships only 100% authentic products from authorised distributors. Your privacy is our priority.' },
  { question: 'Do you deliver cigarettes to regional Australia?', answer: 'Yes, we deliver to all Australian postcodes — metro, regional, and remote areas. Free shipping applies on orders over A$50 regardless of location.' },
];

const BuyCigarettesOnlineAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data: cats } = await supabase
        .from('categories')
        .select('id')
        .or('slug.ilike.%cigarette%,name.ilike.%cigarette%')
        .eq('is_active', true);

      let query = supabase.from('public_products').select('*').eq('is_active', true);
      if (cats && cats.length > 0) {
        query = query.in('category_id', cats.map(c => c.id));
      }
      const { data } = await query.order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Buy Cigarettes Online Australia"
        description="Buy cigarettes online in Australia at the cheapest prices. All major brands delivered Australia-wide. Free shipping over A$50. Fast, discreet delivery to Sydney, Melbourne, Brisbane, Perth & more."
        canonical="/buy-cigarettes-online-australia"
        keywords="buy cigarettes online Australia, buy cigarettes online, cigarettes online Australia, order cigarettes online, cigarette delivery Australia, buy smokes online Australia, cheapest cigarettes online Australia, cigarettes delivered Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Buy Cigarettes Online Australia', url: '/buy-cigarettes-online-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      {/* Hero */}
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Cigarettes Online Australia
              <span className="text-primary block mt-2">Cheapest Prices, Free Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              <strong>Buy cigarettes online</strong> from Australia's most trusted online tobacco store. Premium brands at unbeatable prices with <strong>free shipping over A$50</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Shop All Cigarettes <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-smokes-online">Cheap Smokes Online</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Trust badges */}
      <section className="border-y bg-secondary/30 py-8">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="flex items-center gap-3 justify-center">
              <Truck className="h-8 w-8 text-primary" />
              <div><p className="font-semibold">Free Shipping</p><p className="text-sm text-muted-foreground">Orders over A$50</p></div>
            </div>
            <div className="flex items-center gap-3 justify-center">
              <Shield className="h-8 w-8 text-primary" />
              <div><p className="font-semibold">100% Authentic</p><p className="text-sm text-muted-foreground">Genuine products</p></div>
            </div>
            <div className="flex items-center gap-3 justify-center">
              <Clock className="h-8 w-8 text-primary" />
              <div><p className="font-semibold">Fast Dispatch</p><p className="text-sm text-muted-foreground">1-3 business days</p></div>
            </div>
            <div className="flex items-center gap-3 justify-center">
              <MapPin className="h-8 w-8 text-primary" />
              <div><p className="font-semibold">Australia-Wide</p><p className="text-sm text-muted-foreground">All postcodes</p></div>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Why Buy Cigarettes Online from Aussie Smoke Store?</h2>
            <p>
              Aussie Smoke Store is Australia's #1 destination to <strong>buy cigarettes online</strong>. We offer the widest selection of premium cigarette brands at the <strong>cheapest prices in Australia</strong>. Whether you're in Sydney, Melbourne, Brisbane, Perth, or anywhere across the country — we deliver right to your door.
            </p>
            <h3>Australia-Wide Cigarette Delivery</h3>
            <p>
              We ship cigarettes to every Australian city, town, and regional area. Our fast, discreet delivery service ensures your order arrives safely. <strong>Free shipping on all orders over A$50</strong> — the best deal for buying cigarettes online in Australia.
            </p>
            <h3>Premium Cigarette Brands at Cheap Prices</h3>
            <p>
              From classic brands like Marlboro and Winfield to premium options like Dunhill and Peter Stuyvesant — we stock them all at prices you won't find elsewhere. Buy cigarettes online in bulk and save even more with our volume discounts.
            </p>
          </div>

          {/* City targeting */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Buy Cigarettes Online — We Deliver Across Australia</h2>
            <div className="flex flex-wrap gap-3 justify-center">
              {CITIES.map(city => (
                <Link
                  key={city}
                  to={`/products`}
                  className="px-4 py-2 rounded-full bg-secondary/60 hover:bg-secondary transition-colors text-sm font-medium"
                >
                  Buy Cigarettes {city}
                </Link>
              ))}
            </div>
          </div>

          {/* Internal links */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes Online</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes Online</Link>
            <Link to="/cheap-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Tobacco Online</Link>
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Buy Cigarettes Online — Best Sellers</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Cigarettes <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions — Buy Cigarettes Online Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BuyCigarettesOnlineAustralia;
