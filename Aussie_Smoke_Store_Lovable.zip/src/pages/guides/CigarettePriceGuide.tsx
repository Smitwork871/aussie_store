import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What are the cheapest cigarette brands in Australia in 2026?', answer: 'The cheapest cigarette brands available online in Australia include Manchester, Bond Street, Horizon, and Holiday. At Aussie Smoke Store, we offer all these brands at prices significantly below retail tobacconists.' },
  { question: 'How much do cigarettes cost in Australia in 2026?', answer: 'Retail cigarette prices in Australia range from A$35-$60+ per pack due to excise taxes. Online stores like Aussie Smoke Store offer dramatically lower prices — browse our shop to see current pricing on all brands.' },
  { question: 'What is the most popular cigarette brand in Australia?', answer: 'Marlboro remains the most popular premium brand, while Winfield and Peter Jackson dominate the mid-range. For budget-conscious smokers, Manchester and Bond Street are top sellers at Aussie Smoke Store.' },
  { question: 'How much is a carton of Marlboro in Australia?', answer: 'Retail cartons of Marlboro can cost over A$400 in Australia. Aussie Smoke Store offers Marlboro Red and Marlboro Gold cartons at a fraction of retail prices — check our Marlboro page for current deals.' },
  { question: 'What are the best rolling tobacco brands in Australia?', answer: 'Popular rolling tobacco brands include Champion Ruby, JPS, Drum, and Port Royal. Aussie Smoke Store stocks premium rolling tobacco at the cheapest online prices with Australia-wide delivery.' },
  { question: 'Is it legal to buy cigarettes online in Australia?', answer: 'Tobacco regulations vary by state. Aussie Smoke Store operates in compliance with applicable laws. All customers must be 18+ to purchase. We ship discreetly in plain packaging Australia-wide.' },
];

const BRAND_COMPARISONS = [
  { brand: 'Marlboro Red', pack: 'Carton (10 packs)', retail: '$450+', ours: 'See shop' },
  { brand: 'Marlboro Gold', pack: 'Carton (10 packs)', retail: '$450+', ours: 'See shop' },
  { brand: 'Manchester', pack: 'Carton (10 packs)', retail: '$380+', ours: 'See shop' },
  { brand: 'Bond Street', pack: 'Carton (10 packs)', retail: '$370+', ours: 'See shop' },
  { brand: 'Peter Jackson', pack: 'Carton (10 packs)', retail: '$500+', ours: 'See shop' },
];

const CigarettePriceGuide = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cigarette Prices Australia 2026"
        description="Complete guide to cigarette prices in Australia 2026. Compare Marlboro, Manchester, Bond Street & more. Find the cheapest cigarettes online. Save hundreds per carton."
        canonical="/cigarette-prices-australia"
        keywords="cigarette prices Australia, cigarette prices Australia 2026, how much are cigarettes in Australia, cheapest cigarettes Australia, Marlboro price Australia, cigarette carton price Australia, tobacco prices Australia, cheapest cigarette brands Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cigarette Prices Australia 2026', url: '/cigarette-prices-australia' }]),
          articleJsonLd({ headline: 'Cigarette Prices Australia 2026', url: '/cigarette-prices-australia' }),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cigarette Prices Australia 2026
              <span className="text-primary block mt-2">Complete Price Guide &amp; Cheapest Brands</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Compare <strong>cigarette prices in Australia</strong> for 2026. Find out which brands offer the best value and how to save hundreds buying online from Aussie Smoke Store.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Cheapest Cigarettes <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>How Much Do Cigarettes Cost in Australia in 2026?</h2>
              <p>
                Australia has some of the highest cigarette prices in the world due to government excise taxes. A single pack of 20 cigarettes at a retail tobacconist now costs between <strong>A$35 and A$60+</strong> depending on the brand. A carton of 10 packs can easily exceed <strong>A$400-$550</strong> at retail.
              </p>
              <p>
                That's why thousands of Australian smokers are turning to online stores like <strong>Aussie Smoke Store</strong> to save significantly. We offer the same premium brands — Marlboro, Manchester, Bond Street, and more — at a fraction of retail prices.
              </p>

              <h2>Cigarette Price Comparison Table — Retail vs Aussie Smoke Store</h2>
            </div>

            <div className="overflow-x-auto mb-12">
              <table className="w-full border-collapse border rounded-lg">
                <thead>
                  <tr className="bg-secondary">
                    <th className="p-3 text-left font-semibold border-b">Brand</th>
                    <th className="p-3 text-left font-semibold border-b">Size</th>
                    <th className="p-3 text-left font-semibold border-b">Retail Price</th>
                    <th className="p-3 text-left font-semibold border-b">Our Price</th>
                  </tr>
                </thead>
                <tbody>
                  {BRAND_COMPARISONS.map((item, i) => (
                    <tr key={i} className="hover:bg-secondary/30">
                      <td className="p-3 border-b font-medium">{item.brand}</td>
                      <td className="p-3 border-b">{item.pack}</td>
                      <td className="p-3 border-b text-muted-foreground line-through">{item.retail}</td>
                      <td className="p-3 border-b">
                        <Link to="/products" className="text-primary font-semibold hover:underline">{item.ours}</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>Cheapest Cigarette Brands in Australia</h2>
              <p>If you're looking for the <strong>cheapest cigarettes in Australia</strong>, these brands offer the best value:</p>
              <ol>
                <li><strong>Manchester</strong> — One of the most affordable brands with a smooth flavour profile. Available in multiple variants.</li>
                <li><strong>Bond Street</strong> — Budget-friendly with consistent quality. Popular among cost-conscious smokers.</li>
                <li><strong>Horizon</strong> — Entry-level pricing without compromising too much on taste.</li>
                <li><strong>Holiday</strong> — Another budget option that's widely available across Australia.</li>
                <li><strong>Marlboro</strong> — While premium-priced at retail, Aussie Smoke Store offers Marlboro at significantly reduced prices.</li>
              </ol>

              <h2>How to Save Money on Cigarettes in Australia</h2>
              <ul>
                <li><strong>Buy online</strong> — Online stores like Aussie Smoke Store offer prices far below retail tobacconists</li>
                <li><strong>Buy cartons</strong> — Buying in bulk (cartons of 10 packs) saves significantly per pack</li>
                <li><strong>Use coupon codes</strong> — Check for promotional discounts and coupon codes at checkout</li>
                <li><strong>Free shipping threshold</strong> — Orders over A$50 qualify for free shipping</li>
                <li><strong>Consider rolling tobacco</strong> — Rolling your own cigarettes can save up to 50% vs pre-made packs</li>
              </ul>

              <h2>Rolling Tobacco Prices in Australia</h2>
              <p>
                Rolling tobacco is increasingly popular among Australian smokers looking to save money. A 30g pouch of rolling tobacco costs A$50-$80 at retail, but Aussie Smoke Store offers premium rolling tobacco brands at much lower prices. Popular brands include Champion Ruby, JPS Blue, Drum, and Port Royal.
              </p>

              <h2>Vape Prices in Australia</h2>
              <p>
                Vapes and e-cigarettes are another alternative. Aussie Smoke Store stocks a range of vapes from brands like U Well, IGET, and Kuz at competitive prices. Browse our <Link to="/cheap-vapes-online">cheap vapes online</Link> selection.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
              <Link to="/marlboro-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Marlboro Australia</Link>
              <Link to="/cheap-rolling-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Rolling Tobacco</Link>
              <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheapest Cigarettes &amp; Tobacco Online</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Cigarette Prices in Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CigarettePriceGuide;
