import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What are the best vapes in Australia in 2026?', answer: 'Popular vape brands in Australia include IGET, U Well, Kuz, and Alibabar. Aussie Smoke Store stocks a wide range of disposable and refillable vapes at the cheapest online prices.' },
  { question: 'How much do vapes cost in Australia?', answer: 'Vape prices vary from A$15 for basic disposables to A$80+ for premium refillable devices at retail. Aussie Smoke Store offers vapes at significantly lower prices — browse our selection for current deals.' },
  { question: 'What is the best disposable vape in Australia?', answer: 'IGET Bar and IGET Legend are among the most popular disposable vapes in Australia due to their flavour range and puff count. We stock these and many other disposable vapes at discount prices.' },
  { question: 'Are vapes cheaper than cigarettes in Australia?', answer: 'Generally yes. Vaping can be significantly cheaper than smoking traditional cigarettes, especially when you buy online from Aussie Smoke Store at our discounted prices.' },
  { question: 'Do you deliver vapes Australia-wide?', answer: 'Yes! Aussie Smoke Store delivers vapes to all Australian addresses — Sydney, Melbourne, Brisbane, Perth, Adelaide, and everywhere in between. Free shipping on orders over A$50.' },
];

const VapeGuide = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Best Vapes Australia 2026 — Cheap Vapes Online Guide"
        description="Complete guide to vapes in Australia 2026. Compare IGET, U Well, Kuz & more. Buy cheap vapes online with Australia-wide delivery. Free shipping over A$50."
        canonical="/vape-guide-australia"
        keywords="best vapes Australia, cheap vapes Australia, vape Australia 2026, IGET vape Australia, disposable vapes Australia, buy vapes online Australia, vape prices Australia, U Well Australia, Kuz vape, cheap vapes online"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Vape Guide Australia 2026', url: '/vape-guide-australia' }]),
          articleJsonLd({ headline: 'Best Vapes Australia 2026 — Cheap Vapes Online Guide', url: '/vape-guide-australia' }),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Best Vapes Australia 2026
              <span className="text-primary block mt-2">Cheap Vapes Online — Complete Guide</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Everything you need to know about <strong>vapes in Australia</strong>. Compare top brands, prices, and buy the cheapest vapes online from Aussie Smoke Store.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Vapes <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Top Vape Brands in Australia 2026</h2>
            <p>The Australian vape market has grown rapidly. Here are the most popular <strong>vape brands</strong> available at Aussie Smoke Store:</p>
            <ol>
              <li><strong>IGET</strong> — Australia's most popular disposable vape brand. IGET Bar, IGET Legend, and IGET King offer massive puff counts and diverse flavours.</li>
              <li><strong>U Well</strong> — Premium refillable vape devices known for excellent build quality and flavour production.</li>
              <li><strong>Kuz</strong> — Popular budget-friendly disposable vapes with a wide flavour range.</li>
              <li><strong>Alibabar</strong> — Affordable disposable vapes gaining popularity across Australia.</li>
            </ol>

            <h2>Disposable vs Refillable Vapes — Which is Better?</h2>
            <h3>Disposable Vapes</h3>
            <ul>
              <li><strong>Pros:</strong> No maintenance, pre-filled, ready to use, portable</li>
              <li><strong>Cons:</strong> Higher long-term cost, more waste, limited customisation</li>
              <li><strong>Best for:</strong> Beginners, casual vapers, convenience seekers</li>
            </ul>
            <h3>Refillable Vapes</h3>
            <ul>
              <li><strong>Pros:</strong> Cheaper long-term, more flavour options, customisable</li>
              <li><strong>Cons:</strong> Requires maintenance, initial setup cost, learning curve</li>
              <li><strong>Best for:</strong> Regular vapers, flavour enthusiasts, cost-conscious users</li>
            </ul>

            <h2>Most Popular Vape Flavours in Australia</h2>
            <ol>
              <li><strong>Mango</strong> — Sweet tropical flavour, consistently the #1 seller</li>
              <li><strong>Grape</strong> — Rich and fruity, popular across all brands</li>
              <li><strong>Watermelon Ice</strong> — Refreshing with a menthol kick</li>
              <li><strong>Blueberry</strong> — Sweet berry flavour loved by Aussie vapers</li>
              <li><strong>Tobacco</strong> — Classic flavour for smokers transitioning to vaping</li>
            </ol>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Buy Cheap Vapes</Link>
            <Link to="/cigarette-prices-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cigarette Prices</Link>
            <Link to="/nicotine-pouches-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Nicotine Pouches</Link>
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheapest Vapes Online</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Vapes in Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default VapeGuide;
