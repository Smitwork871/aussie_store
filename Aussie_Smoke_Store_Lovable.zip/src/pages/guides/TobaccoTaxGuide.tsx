import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'How much is tobacco excise tax in Australia in 2026?', answer: 'Australian tobacco excise sits at roughly A$1.40+ per stick in 2026 after years of annual indexation and the staged 5% September increases that ran from 2023 through 2025. That means tax alone accounts for more than A$28 on a standard 20-pack before retailer margin and GST.' },
  { question: 'When does the next tobacco tax increase happen?', answer: 'Tobacco excise is indexed twice a year (March and September) to average weekly earnings. The next CPI/AWOTE indexation lift is scheduled for 1 September 2026, on top of the bi-annual March 2026 adjustment that already applied.' },
  { question: 'Why are cigarettes so expensive in Australia?', answer: 'Australia has the highest tobacco taxes in the world. Excise duty, GST, and retailer margin together typically make up 75–80% of the shelf price. That is why a single pack at a servo can cost A$45–A$60+.' },
  { question: 'How can I save money on smokes with the new tax?', answer: 'The biggest savings come from buying cartons online, switching to budget brands like Manchester or Bond Street, or moving to rolling tobacco where the per-stick cost is roughly half. Aussie Smoke Store lists all three options at well below retail.' },
  { question: 'Is rolling tobacco taxed the same as cigarettes?', answer: 'Yes — since 2017 loose tobacco is taxed on a per-stick equivalent basis (0.7g = 1 stick), so a 30g pouch carries excise on roughly 42 sticks. It is still cheaper than pre-made packs because there is no manufacturing or filter cost loaded on top.' },
  { question: 'Will tobacco prices keep rising in 2026 and 2027?', answer: 'Yes. Even without further 5% policy hikes, automatic indexation guarantees increases every March and September. Treasury forecasts put the average pack above A$50 by late 2026 and approaching A$55 in 2027.' },
];

const TAX_HISTORY = [
  { year: '2020', excisePerStick: '$1.03', avgPack20: '$35', notes: '12.5% annual hikes ended' },
  { year: '2022', excisePerStick: '$1.12', avgPack20: '$40', notes: 'CPI indexation only' },
  { year: '2023', excisePerStick: '$1.20', avgPack20: '$42', notes: '5% Sep increase begins' },
  { year: '2024', excisePerStick: '$1.27', avgPack20: '$45', notes: '2nd 5% increase' },
  { year: '2025', excisePerStick: '$1.34', avgPack20: '$48', notes: '3rd & final 5% increase' },
  { year: '2026', excisePerStick: '$1.40+', avgPack20: '$50+', notes: 'AWOTE indexation only' },
];

const PRICE_BREAKDOWN = [
  { brand: 'Marlboro Gold (20s)', retail: '$58', excise: '$28', gst: '$5.30', netOfTax: '$24.70', ourPrice: 'See shop' },
  { brand: 'Winfield Blue (20s)', retail: '$52', excise: '$28', gst: '$4.70', netOfTax: '$19.30', ourPrice: 'See shop' },
  { brand: 'Peter Jackson (20s)', retail: '$50', excise: '$28', gst: '$4.55', netOfTax: '$17.45', ourPrice: 'See shop' },
  { brand: 'Manchester (20s)', retail: '$42', excise: '$28', gst: '$3.80', netOfTax: '$10.20', ourPrice: 'See shop' },
  { brand: 'Bond Street (20s)', retail: '$40', excise: '$28', gst: '$3.65', netOfTax: '$8.35', ourPrice: 'See shop' },
  { brand: 'Champion Ruby 30g RYO', retail: '$78', excise: '$58.80', gst: '$7.10', netOfTax: '$12.10', ourPrice: 'See shop' },
];

const TobaccoTaxGuide = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Australian Tobacco Tax Guide 2026"
        description="2026 guide to Australia's tobacco excise tax. See how much tax is on a packet of cigarettes, the September 2026 indexation, and how to beat rising prices with cheap smokes online."
        canonical="/australian-tobacco-tax-guide"
        keywords="australian tobacco tax, tobacco excise australia, tobacco tax increase 2026, cigarette price increase australia, how much tax on cigarettes australia, tobacco excise 2026, cheap smokes online, cigarette prices australia 2026, tobacco indexation australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: 'Australian Tobacco Tax Guide 2026', url: '/australian-tobacco-tax-guide' },
          ]),
          articleJsonLd({ headline: 'Australian Tobacco Tax Guide 2026', url: '/australian-tobacco-tax-guide' }),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Australian Tobacco Tax Guide 2026
              <span className="text-primary block mt-2">Excise, Price Increases &amp; How to Save</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Everything you need to know about <strong>Australia's tobacco excise tax</strong>, the 2026 indexation increases, and the cheapest legal ways to keep smoking without paying servo prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Cheap Smokes Online <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>How Tobacco Tax Works in Australia</h2>
              <p>
                Tobacco in Australia is taxed two ways: a federal <strong>excise duty</strong> charged per stick (or per gram for rolling tobacco) and 10% <strong>GST</strong> applied to the final retail price. The excise rate is set by the Australian Taxation Office (ATO) and indexed <strong>twice a year</strong> — every March and September — to movements in Average Weekly Ordinary Time Earnings (AWOTE).
              </p>
              <p>
                On top of indexation, the Federal Budget introduced three consecutive <strong>5% policy increases</strong> that ran in September 2023, 2024 and 2025. Those finished in 2025 — but indexation continues automatically, which is why prices keep climbing through 2026.
              </p>

              <h2>2026 Tobacco Excise Rate &amp; Scheduled Increases</h2>
              <p>
                As of March 2026 the excise is approximately <strong>A$1.40 per stick</strong> — meaning a standard 20-pack carries around <strong>A$28 in excise duty alone</strong> before GST and retailer margin. The next scheduled lift is the <strong>1 September 2026</strong> AWOTE indexation, which Treasury models put at roughly 2–3%, pushing excise to about A$1.43–A$1.44 per stick.
              </p>

              <h2>Tobacco Excise History — 2020 to 2026</h2>
            </div>

            <div className="overflow-x-auto mb-12">
              <table className="w-full border-collapse border rounded-lg">
                <thead>
                  <tr className="bg-secondary">
                    <th className="p-3 text-left font-semibold border-b">Year</th>
                    <th className="p-3 text-left font-semibold border-b">Excise / Stick</th>
                    <th className="p-3 text-left font-semibold border-b">Avg Pack (20s) Retail</th>
                    <th className="p-3 text-left font-semibold border-b">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {TAX_HISTORY.map((row, i) => (
                    <tr key={i} className="hover:bg-secondary/30">
                      <td className="p-3 border-b font-medium">{row.year}</td>
                      <td className="p-3 border-b">{row.excisePerStick}</td>
                      <td className="p-3 border-b">{row.avgPack20}</td>
                      <td className="p-3 border-b text-muted-foreground">{row.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>What's Actually in the Price of a Pack? Premium vs Budget Brands After Tax</h2>
              <p>
                The table below breaks down a typical 20-pack at retail tobacconist prices. Notice how the <strong>excise component is identical</strong> across every brand — the only real difference between a premium and a budget pack is the manufacturer/retailer margin sitting on top of the tax.
              </p>
            </div>

            <div className="overflow-x-auto mb-12">
              <table className="w-full border-collapse border rounded-lg">
                <thead>
                  <tr className="bg-secondary">
                    <th className="p-3 text-left font-semibold border-b">Brand</th>
                    <th className="p-3 text-left font-semibold border-b">Retail Price</th>
                    <th className="p-3 text-left font-semibold border-b">Excise</th>
                    <th className="p-3 text-left font-semibold border-b">GST</th>
                    <th className="p-3 text-left font-semibold border-b">Margin (net of tax)</th>
                    <th className="p-3 text-left font-semibold border-b">Our Price</th>
                  </tr>
                </thead>
                <tbody>
                  {PRICE_BREAKDOWN.map((row, i) => (
                    <tr key={i} className="hover:bg-secondary/30">
                      <td className="p-3 border-b font-medium">{row.brand}</td>
                      <td className="p-3 border-b text-muted-foreground line-through">{row.retail}</td>
                      <td className="p-3 border-b">{row.excise}</td>
                      <td className="p-3 border-b">{row.gst}</td>
                      <td className="p-3 border-b">{row.netOfTax}</td>
                      <td className="p-3 border-b">
                        <Link to="/products" className="text-primary font-semibold hover:underline">{row.ourPrice}</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>How to Beat the 2026 Tobacco Tax Increases</h2>
              <ul>
                <li><strong>Buy cartons online</strong> — A carton (10 packs) from Aussie Smoke Store can save A$100–A$200 versus a tobacconist on the same brand.</li>
                <li><strong>Switch to a budget brand</strong> — <Link to="/manchester-cigarettes-australia">Manchester</Link> and Bond Street carry the same excise as Marlboro, so the price gap is pure margin you can take back.</li>
                <li><strong>Roll your own</strong> — A 30g pouch of <Link to="/cheap-rolling-tobacco-online">rolling tobacco</Link> produces ~40 sticks at roughly half the per-stick cost of pre-mades.</li>
                <li><strong>Consider pouches or vapes</strong> — <Link to="/nicotine-pouches-australia">Nicotine pouches</Link> and <Link to="/cheap-vapes-online">vapes</Link> sit outside tobacco excise and can dramatically cut weekly spend.</li>
                <li><strong>Stack the free-shipping threshold</strong> — Orders over A$50 ship free Australia-wide, so combining a carton plus a pouch usually clears it.</li>
              </ul>

              <h2>What Happens to Prices in 2027?</h2>
              <p>
                With the policy hikes finished, increases revert to twice-yearly AWOTE indexation. Based on current wages growth that's roughly a <strong>4–6% lift per year</strong>. Treasury's forward estimates have the average 20-pack at <strong>A$53–A$55 by late 2027</strong>, with premium brands like Marlboro pushing past A$65.
              </p>

              <h2>Is Buying Cheap Smokes Online Legal in Australia?</h2>
              <p>
                Yes — purchasing duty-paid tobacco from an Australian-based online retailer is legal for anyone 18 or over. Aussie Smoke Store ships only duty-paid stock and requires age verification at entry and checkout. What's <em>not</em> legal is importing tobacco from overseas without paying excise — those "chop-chop" deals carry heavy ATO penalties.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              <Link to="/cigarette-prices-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cigarette Price Guide</Link>
              <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
              <Link to="/cheap-rolling-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Rolling Tobacco</Link>
              <Link to="/nicotine-pouches-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Nicotine Pouches</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheapest Cigarettes &amp; Tobacco Online</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Australian Tobacco Tax 2026</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default TobaccoTaxGuide;
