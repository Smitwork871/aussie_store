import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'How much does 1kg of tobacco cost in Australia in 2026?', answer: '1kg of loose-leaf rolling tobacco in Australia typically retails between A$2,400 and A$2,800 at tobacconists once excise and GST are loaded on. Buying online from Aussie Smoke Store by stacking 30g–50g pouches into bulk orders can bring the effective per-kilo cost down to roughly A$2,000–A$2,300, depending on brand.' },
  { question: 'Why is 1kg of tobacco so expensive?', answer: 'Loose tobacco is taxed on a per-stick-equivalent basis at 0.7g per stick. That means 1kg carries excise on roughly 1,428 sticks — about A$2,000 in federal excise alone in 2026, before GST or retailer margin.' },
  { question: 'Can you legally buy 1kg of tobacco in Australia?', answer: 'Yes. Duty-paid loose-leaf and pouch tobacco is legal to buy in any quantity from an Australian retailer if you are 18+. What is illegal is buying untaxed "chop-chop" or importing tobacco from overseas without paying excise.' },
  { question: 'What is the cheapest 1kg-equivalent tobacco brand in Australia?', answer: 'Budget brands like JPS, Riverstone and Drum Original tend to sit at the bottom of the per-kilo ladder, while premium names like Champion Ruby and Old Holborn sit at the top. The cheapest legal per-kilo price you will find from a duty-paid Australian seller in 2026 is around A$2,000.' },
  { question: 'Is it cheaper to buy 1kg of tobacco than packs of cigarettes?', answer: 'Yes — significantly. 1kg of rolling tobacco produces roughly 1,400 sticks. The same number of pre-made cigarettes would cost A$3,500+ at retail. Bulk rolling tobacco roughly halves the per-stick cost.' },
  { question: 'Does Aussie Smoke Store ship 1kg bulk tobacco orders?', answer: 'Yes — we ship rolling tobacco Australia-wide in 30g, 50g and multi-pouch bulk quantities. Orders over A$50 ship free, which most 1kg-equivalent orders comfortably clear.' },
];

const PRICE_TABLE = [
  { brand: 'JPS (Budget)', perKilo: '$2,050', per50g: '$103', sticksPerKg: '~1,428', notes: 'Cheapest legal duty-paid per-kg in 2026' },
  { brand: 'Riverstone', perKilo: '$2,120', per50g: '$106', sticksPerKg: '~1,428', notes: 'Mild blend, popular value pick' },
  { brand: 'Drum Original', perKilo: '$2,280', per50g: '$114', sticksPerKg: '~1,428', notes: 'Dutch halfzware, mid-tier' },
  { brand: 'White Ox', perKilo: '$2,450', per50g: '$122', sticksPerKg: '~1,428', notes: 'Strong full-flavour' },
  { brand: 'Champion Ruby', perKilo: '$2,620', per50g: '$131', sticksPerKg: '~1,428', notes: 'Premium dark blend' },
  { brand: 'Old Holborn Yellow', perKilo: '$2,780', per50g: '$139', sticksPerKg: '~1,428', notes: 'Premium aromatic, top tier' },
];

const BulkTobaccoPriceGuide = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="1kg Tobacco Price Australia 2026 — Bulk Guide"
        description="2026 guide to 1kg tobacco prices in Australia. Compare bulk rolling tobacco brands per kilo, see excise breakdowns, and find the cheapest legal duty-paid bulk buys online."
        canonical="/1kg-tobacco-price-guide-australia"
        keywords="1kg tobacco price australia, bulk tobacco australia, cheapest 1kg tobacco, 1 kilo tobacco price, bulk rolling tobacco australia, cheap bulk tobacco online, per kilo tobacco price australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: '1kg Tobacco Price Guide Australia', url: '/1kg-tobacco-price-guide-australia' },
          ]),
          articleJsonLd({ headline: '1kg Tobacco Price Australia 2026 — Bulk Guide', url: '/1kg-tobacco-price-guide-australia' }),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              1kg Tobacco Price Guide
              <span className="text-primary block mt-2">Australia 2026 — Bulk Buys Compared</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              The complete <strong>1kg tobacco price</strong> comparison for Australia in 2026 — every major brand ranked by per-kilo cost, with excise breakdowns and the cheapest legal bulk options online.
            </p>
            <Button size="lg" asChild>
              <Link to="/cheap-rolling-tobacco-online">Shop Bulk Rolling Tobacco <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>Why Buy 1kg of Tobacco Instead of Packs?</h2>
              <p>
                Buying bulk rolling tobacco is the single biggest legal saving available to Australian smokers in 2026. A 1kg-equivalent order produces around <strong>1,400 sticks</strong> at roughly <strong>A$1.50–A$2.00 per stick</strong> all-in — about half the per-stick cost of a Marlboro 20-pack from a servo.
              </p>
              <p>
                Bulk also unlocks free shipping (orders over <strong>A$50</strong> at Aussie Smoke Store ship free Australia-wide) and avoids the price creep that happens every March and September when excise is indexed.
              </p>

              <h2>1kg Tobacco Price Comparison — 2026 Brands</h2>
              <p>
                Prices below are realistic 2026 Australian duty-paid rates for buying the equivalent of 1kg through stacked 30g/50g pouches. All figures include excise and GST.
              </p>
            </div>

            <div className="overflow-x-auto mb-12">
              <table className="w-full border-collapse border rounded-lg">
                <thead>
                  <tr className="bg-secondary">
                    <th className="p-3 text-left font-semibold border-b">Brand</th>
                    <th className="p-3 text-left font-semibold border-b">Per Kilo</th>
                    <th className="p-3 text-left font-semibold border-b">Per 50g Pouch</th>
                    <th className="p-3 text-left font-semibold border-b">Sticks / Kg</th>
                    <th className="p-3 text-left font-semibold border-b">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {PRICE_TABLE.map((row, i) => (
                    <tr key={i} className="hover:bg-secondary/30">
                      <td className="p-3 border-b font-medium">{row.brand}</td>
                      <td className="p-3 border-b font-semibold text-primary">{row.perKilo}</td>
                      <td className="p-3 border-b">{row.per50g}</td>
                      <td className="p-3 border-b">{row.sticksPerKg}</td>
                      <td className="p-3 border-b text-muted-foreground">{row.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>How Excise Builds the 1kg Price</h2>
              <p>
                Loose tobacco is taxed on a stick-equivalent basis (0.7g = 1 stick). In 2026 the excise rate is roughly <strong>A$1.40 per stick</strong>, so 1kg carries about <strong>A$2,000 in federal excise alone</strong>. Add 10% GST and a small retailer margin and you land in the A$2,050–A$2,800 band shown above.
              </p>
              <p>
                That is also why brand premiums look small in percentage terms — almost every dollar of the price is tax. Switching from a premium to a budget blend like JPS or Riverstone can still save A$500–A$700 per kilo.
              </p>

              <h2>How to Get the Cheapest 1kg Tobacco Price in Australia</h2>
              <ul>
                <li><strong>Buy online in bulk</strong> — stacking pouches at <Link to="/cheap-rolling-tobacco-online">Aussie Smoke Store</Link> is consistently A$50–A$500 below tobacconist per-kilo rates.</li>
                <li><strong>Pick a budget blend</strong> — JPS, Riverstone and Drum Original carry identical excise to premium brands but a much smaller margin.</li>
                <li><strong>Clear the free-shipping threshold</strong> — orders over A$50 ship free; almost any bulk order crosses it.</li>
                <li><strong>Lock in before September indexation</strong> — excise indexes every March and September; buying ahead of the September 2026 lift saves another 2–3%.</li>
                <li><strong>Compare to pre-mades</strong> — 1kg of tobacco produces ~1,400 sticks for roughly A$2,100. The same number of premium pre-made cigarettes would cost over A$4,000.</li>
              </ul>

              <h2>Is It Legal to Buy 1kg of Tobacco in Australia?</h2>
              <p>
                Yes. There is no legal limit on how much duty-paid tobacco you can buy from an Australian retailer if you are 18 or older. Aussie Smoke Store only sells <strong>duty-paid stock</strong> and requires age verification at entry and checkout. Avoid any seller offering "chop-chop" or overseas imports — both carry serious ATO penalties.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              <Link to="/cheap-rolling-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Rolling Tobacco</Link>
              <Link to="/rolling-tobacco-guide-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Rolling Tobacco Guide</Link>
              <Link to="/australian-tobacco-tax-guide" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Tobacco Tax Guide</Link>
              <Link to="/cheapest-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheapest Cigarettes</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Shop Bulk Rolling Tobacco</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — 1kg Tobacco Prices in Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BulkTobaccoPriceGuide;
