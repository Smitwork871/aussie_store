import React from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Is it legal to buy cigarettes online in Australia?', answer: 'Yes. It is legal for adults aged 18 and over to buy cigarettes, rolling tobacco and other tobacco products online for personal use in Australia. Sellers must verify your age and ship only to verified adults — Aussie Smoke Store does both.' },
  { question: 'What is the legal smoking age in Australia?', answer: 'The legal age to buy and possess tobacco products is 18 in every Australian state and territory. Online stores are required to verify your age before completing a sale.' },
  { question: 'Are there quantity limits when buying tobacco online for personal use?', answer: 'For domestic Australian purchases there is no fixed per-order limit, but orders must be for personal use — not for resale. Importing tobacco from overseas is a different matter (see below) and is heavily restricted.' },
  { question: 'Can I import cigarettes from overseas into Australia?', answer: 'Since 1 July 2019 it has been illegal to import tobacco into Australia (including cigarettes, loose tobacco and snus) without a permit from the Australian Border Force. Buying from a domestic Australian retailer like Aussie Smoke Store avoids this entirely.' },
  { question: 'Is it legal to buy nicotine vapes online in Australia?', answer: 'Nicotine vaping products are tightly regulated. Since the 2024 reforms, nicotine vapes are sold through pharmacies and require a doctor consultation for higher strengths. Zero-nicotine and accessory products are not subject to the same restrictions.' },
  { question: 'Do online tobacco sales require ID verification?', answer: 'Yes. Australian retailers must take reasonable steps to confirm the buyer is 18 or over. Aussie Smoke Store uses an age-gate on entry and validates customer details at checkout.' },
  { question: 'Are plain packaging laws followed for online sales?', answer: 'Yes. All tobacco sold in Australia, online or in-store, must be in plain, drab packaging with mandated health warnings. Aussie Smoke Store ships only fully compliant Australian-market stock.' },
];

const LEGAL_TABLE = [
  { topic: 'Minimum purchase age', rule: '18 years (all states & territories)', sourceNote: 'Public Health (Tobacco) Acts' },
  { topic: 'Online domestic sales', rule: 'Legal for personal use, age verification required', sourceNote: 'State tobacco laws' },
  { topic: 'Importing tobacco from overseas', rule: 'Prohibited without ABF permit since 1 July 2019', sourceNote: 'Customs (Prohibited Imports) Regulations' },
  { topic: 'Plain packaging', rule: 'Mandatory — no branding, drab brown packs only', sourceNote: 'Tobacco Plain Packaging Act 2011' },
  { topic: 'Nicotine vapes', rule: 'Pharmacy-only model since 2024 reforms', sourceNote: 'Therapeutic Goods Administration' },
  { topic: 'Advertising tobacco', rule: 'Prohibited (price lists & age-gated sites permitted)', sourceNote: 'Tobacco Advertising Prohibition Act 1992' },
];

const TobaccoLawsAustralia = () => {
  return (
    <Layout>
      <SEOHead
        title="Is It Legal to Buy Cigarettes Online in Australia?"
        description="Plain-English guide to Australian tobacco laws: legal age, online purchase rules, ID checks, import restrictions, plain packaging & vape laws in 2026."
        canonical="/tobacco-laws-australia"
        keywords="is it legal to buy cigarettes online in australia, tobacco laws australia, buy cigarettes online legal, online tobacco rules, cigarette age limit australia, importing tobacco australia, plain packaging laws"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: 'Guides', url: '/' },
            { name: 'Tobacco Laws Australia', url: '/tobacco-laws-australia' },
          ]),
          articleJsonLd({ headline: 'Is It Legal to Buy Cigarettes Online in Australia?', url: '/tobacco-laws-australia' }),
          faqJsonLd(FAQS),
        ]}
      />

      {/* Hero */}
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Is It Legal to Buy Cigarettes Online in Australia?
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Short answer: <strong>yes</strong> — adults 18+ can legally buy cigarettes, rolling tobacco and tobacco accessories online from an Australian retailer for personal use. This 2026 guide breaks down the rules: age verification, quantity limits, the difference between domestic and overseas orders, and where vapes sit under current law.
            </p>
            <div className="flex justify-center gap-3">
              <Button asChild size="lg">
                <Link to="/products">Browse the Catalogue <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/australian-tobacco-tax-guide">Tobacco Tax Guide</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Legality summary */}
      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-4">Tobacco law at a glance</h2>
          <p className="text-muted-foreground mb-6">
            Australian tobacco regulation is split between Commonwealth law (excise, advertising, plain packaging, imports) and state law (minimum age, retail licensing). The table below summarises the rules most online shoppers ask about.
          </p>
          <div className="overflow-x-auto rounded-lg border">
            <table className="w-full text-sm">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-3 font-semibold">Topic</th>
                  <th className="text-left p-3 font-semibold">Rule (2026)</th>
                  <th className="text-left p-3 font-semibold">Source</th>
                </tr>
              </thead>
              <tbody>
                {LEGAL_TABLE.map((row) => (
                  <tr key={row.topic} className="border-t">
                    <td className="p-3 font-medium">{row.topic}</td>
                    <td className="p-3">{row.rule}</td>
                    <td className="p-3 text-muted-foreground">{row.sourceNote}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Domestic vs international */}
      <section className="py-12 md:py-16 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-4">Domestic Australian orders vs overseas imports</h2>
          <p className="text-muted-foreground mb-4">
            This is the single biggest source of confusion. Buying tobacco from an <strong>Australian retailer</strong> shipped from inside Australia is legal for adults. Buying tobacco from a <strong>foreign website</strong> and importing it is a different story.
          </p>
          <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
            <li><strong>Domestic (Australia → Australia):</strong> Legal, age-verified, no import permit needed. Excise has already been paid on the goods. This is what Aussie Smoke Store does.</li>
            <li><strong>Importing from overseas:</strong> Since 1 July 2019, importing tobacco without an Australian Border Force permit is prohibited. Parcels are seized at the border and excise of A$1.40+ per stick is charged before release, often making the order more expensive than buying locally.</li>
            <li><strong>Duty-free allowance:</strong> Travellers entering Australia can bring 25 cigarettes (or 25g of tobacco) duty-free per adult — anything above is taxable at the full domestic excise rate.</li>
          </ul>
        </div>
      </section>

      {/* Age verification */}
      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-4">Age verification & ID checks</h2>
          <p className="text-muted-foreground mb-4">
            Every state and territory in Australia sets the minimum tobacco purchase age at 18. Online retailers must take "reasonable steps" to confirm the buyer is an adult. In practice, that means:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
            <li>An age-gate on entry to the site (the modal you saw when you first visited Aussie Smoke Store).</li>
            <li>Confirmation at checkout that you are 18+.</li>
            <li>Couriers are entitled to request photo ID on delivery for tobacco parcels.</li>
            <li>Knowingly buying on behalf of a minor is an offence in every state.</li>
          </ul>
        </div>
      </section>

      {/* Quantity & personal use */}
      <section className="py-12 md:py-16 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-4">Quantity limits for personal use</h2>
          <p className="text-muted-foreground mb-4">
            There is <strong>no per-order legal cap</strong> on domestic Australian tobacco sales — you can lawfully buy a single pack or a full carton. Two caveats apply:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
            <li><strong>Personal use only.</strong> Reselling tobacco without a retail tobacco licence is an offence under every state's <em>Tobacco Act</em>.</li>
            <li><strong>Order patterns matter.</strong> Large repeat orders shipped to commercial addresses can trigger compliance reviews. Aussie Smoke Store ships to private residential addresses by default.</li>
          </ul>
        </div>
      </section>

      {/* Vapes */}
      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-4">What about nicotine vapes?</h2>
          <p className="text-muted-foreground mb-4">
            Nicotine vapes are regulated separately from combustible tobacco. Under the 2024 reforms led by the Therapeutic Goods Administration (TGA), nicotine vapes are pharmacy-only products in Australia. Aussie Smoke Store does not sell nicotine e-liquid online — we list zero-nicotine devices and accessories that fall outside the TGA's prescription framework.
          </p>
          <p className="text-muted-foreground">
            For combustible tobacco — cigarettes, rolling tobacco, and pouches — online retail remains fully legal for adults.
          </p>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-12 md:py-16 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">Frequently asked questions</h2>
          <div className="space-y-6">
            {FAQS.map((faq) => (
              <div key={faq.question}>
                <h3 className="text-lg font-semibold mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-16">
        <div className="container max-w-3xl text-center">
          <h2 className="text-3xl font-bold mb-4">Shop with a fully compliant Australian retailer</h2>
          <p className="text-muted-foreground mb-6">
            Aussie Smoke Store is age-gated, ships from within Australia, and lists only Australian-market plain-packaged stock. Free shipping on orders over A$50.
          </p>
          <Button asChild size="lg">
            <Link to="/products">Browse Cigarettes & Tobacco <ArrowRight className="ml-2 h-4 w-4" /></Link>
          </Button>
        </div>
      </section>

      <p className="container max-w-4xl text-xs text-muted-foreground pb-12">
        Information current as of June 2026. This page is general guidance, not legal advice. Refer to your state's tobacco regulator and the Australian Border Force for the latest rules.
      </p>
    </Layout>
  );
};

export default TobaccoLawsAustralia;
