import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight, Star } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Are Manchester cigarettes good value in Australia?', answer: 'Yes — Manchester is one of the best-value cigarette brands available online in Australia. It delivers a consistent smoke and full-flavour tobacco at a fraction of the price of premium brands like Marlboro or Winfield, which is why it has become the go-to budget option for many Australian smokers.' },
  { question: 'What are the different Manchester cigarette variants?', answer: 'The most popular Manchester variants in Australia are Manchester Royal Red (full flavour), Manchester Sapphire Blue (smoother, lighter blend) and Manchester Double Drive (a stronger, richer blend). All are widely available at Aussie Smoke Store.' },
  { question: 'How do Manchester cigarettes compare to Marlboro?', answer: 'Manchester and Marlboro Red are both full-flavour blends, but Manchester is significantly cheaper per carton. Marlboro has a slightly richer, more aromatic profile; Manchester offers a very similar full-flavour experience at a much lower price, making it the better value pick for everyday smokers.' },
  { question: 'How do Manchester cigarettes compare to Winfield?', answer: 'Winfield is Australia\'s most popular mid-range brand with a classic Australian tobacco taste. Manchester delivers a comparable smoke — smooth, full-bodied and consistent — at a much lower price per carton, so smokers switching from Winfield are usually happy with the value.' },
  { question: 'Which Manchester variant should I choose?', answer: 'Pick Royal Red for a traditional full-flavour smoke, Sapphire Blue if you prefer a lighter and smoother draw, or Double Drive if you want a stronger, more intense blend. Many customers keep more than one variant on hand.' },
  { question: 'Where can I buy Manchester cigarettes online in Australia?', answer: 'Aussie Smoke Store stocks all popular Manchester variants — Royal Red, Sapphire Blue and Double Drive — with Australia-wide delivery, discreet plain packaging, and free shipping on orders over A$50.' },
];

const VARIANTS = [
  {
    name: 'Manchester Royal Red',
    tagline: 'Full-flavour classic',
    strength: 'Full flavour',
    profile: 'Rich, robust, traditional tobacco taste with a strong throat hit.',
    bestFor: 'Smokers switching from Marlboro Red or Winfield Red who want a full-bodied everyday smoke.',
    to: '/manchester-royal-red-cigarettes-australia',
    rating: 4.6,
  },
  {
    name: 'Manchester Sapphire Blue',
    tagline: 'Smooth & lighter blend',
    strength: 'Smooth / medium',
    profile: 'Cleaner draw, less harsh, milder tobacco character with a softer aftertaste.',
    bestFor: 'Smokers coming from Marlboro Gold or Winfield Blue who prefer a lighter smoke.',
    to: '/manchester-sapphire-blue-cigarettes-australia',
    rating: 4.5,
  },
  {
    name: 'Manchester Double Drive',
    tagline: 'Stronger, richer blend',
    strength: 'Extra strong',
    profile: 'Deeper, richer smoke with a heavier tobacco note — noticeably stronger than Royal Red.',
    bestFor: 'Experienced full-flavour smokers who want more intensity per stick.',
    to: '/manchester-double-drive-australia',
    rating: 4.6,
  },
];

const PRICE_COMPARE = [
  { brand: 'Manchester Royal Red', size: 'Carton (10 packs)', retail: '$380+', ours: 'See shop', highlight: true },
  { brand: 'Manchester Sapphire Blue', size: 'Carton (10 packs)', retail: '$380+', ours: 'See shop', highlight: true },
  { brand: 'Manchester Double Drive', size: 'Carton (10 packs)', retail: '$380+', ours: 'See shop', highlight: true },
  { brand: 'Marlboro Red', size: 'Carton (10 packs)', retail: '$450+', ours: 'See shop' },
  { brand: 'Marlboro Gold', size: 'Carton (10 packs)', retail: '$450+', ours: 'See shop' },
  { brand: 'Winfield Blue', size: 'Carton (10 packs)', retail: '$430+', ours: 'See shop' },
];

const ManchesterCigarettesReview = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .ilike('name', '%manchester%')
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase
          .from('public_products')
          .select('*')
          .eq('is_active', true)
          .order('is_featured', { ascending: false })
          .limit(12);
        if (fallback) setProducts(fallback as Product[]);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Manchester Cigarettes Review Australia 2026 — Royal Red, Sapphire Blue & Double Drive"
        description="Honest 2026 review of Manchester cigarettes in Australia. Compare Royal Red, Sapphire Blue and Double Drive vs Marlboro and Winfield. Prices, strength, taste — full guide."
        canonical="/guides/manchester-cigarettes-review"
        keywords="Manchester cigarettes review, Manchester cigarettes Australia, Manchester Royal Red review, Manchester Sapphire Blue review, Manchester Double Drive review, best budget cigarettes Australia, cheap cigarettes Australia, Manchester vs Marlboro, Manchester vs Winfield"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: 'Guides', url: '/cigarette-prices-australia' },
            { name: 'Manchester Cigarettes Review', url: '/guides/manchester-cigarettes-review' },
          ]),
          articleJsonLd({ headline: 'Manchester Cigarettes Review Australia 2026 — Royal Red, Sapphire Blue & Double Drive', url: '/guides/manchester-cigarettes-review' }),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Manchester Cigarettes Review Australia
              <span className="text-primary block mt-2">Royal Red · Sapphire Blue · Double Drive</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              An honest 2026 review of <strong>Manchester cigarettes</strong> — Australia's most popular <strong>budget cigarette brand</strong>. Full comparison of every variant, plus price checks against Marlboro and Winfield.
            </p>
            <Button size="lg" asChild>
              <Link to="/manchester-cigarettes-australia">Shop Manchester Cigarettes <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-neutral dark:prose-invert mb-10">
              <h2>Why Manchester Cigarettes Are a Top Budget Pick in Australia</h2>
              <p>
                With retail cigarette prices in Australia now above <strong>A$40 a pack</strong> for premium brands, more smokers than ever are switching to affordable full-flavour brands. <strong>Manchester cigarettes</strong> have become one of the most popular budget picks in the country — offering a genuine full-flavour smoke, consistent burn and multiple variants to suit different tastes, all at a much lower price than premium brands.
              </p>
              <p>
                This guide covers the three most popular Manchester variants in Australia — <strong>Royal Red</strong>, <strong>Sapphire Blue</strong> and <strong>Double Drive</strong> — and compares them head-to-head against premium brands like Marlboro and Winfield so you can decide which one is right for you.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-3 mb-14">
              {VARIANTS.map((v) => (
                <article key={v.name} className="rounded-lg border bg-card p-6 flex flex-col">
                  <div className="flex items-center gap-1 mb-3 text-primary">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < Math.round(v.rating) ? 'fill-current' : 'opacity-30'}`} />
                    ))}
                    <span className="ml-1 text-sm text-muted-foreground">{v.rating.toFixed(1)}/5</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-1">{v.name}</h3>
                  <p className="text-sm text-primary font-medium mb-3">{v.tagline}</p>
                  <dl className="text-sm space-y-2 mb-4">
                    <div>
                      <dt className="text-muted-foreground">Strength</dt>
                      <dd className="font-medium">{v.strength}</dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">Taste profile</dt>
                      <dd>{v.profile}</dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">Best for</dt>
                      <dd>{v.bestFor}</dd>
                    </div>
                  </dl>
                  <div className="mt-auto">
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={v.to}>View {v.name.replace('Manchester ', '')}</Link>
                    </Button>
                  </div>
                </article>
              ))}
            </div>

            <div className="prose prose-neutral dark:prose-invert mb-8">
              <h2>Manchester vs Marlboro vs Winfield — Price Comparison</h2>
              <p>
                Here's how a Manchester carton stacks up against premium Australian cigarette brands. Retail figures are typical tobacconist prices; Aussie Smoke Store online pricing is dramatically lower — check the shop for live prices.
              </p>
            </div>

            <div className="overflow-x-auto mb-12">
              <table className="w-full border-collapse border rounded-lg">
                <thead>
                  <tr className="bg-secondary">
                    <th className="p-3 text-left font-semibold border-b">Brand</th>
                    <th className="p-3 text-left font-semibold border-b">Size</th>
                    <th className="p-3 text-left font-semibold border-b">Retail Price</th>
                    <th className="p-3 text-left font-semibold border-b">Our Price</th>
                  </tr>
                </thead>
                <tbody>
                  {PRICE_COMPARE.map((item, i) => (
                    <tr key={i} className={`hover:bg-secondary/30 ${item.highlight ? 'bg-primary/5' : ''}`}>
                      <td className="p-3 border-b font-medium">{item.brand}</td>
                      <td className="p-3 border-b">{item.size}</td>
                      <td className="p-3 border-b text-muted-foreground line-through">{item.retail}</td>
                      <td className="p-3 border-b">
                        <Link to="/manchester-cigarettes-australia" className="text-primary font-semibold hover:underline">{item.ours}</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>Manchester Royal Red — Full-Flavour Review</h2>
              <p>
                <strong>Manchester Royal Red</strong> is the flagship of the range and the closest match to full-flavour classics like Marlboro Red or Winfield Red. Expect a rich, tobacco-forward taste, a firm throat hit and a satisfying draw. Burn is even, the ash holds well and the aftertaste stays clean — impressive at this price point.
              </p>
              <p>
                <strong>Verdict:</strong> The best all-round Manchester variant for full-flavour smokers who want everyday value.
              </p>

              <h2>Manchester Sapphire Blue — Smooth Blend Review</h2>
              <p>
                <strong>Manchester Sapphire Blue</strong> is the lighter, smoother option in the lineup. It has a cleaner draw with less throat hit and a milder aftertaste — a comfortable alternative to Marlboro Gold or Winfield Blue. The flavour is softer but still full enough not to feel watered down.
              </p>
              <p>
                <strong>Verdict:</strong> The best pick for smokers who prefer a smoother, easier-going smoke without paying premium-brand prices.
              </p>

              <h2>Manchester Double Drive — Strong Blend Review</h2>
              <p>
                <strong>Manchester Double Drive</strong> takes the Royal Red profile up a notch. It's a stronger, richer blend with a heavier body and a more pronounced tobacco note. Not for beginners — it's aimed at experienced smokers who want more intensity per cigarette.
              </p>
              <p>
                <strong>Verdict:</strong> The strongest Manchester variant — pick it if Royal Red feels too mild.
              </p>

              <h2>Is Manchester the Best Budget Cigarette in Australia?</h2>
              <p>
                Across all three variants, Manchester consistently delivers a real full-flavour cigarette experience at a price well below premium brands. For most Australian smokers looking to cut spend without dropping to unregulated products, Manchester is one of the best value picks on the market — which is why it's a bestseller at Aussie Smoke Store.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              <Link to="/manchester-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">All Manchester</Link>
              <Link to="/marlboro-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Marlboro Australia</Link>
              <Link to="/cheapest-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheapest Cigarettes</Link>
              <Link to="/cigarette-prices-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cigarette Prices 2026</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Shop Manchester Cigarettes Online</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/manchester-cigarettes-australia">View All Manchester <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Manchester Cigarettes Review</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default ManchesterCigarettesReview;
