import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What is the best rolling tobacco in Australia?', answer: 'Champion Ruby and JPS Blue are among the most popular rolling tobaccos in Australia. At Aussie Smoke Store, we offer premium rolling tobacco at the cheapest online prices with Australia-wide delivery.' },
  { question: 'How much does rolling tobacco cost in Australia?', answer: 'Retail prices for 30g rolling tobacco pouches range from A$50-$80+ in Australia. Aussie Smoke Store offers significantly lower prices — shop our selection to see current deals.' },
  { question: 'Is rolling tobacco cheaper than cigarettes?', answer: 'Yes, rolling your own cigarettes can save up to 50% compared to buying pre-made packs. Combined with our online discount prices, the savings are even greater.' },
  { question: 'What papers and filters do I need for rolling tobacco?', answer: 'You\'ll need rolling papers (we recommend Rizla or RAW) and filters or tips. Aussie Smoke Store stocks all the accessories you need alongside our rolling tobacco range.' },
  { question: 'How long does a 30g pouch of rolling tobacco last?', answer: 'A 30g pouch typically makes 40-50 hand-rolled cigarettes, depending on how tightly you roll. Heavy smokers may go through a pouch in 3-4 days, while moderate smokers can make it last a week.' },
];

const RollingTobaccoGuide = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Best Rolling Tobacco Australia 2026"
        description="Complete guide to rolling tobacco in Australia 2026. Compare Champion Ruby, JPS, Drum & more. Buy cheap rolling tobacco online. Free shipping over A$50."
        canonical="/rolling-tobacco-guide-australia"
        keywords="rolling tobacco Australia, best rolling tobacco Australia, cheap rolling tobacco, rolling tobacco brands Australia, Champion Ruby, JPS rolling tobacco, buy rolling tobacco online Australia, RYO tobacco Australia, roll your own tobacco"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Rolling Tobacco Guide Australia', url: '/rolling-tobacco-guide-australia' }]),
          articleJsonLd({ headline: 'Best Rolling Tobacco Australia 2026', url: '/rolling-tobacco-guide-australia' }),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Rolling Tobacco Australia
              <span className="text-primary block mt-2">2026 Brands, Prices &amp; Buying Guide</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Everything you need to know about <strong>rolling tobacco in Australia</strong>. Compare brands, prices, and buy the cheapest rolling tobacco online from Aussie Smoke Store.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Rolling Tobacco <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Best Rolling Tobacco Brands in Australia</h2>
            <p>
              Roll-your-own (RYO) tobacco is one of the best ways to save money as a smoker in Australia. Here are the most popular <strong>rolling tobacco brands</strong> available at Aussie Smoke Store:
            </p>
            <ol>
              <li><strong>Champion Ruby</strong> — Australia's #1 selling RYO tobacco. Rich, full-bodied flavour that's perfect for hand-rolling.</li>
              <li><strong>JPS Blue</strong> — Smooth and mellow. A favourite for smokers who prefer a lighter roll.</li>
              <li><strong>Drum</strong> — Iconic European brand known for its premium blend and easy rolling texture.</li>
              <li><strong>Port Royal</strong> — Rich, aromatic tobacco that's popular among experienced rollers.</li>
              <li><strong>Winfield</strong> — Classic Australian tobacco brand offering consistent quality.</li>
            </ol>

            <h2>Why Choose Rolling Tobacco Over Pre-Made Cigarettes?</h2>
            <ul>
              <li><strong>Save up to 50%</strong> — Rolling your own is significantly cheaper per cigarette than buying packs</li>
              <li><strong>Control your smoke</strong> — Choose how much tobacco per cigarette and how tight to roll</li>
              <li><strong>Fresher tobacco</strong> — Pouches keep tobacco moist and fresh longer than pre-made packs</li>
              <li><strong>More variety</strong> — Mix and match different tobaccos and papers for your perfect smoke</li>
            </ul>

            <h2>Essential Rolling Accessories</h2>
            <p>To get started with rolling tobacco, you'll need:</p>
            <ul>
              <li><strong>Rolling papers</strong> — Rizla, RAW, or OCB are popular choices</li>
              <li><strong>Filter tips</strong> — Pre-made or cardboard tips for a smoother draw</li>
              <li><strong>Rolling machine</strong> — Optional but helps beginners achieve consistent rolls</li>
              <li><strong>Tobacco pouch</strong> — Keeps your tobacco fresh and portable</li>
            </ul>

            <h2>How to Roll the Perfect Cigarette</h2>
            <ol>
              <li>Take a pinch of tobacco and spread it evenly along the paper</li>
              <li>Place a filter tip at one end</li>
              <li>Roll the paper back and forth between your fingers to shape the tobacco</li>
              <li>Tuck the front edge of the paper around the tobacco and roll up</li>
              <li>Lick the gummed edge and seal</li>
            </ol>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-rolling-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Buy Rolling Tobacco</Link>
            <Link to="/cigarette-prices-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cigarette Prices</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Tobacco</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Rolling Tobacco &amp; Accessories</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Rolling Tobacco in Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default RollingTobaccoGuide;
