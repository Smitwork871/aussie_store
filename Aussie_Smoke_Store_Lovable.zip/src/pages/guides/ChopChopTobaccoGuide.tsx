import React from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { ArrowRight, AlertTriangle } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd, articleJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What is chop chop tobacco?', answer: 'Chop chop is a colloquial Australian term for unbranded, illicit loose-leaf tobacco that has been grown or processed outside of the licensed and taxed tobacco supply chain. It is illegal to buy, sell, or possess in Australia.' },
  { question: 'Is chop chop tobacco legal in Australia?', answer: 'No. Chop chop is illegal under the Excise Act 1901 and enforced by the Australian Border Force and the ATO’s Illicit Tobacco Taskforce. Penalties include large fines and imprisonment for supply and commercial possession.' },
  { question: 'Can I buy chop chop tobacco online?', answer: 'No. Aussie Smoke Store does NOT sell chop chop or any illicit tobacco. We only stock legal, duty-paid rolling tobacco, cigarettes and vaping products. If a site is offering "chop chop online", it is operating illegally and buyers risk seizure and prosecution.' },
  { question: 'What is the legal alternative to chop chop?', answer: 'Legal, duty-paid rolling tobacco (RYO) is the closest legal alternative. Brands like Champion Ruby, JPS Blue, Drum and Winfield RYO are available from licensed retailers such as Aussie Smoke Store with guaranteed quality control.' },
  { question: 'Why is chop chop dangerous?', answer: 'Because chop chop bypasses regulation, there is no quality control. It has been found to contain mould, pesticides, insects and other contaminants, and nicotine content is unpredictable. Legal tobacco is subject to Australian testing standards.' },
];

const ChopChopTobaccoGuide = () => {
  return (
    <Layout>
      <SEOHead
        title="Chop Chop Tobacco Australia — Legality, Risks & Legal Alternatives"
        description="Guide to chop chop tobacco in Australia. What it is, why it is illegal, the health and legal risks, and the cheapest legal rolling tobacco alternatives you can buy online."
        canonical="/chop-chop-tobacco-australia-guide"
        keywords="chop chop tobacco, chop chop tobacco Australia, is chop chop illegal, chop chop vs rolling tobacco, cheap legal rolling tobacco Australia, illicit tobacco Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: 'Guides', url: '/rolling-tobacco-guide-australia' },
            { name: 'Chop Chop Tobacco Australia Guide', url: '/chop-chop-tobacco-australia-guide' },
          ]),
          articleJsonLd({ headline: 'Chop Chop Tobacco Australia — Legality, Risks & Legal Alternatives', url: '/chop-chop-tobacco-australia-guide' }),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Chop Chop Tobacco in Australia
              <span className="text-primary block mt-2">What It Is, Why It's Illegal & Legal Alternatives</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              A plain-English guide to <strong>chop chop tobacco</strong> in Australia — and the cheapest <strong>legal rolling tobacco</strong> you can actually buy online.
            </p>
            <Button size="lg" asChild>
              <Link to="/products?category=rolling-tobacco">Shop Legal Rolling Tobacco <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-start gap-3 rounded-lg border border-destructive/40 bg-destructive/10 p-4 mb-10">
              <AlertTriangle className="h-5 w-5 mt-1 shrink-0 text-destructive" />
              <p className="text-sm md:text-base">
                <strong>Important:</strong> Aussie Smoke Store does <strong>not</strong> sell chop chop or any illicit tobacco. Chop chop is illegal in every Australian state and territory. This page is educational only and directs shoppers to legal, duty-paid alternatives.
              </p>
            </div>

            <div className="prose prose-neutral dark:prose-invert max-w-none mb-12">
              <h2>What is chop chop tobacco?</h2>
              <p>
                “Chop chop” is Australian slang for <strong>unbranded, illicit loose-leaf tobacco</strong> that has been grown, cured or imported outside the licensed tobacco supply chain. Because no excise (tobacco tax) has been paid on it, it is usually sold well below the price of legal rolling tobacco — which is exactly why it draws attention from smokers looking to save money.
              </p>

              <h2>Is chop chop legal in Australia?</h2>
              <p>
                No. Growing, manufacturing, selling, buying or possessing chop chop is illegal under the <em>Excise Act 1901</em> and related state laws. Enforcement is led by the <strong>Australian Border Force (ABF)</strong> and the <strong>ATO Illicit Tobacco Taskforce (ITTF)</strong>. Penalties can include:
              </p>
              <ul>
                <li>Seizure of the tobacco and any vehicles or premises used</li>
                <li>Financial penalties up to 10× the evaded duty</li>
                <li>Prison sentences of up to 10 years for commercial supply</li>
              </ul>

              <h2>Why chop chop is a bad idea (even if it's cheap)</h2>
              <ul>
                <li><strong>No quality control</strong> — testing by NSW Health and academic researchers has found mould, insect fragments, pesticides and other contaminants in seized chop chop.</li>
                <li><strong>Unknown nicotine strength</strong> — because it isn't standardised, dose varies pouch to pouch.</li>
                <li><strong>Funds organised crime</strong> — the illicit tobacco trade is linked to organised crime networks operating across Australia.</li>
                <li><strong>Legal risk to you</strong> — buyers, not just sellers, can be prosecuted and have goods seized.</li>
              </ul>

              <h2>Chop chop vs legal rolling tobacco</h2>
              <p>
                Legal <Link to="/cheap-rolling-tobacco-online">rolling tobacco</Link> (RYO) is the direct, legal alternative to chop chop. It is significantly cheaper per cigarette than a factory-made pack, but is properly cured, tested, and duty-paid. Popular Australian RYO brands include Champion Ruby, JPS Blue, Drum, Winfield RYO and Port Royal.
              </p>

              <h2>Where to buy cheap legal rolling tobacco online</h2>
              <p>
                <strong>Aussie Smoke Store</strong> stocks a wide range of legal, duty-paid rolling tobacco at prices well below supermarket RRP, with <strong>free shipping on orders over A$50</strong> Australia-wide. Every product we sell is compliant with Australian tobacco law.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              <Link to="/cheap-rolling-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Rolling Tobacco</Link>
              <Link to="/rolling-tobacco-guide-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Rolling Tobacco Guide</Link>
              <Link to="/cheap-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Tobacco Online</Link>
              <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Chop Chop Tobacco Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6 bg-background">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default ChopChopTobaccoGuide;
