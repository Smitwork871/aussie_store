import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy bulk cigarettes online in Australia?', answer: 'Yes! Aussie Smoke Store offers bulk cigarette purchasing. Buy cartons and multi-packs at the cheapest prices in Australia with free shipping on orders over A$50.' },
  { question: 'How much can I save buying cigarettes in bulk?', answer: 'Buying cigarettes by the carton saves you significantly compared to buying individual packs. Plus, orders over A$50 qualify for free shipping Australia-wide.' },
  { question: 'What cigarette cartons do you sell?', answer: 'We sell cartons from all major brands including Marlboro, Manchester, Benson & Hedges, Peter Jackson, Winfield and more. Each carton typically contains 10 packets of 20 cigarettes.' },
];

const BulkCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('price', { ascending: true })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Bulk Cigarettes Australia — Carton Prices"
        description="Buy bulk cigarettes and cartons online in Australia. Cheapest carton prices on Marlboro, Manchester & more. Free shipping over A$50. Aussie Smoke Store."
        canonical="/bulk-cigarettes-australia"
        keywords="bulk cigarettes Australia, buy bulk cigarettes online Australia, cigarette carton Australia, cheap cigarette cartons, carton cigarettes Australia, bulk smokes Australia, wholesale cigarettes Australia, bulk darts Australia"
        jsonLd={[
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Bulk Cigarettes Australia', url: '/bulk-cigarettes-australia' }]),
          faqJsonLd(FAQS),
          localBusinessJsonLd(),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16">
        <div className="container max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-center">
            Buy Bulk Cigarettes Online Australia
          </h1>
          <p className="text-lg text-muted-foreground text-center mb-8 max-w-2xl mx-auto">
            Save big by buying <strong>bulk cigarettes online</strong> in Australia. Get the cheapest carton prices on all major brands with <strong>free shipping on orders over A$50</strong>.
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" asChild>
              <Link to="/products">Shop Cartons <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8 text-center">Bulk Cigarettes — Best Prices</h2>
          <ProductGrid products={products} isLoading={isLoading} />
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">Why Buy Bulk Cigarettes Online?</h2>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
            <p>Buying <strong>bulk cigarettes in Australia</strong> is the smartest way to save money. At Aussie Smoke Store, our carton prices are the lowest you'll find online. We stock cartons from every popular brand.</p>
            <p>Our bulk cigarette range includes: <strong>Marlboro cartons</strong>, <strong>Manchester cartons</strong>, <strong>Benson &amp; Hedges cartons</strong>, <strong>Peter Jackson cartons</strong> and many more. All genuine, factory-sealed products.</p>
            <p>Combine with our <strong>free shipping over A$50</strong> and you've got the best deal on cigarettes anywhere in Australia. Browse our <Link to="/cheapest-cigarettes-australia" className="text-primary hover:underline">cheapest cigarettes</Link> or check our <Link to="/cigarette-prices-australia" className="text-primary hover:underline">price guide</Link> to compare.</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">FAQ — Bulk Cigarettes Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BulkCigarettesAustralia;
