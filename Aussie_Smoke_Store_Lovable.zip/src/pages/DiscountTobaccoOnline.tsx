import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I find discount tobacco online in Australia?', answer: 'Aussie Smoke Store is Australia\'s #1 discount tobacco store. We offer cigarettes, rolling tobacco, vapes, and accessories at wholesale-style discount prices with free shipping over A$50.' },
  { question: 'How much can I save buying discount tobacco online?', answer: 'You can save up to 60% compared to retail prices when buying discount tobacco online from Aussie Smoke Store. Bulk orders qualify for even bigger savings plus free shipping.' },
  { question: 'Is discount tobacco the same quality as retail?', answer: 'Absolutely! All our tobacco products are genuine, sealed, and from the same manufacturers you find in retail stores. The only difference is the price — we cut out the middleman.' },
  { question: 'Do you offer bulk discounts on tobacco?', answer: 'Yes! The more you buy, the more you save. Orders over A$50 qualify for free shipping, and carton purchases offer significant per-pack savings compared to singles.' },
];

const DiscountTobaccoOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .not('compare_at_price', 'is', null)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase
          .from('public_products')
          .select('*')
          .eq('is_active', true)
          .order('is_featured', { ascending: false })
          .limit(12);
        if (fallback) setProducts(fallback as Product[]);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Discount Tobacco Online Australia — Save Up to 60% on Smokes"
        description="Buy discount tobacco online in Australia. Save up to 60% on cigarettes, rolling tobacco, vapes & accessories. Free shipping over A$50. Shop Aussie Smoke Store."
        canonical="/discount-tobacco-online"
        keywords="discount tobacco online, discount cigarettes Australia, cheap tobacco deals, tobacco sale online Australia, discount smokes Australia, bulk tobacco discount, wholesale tobacco online Australia, save on cigarettes Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Discount Tobacco Online', url: '/discount-tobacco-online' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Discount Tobacco Online Australia
              <span className="text-primary block mt-2">Save Up to 60% on Every Order</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Shop <strong>discount tobacco online</strong> at Aussie Smoke Store. Huge savings on cigarettes, rolling tobacco, vapes & accessories. <strong>Free shipping over A$50.</strong>
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Shop Discount Tobacco <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-tobacco-online">Cheap Tobacco Online</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Australia's Best Discount Tobacco Deals</h2>
            <p>
              Why pay retail prices for tobacco? At Aussie Smoke Store, we offer <strong>discount tobacco online</strong> at prices you won't find anywhere else in Australia. Every product is genuine, sealed, and delivered discreetly.
            </p>
            <h3>How We Keep Prices Low</h3>
            <ul>
              <li><strong>Direct sourcing</strong> — We cut out middlemen to pass savings directly to you</li>
              <li><strong>Bulk pricing</strong> — Carton and multi-pack deals for maximum savings</li>
              <li><strong>Free shipping</strong> — Orders over A$50 ship free to anywhere in Australia</li>
              <li><strong>No hidden costs</strong> — What you see is what you pay</li>
            </ul>
            <h3>Discount Tobacco Product Range</h3>
            <ul>
              <li><strong>Discount Cigarettes</strong> — Marlboro, Manchester, Winfield, and more at wholesale prices</li>
              <li><strong>Discount Rolling Tobacco</strong> — Premium blends for the budget-conscious roller</li>
              <li><strong>Discount Vapes</strong> — U Well, Alibabar, Iget, Kuz at clearance prices</li>
              <li><strong>Accessories</strong> — Filters, papers, lighters at rock-bottom prices</li>
            </ul>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes Online</Link>
            <Link to="/best-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Best Cigarettes Australia</Link>
            <Link to="/online-tobacco-shop-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Online Tobacco Shop</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Discount Tobacco — Best Deals</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions — Discount Tobacco</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default DiscountTobaccoOnline;
