import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Victoria?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes, tobacco, and vapes across all of Victoria — from Melbourne to Geelong, Ballarat, Bendigo, and regional VIC.' },
  { question: 'How long does cigarette delivery take in VIC?', answer: 'Melbourne metro orders typically arrive within 3-5 business days. Regional VIC may take 5-7 days. Orders over A$50 qualify for free shipping.' },
  { question: 'What are the cheapest cigarettes available in Victoria?', answer: 'We stock budget brands like Manchester and Bond Street alongside premium Marlboro — all at prices far below Melbourne and VIC retail tobacconists.' },
  { question: 'Do you deliver to regional Victoria?', answer: 'Absolutely. We deliver to every VIC postcode including Geelong, Ballarat, Bendigo, Shepparton, Warrnambool, Mildura, and the Mornington Peninsula.' },
];

const CheapSmokesVIC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes VIC — Buy Cigarettes Online Victoria"
        description="Buy cheap cigarettes and tobacco online in Victoria. Cheapest prices on Marlboro, rolling tobacco, vapes & more. Fast delivery across VIC. Free shipping over A$50."
        canonical="/cheap-smokes-vic"
        keywords="cheap smokes VIC, buy cigarettes online Victoria, cheap cigarettes Victoria, tobacco delivery VIC, cigarettes online Victoria, cheap tobacco VIC, buy smokes Victoria, discount cigarettes Melbourne"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes VIC', url: '/cheap-smokes-vic' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Victoria
              <span className="text-primary block mt-2">Buy Cigarettes Online — VIC Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in Victoria</strong>? Aussie Smoke Store delivers the cheapest cigarettes, rolling tobacco &amp; vapes across all of VIC. Save big vs retail prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Victoria</h2>
            <p>
              Victorian smokers pay premium prices at local tobacconists. With Aussie Smoke Store, you can <strong>buy cigarettes online in Victoria</strong> at a fraction of the retail cost — delivered discreetly to your door anywhere in VIC, from Melbourne CBD to the Great Ocean Road and the Murray region.
            </p>
            <h3>Why Victorian Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Cheapest prices in Australia</strong> — far below VIC retail</li>
              <li><strong>Statewide delivery</strong> — Melbourne, Geelong, Ballarat, Bendigo, regional VIC</li>
              <li><strong>Huge selection</strong> — Marlboro, Manchester, rolling tobacco, vapes &amp; more</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet packaging</strong> — plain parcels for your privacy</li>
            </ul>
            <h3>VIC Areas We Deliver To</h3>
            <p>
              We deliver to every Victorian postcode — Melbourne, Geelong, Ballarat, Bendigo, Shepparton, Warrnambool, Mildura, Mornington Peninsula, Frankston, Dandenong, and hundreds more.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-melbourne" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Melbourne</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-nsw" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes NSW</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Victoria</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Victoria</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesVIC;
