import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Western Australia?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes, tobacco, and vapes across all of WA — from Perth to Fremantle, Bunbury, Geraldton, Kalgoorlie, and regional WA.' },
  { question: 'How long does cigarette delivery take in WA?', answer: 'Perth metro orders typically arrive within 4-6 business days. Regional WA may take 6-8 days. Orders over A$50 qualify for free shipping.' },
  { question: 'What are the cheapest cigarettes available in WA?', answer: 'We stock budget brands like Manchester and Bond Street alongside premium Marlboro — all at prices far below Perth and WA retail tobacconists.' },
  { question: 'Do you deliver to regional Western Australia?', answer: 'Absolutely. We deliver to every WA postcode including Bunbury, Geraldton, Kalgoorlie, Albany, Broome, Karratha, and all remote areas.' },
];

const CheapSmokesWA = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes WA — Buy Cigarettes Online Western Australia"
        description="Buy cheap cigarettes and tobacco online in Western Australia. Cheapest prices on Marlboro, rolling tobacco, vapes & more. Fast delivery across WA. Free shipping over A$50."
        canonical="/cheap-smokes-wa"
        keywords="cheap smokes WA, buy cigarettes online Western Australia, cheap cigarettes WA, tobacco delivery WA, cigarettes online Western Australia, cheap tobacco WA, buy smokes Perth, discount cigarettes WA"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes WA', url: '/cheap-smokes-wa' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Western Australia
              <span className="text-primary block mt-2">Buy Cigarettes Online — WA Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in WA</strong>? Aussie Smoke Store delivers the cheapest cigarettes, rolling tobacco &amp; vapes across all of Western Australia. Save big vs retail prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Western Australia</h2>
            <p>
              WA smokers face some of the highest tobacco prices in the country. With Aussie Smoke Store, you can <strong>buy cigarettes online in Western Australia</strong> at a fraction of the retail cost — delivered discreetly to your door from Perth to the Kimberley and everywhere in between.
            </p>
            <h3>Why WA Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Cheapest prices in Australia</strong> — far below WA retail</li>
              <li><strong>Statewide delivery</strong> — Perth, Fremantle, Bunbury, Geraldton, Kalgoorlie</li>
              <li><strong>Huge selection</strong> — Marlboro, Manchester, rolling tobacco, vapes &amp; more</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet packaging</strong> — plain parcels for your privacy</li>
            </ul>
            <h3>WA Areas We Deliver To</h3>
            <p>
              We deliver to every WA postcode — Perth, Fremantle, Joondalup, Rockingham, Mandurah, Bunbury, Geraldton, Kalgoorlie, Albany, Broome, Karratha, and all regional areas.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-perth" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Perth</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-qld" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes QLD</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Western Australia</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in WA</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesWA;
