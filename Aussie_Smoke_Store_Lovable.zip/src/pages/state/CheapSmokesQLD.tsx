import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in Queensland?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes, tobacco, and vapes across all of Queensland — from Brisbane to the Gold Coast, Sunshine Coast, Cairns, Townsville, and regional QLD.' },
  { question: 'How long does cigarette delivery take in QLD?', answer: 'Brisbane and Gold Coast orders typically arrive within 3-5 business days. Regional QLD may take 5-7 days. Orders over A$50 qualify for free shipping.' },
  { question: 'What are the cheapest cigarettes available in Queensland?', answer: 'We stock budget brands like Manchester and Bond Street alongside premium Marlboro — all at prices far below QLD retail tobacconists and supermarkets.' },
  { question: 'Do you deliver to regional Queensland?', answer: 'Absolutely. We deliver to every QLD postcode including Cairns, Townsville, Mackay, Rockhampton, Bundaberg, Toowoomba, and the Whitsundays.' },
];

const CheapSmokesQLD = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes QLD — Buy Cigarettes Online Queensland"
        description="Buy cheap cigarettes and tobacco online in Queensland. Cheapest prices on Marlboro, rolling tobacco, vapes & more. Fast delivery across QLD. Free shipping over A$50."
        canonical="/cheap-smokes-qld"
        keywords="cheap smokes QLD, buy cigarettes online Queensland, cheap cigarettes Queensland, tobacco delivery QLD, cigarettes online Queensland, cheap tobacco QLD, buy smokes Queensland, discount cigarettes Brisbane"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes QLD', url: '/cheap-smokes-qld' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Queensland
              <span className="text-primary block mt-2">Buy Cigarettes Online — QLD Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in Queensland</strong>? Aussie Smoke Store delivers the cheapest cigarettes, rolling tobacco &amp; vapes across all of QLD. Save big vs retail prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in Queensland</h2>
            <p>
              Queensland smokers pay premium prices at local tobacconists and servos. With Aussie Smoke Store, you can <strong>buy cigarettes online in Queensland</strong> at a fraction of the retail cost — delivered discreetly to your door from Brisbane to Cairns and everywhere in between.
            </p>
            <h3>Why QLD Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Cheapest prices in Australia</strong> — far below QLD retail</li>
              <li><strong>Statewide delivery</strong> — Brisbane, Gold Coast, Sunshine Coast, Cairns, Townsville</li>
              <li><strong>Huge selection</strong> — Marlboro, Manchester, rolling tobacco, vapes &amp; more</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet packaging</strong> — plain parcels for your privacy</li>
            </ul>
            <h3>QLD Areas We Deliver To</h3>
            <p>
              We deliver to every Queensland postcode — Brisbane, Gold Coast, Sunshine Coast, Cairns, Townsville, Mackay, Rockhampton, Bundaberg, Toowoomba, Ipswich, Logan, and hundreds more.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-brisbane" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Brisbane</Link>
            <Link to="/cheap-smokes-gold-coast" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Gold Coast</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-smokes-nsw" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes NSW</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — Queensland</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in Queensland</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesQLD;
