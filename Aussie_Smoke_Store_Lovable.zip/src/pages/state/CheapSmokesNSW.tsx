import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy cheap cigarettes online in NSW?', answer: 'Yes! Aussie Smoke Store delivers cheap cigarettes, tobacco, and vapes across all of New South Wales — from Sydney to Newcastle, Wollongong, the Central Coast, and regional NSW.' },
  { question: 'How long does cigarette delivery take in NSW?', answer: 'NSW metro orders typically arrive within 3-5 business days. Regional NSW may take 5-7 days. Orders over A$50 qualify for free shipping.' },
  { question: 'What are the cheapest cigarettes available in NSW?', answer: 'We stock budget-friendly brands like Manchester, Bond Street, and Choice alongside premium brands like Marlboro — all at prices far below NSW retail.' },
  { question: 'Do you deliver to regional NSW?', answer: 'Absolutely. We deliver to every NSW postcode including Dubbo, Tamworth, Orange, Bathurst, Coffs Harbour, Wagga Wagga, Albury, and all rural areas.' },
];

const CheapSmokesNSW = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Smokes NSW — Buy Cigarettes Online New South Wales"
        description="Buy cheap cigarettes and tobacco online in NSW. Cheapest prices on Marlboro, rolling tobacco, vapes & more. Fast delivery across all of New South Wales. Free shipping over A$50."
        canonical="/cheap-smokes-nsw"
        keywords="cheap smokes NSW, buy cigarettes online NSW, cheap cigarettes New South Wales, tobacco delivery NSW, cigarettes online NSW, cheap tobacco NSW, buy smokes NSW, discount cigarettes NSW"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes NSW', url: '/cheap-smokes-nsw' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes NSW
              <span className="text-primary block mt-2">Buy Cigarettes Online — New South Wales Delivery</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes in NSW</strong>? Aussie Smoke Store delivers the cheapest cigarettes, rolling tobacco &amp; vapes to every corner of New South Wales. Save big vs retail prices.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online in New South Wales</h2>
            <p>
              NSW smokers face some of the highest tobacco prices in Australia. With Aussie Smoke Store, you can <strong>buy cigarettes online in NSW</strong> at a fraction of the retail cost — delivered discreetly to your door anywhere in the state, from Sydney and the Central Coast to the Blue Mountains and far western NSW.
            </p>
            <h3>Why NSW Smokers Choose Aussie Smoke Store</h3>
            <ul>
              <li><strong>Cheapest prices in Australia</strong> — far below NSW retail tobacconists</li>
              <li><strong>Statewide delivery</strong> — Sydney, Newcastle, Wollongong, Central Coast, regional NSW</li>
              <li><strong>Huge selection</strong> — Marlboro, Manchester, rolling tobacco, vapes &amp; more</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Discreet packaging</strong> — plain parcels for your privacy</li>
            </ul>
            <h3>NSW Areas We Deliver To</h3>
            <p>
              We deliver to every NSW postcode — Sydney, Newcastle, Wollongong, Central Coast, Blue Mountains, Dubbo, Tamworth, Orange, Bathurst, Coffs Harbour, Wagga Wagga, Albury, Lismore, Port Macquarie, and hundreds more.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-sydney" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Sydney</Link>
            <Link to="/cheap-smokes-newcastle" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Newcastle</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Products — NSW</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online in NSW</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesNSW;
