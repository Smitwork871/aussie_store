import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy nicotine pouches in Australia?', answer: 'Aussie Smoke Store stocks a wide range of nicotine pouches including Velo, ZYN and more. Order online and enjoy fast, discreet delivery across Australia.' },
  { question: 'Are nicotine pouches legal in Australia?', answer: 'Nicotine pouches are available for purchase online in Australia for personal use by adults aged 18 and over. Check your state regulations for specific details.' },
  { question: 'What nicotine pouch brands do you carry?', answer: 'We carry popular brands including Velo, ZYN, and other premium nicotine pouch brands in various strengths and flavours.' },
  { question: 'How do nicotine pouches work?', answer: 'Nicotine pouches are tobacco-free, smoke-free products placed between your lip and gum. They deliver nicotine without combustion, making them a discreet alternative.' },
  { question: 'Do you offer free shipping on nicotine pouches?', answer: 'Yes! Free shipping Australia-wide on all orders over A$50, including nicotine pouches.' },
];

const NicotinePouchesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Nicotine Pouches Australia — Buy Velo, ZYN & More Online"
        description="Buy nicotine pouches online in Australia. Velo, ZYN & premium brands at the cheapest prices. Tobacco-free, smoke-free nicotine delivery. Free shipping over A$50."
        canonical="/nicotine-pouches-australia"
        keywords="nicotine pouches Australia, buy nicotine pouches online, Velo nicotine pouches, ZYN Australia, tobacco-free nicotine pouches, nicotine pouches delivery Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Nicotine Pouches Australia', url: '/nicotine-pouches-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Nicotine Pouches Australia
              <span className="text-primary block mt-2">Velo, ZYN & More</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Buy <strong>nicotine pouches online in Australia</strong>. Tobacco-free, smoke-free nicotine delivery from top brands like <strong>Velo</strong> and <strong>ZYN</strong>. Discreet packaging &amp; fast delivery.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Shop All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Nicotine Pouches Online in Australia</h2>
            <p>
              <strong>Nicotine pouches</strong> are the modern, tobacco-free way to enjoy nicotine. At Aussie Smoke Store, we stock Australia's best selection of nicotine pouches from brands like <strong>Velo</strong>, <strong>ZYN</strong>, and more — all at the cheapest prices online.
            </p>
            <p>
              Whether you prefer mint, citrus, or classic flavours, our range of nicotine pouches comes in various strengths from 4mg to 20mg. They're discreet, spit-free, and perfect for use anywhere — at work, on the go, or at home.
            </p>
            <h3>Why Choose Nicotine Pouches?</h3>
            <ul>
              <li><strong>Tobacco-free</strong> — no tobacco leaf, no smoke, no ash</li>
              <li><strong>Discreet</strong> — slim pouches fit comfortably under your lip</li>
              <li><strong>Variety</strong> — multiple flavours and nicotine strengths</li>
              <li><strong>Convenient</strong> — use anywhere without bothering others</li>
            </ul>
            <h3>Fast Delivery Across Australia</h3>
            <p>
              We deliver nicotine pouches to Sydney, Melbourne, Brisbane, Perth, Adelaide, Gold Coast, Hobart, Darwin, Canberra and all regional areas. <strong>Free shipping on orders over A$50.</strong>
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes Online</Link>
            <Link to="/cheap-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Tobacco Online</Link>
            <Link to="/buy-cigarettes-online-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Buy Cigarettes Australia</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Nicotine Pouches &amp; Products</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions About Nicotine Pouches</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default NicotinePouchesAustralia;
