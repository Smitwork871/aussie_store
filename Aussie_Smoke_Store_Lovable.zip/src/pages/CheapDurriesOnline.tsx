import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap durries online in Australia?', answer: 'Aussie Smoke Store sells the cheapest durries online in Australia. Browse our full range of cigarette brands and order with free shipping on orders over A$50.' },
  { question: 'What are durries?', answer: '"Durries" is Australian slang for cigarettes. At Aussie Smoke Store we sell genuine cheap durries from all the top brands at unbeatable prices.' },
  { question: 'Do you deliver durries Australia-wide?', answer: 'Yes! We deliver cheap durries to every state and territory in Australia. Free shipping on orders over A$50, flat rate A$10 for smaller orders.' },
];

const CheapDurriesOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Durries Online Australia"
        description="Buy cheap durries online in Australia. Cheapest cigarettes (durries) from top brands. Free shipping over A$50. Order durries online at Aussie Smoke Store."
        canonical="/cheap-durries-online"
        keywords="cheap durries, cheap durries online, cheap durries Australia, buy durries online Australia, durries online Australia, cheapest durries, durries delivery Australia"
        jsonLd={[
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Durries Online', url: '/cheap-durries-online' }]),
          faqJsonLd(FAQS),
          localBusinessJsonLd(),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16">
        <div className="container max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-center">
            Cheap Durries Online Australia
          </h1>
          <p className="text-lg text-muted-foreground text-center mb-8 max-w-2xl mx-auto">
            Score the <strong>cheapest durries online</strong> in Australia. Aussie Smoke Store stocks all the big-name cigarette brands at rock-bottom prices with <strong>free shipping over A$50</strong>.
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" asChild>
              <Link to="/products">Shop Durries Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8 text-center">Cheapest Durries in Australia</h2>
          <ProductGrid products={products} isLoading={isLoading} />
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">Why Buy Cheap Durries from Aussie Smoke Store?</h2>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
            <p>Australians love their durries, and we love giving you the <strong>cheapest durries online</strong>. Whether you call them durries, darts, smokes or ciggies — we've got you covered with the best prices in Australia.</p>
            <p>Our range includes <strong>Marlboro</strong>, <strong>Manchester</strong>, <strong>Benson &amp; Hedges</strong>, <strong>Peter Jackson</strong>, <strong>Winfield</strong> and more. All genuine, all delivered fast to anywhere in Australia.</p>
            <p>Browse our <Link to="/cheap-cigarettes-online" className="text-primary hover:underline">cheap cigarettes</Link> or check our <Link to="/cigarette-prices-australia" className="text-primary hover:underline">cigarette price guide</Link> to compare brands and find the best deal.</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">FAQ — Cheap Durries Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl text-center">
          <h2 className="text-2xl font-bold mb-4">Related Searches</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/cheap-darts-online" className="text-primary hover:underline">Cheap Darts Online</Link>
            <Link to="/cheap-smokes-online" className="text-primary hover:underline">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="text-primary hover:underline">Cheap Cigarettes Online</Link>
            <Link to="/cheapest-cigarettes-australia" className="text-primary hover:underline">Cheapest Cigarettes Australia</Link>
            <Link to="/buy-cheap-smokes-australia" className="text-primary hover:underline">Buy Cheap Smokes Australia</Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapDurriesOnline;
