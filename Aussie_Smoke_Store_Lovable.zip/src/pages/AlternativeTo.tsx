import React, { useEffect, useState } from 'react';
import { Link, useParams, Navigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight, Check, X } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

type Competitor = {
  slug: string;
  name: string;
  domain: string;
  tagline: string;
  intro: string;
  // honest, neutral comparison rows
  comparison: { feature: string; us: string; them: string; usWins: boolean }[];
  faqs: { question: string; answer: string }[];
};

const COMPETITORS: Record<string, Competitor> = {
  supercheapsmoke: {
    slug: 'supercheapsmoke',
    name: 'Supercheapsmoke',
    domain: 'supercheapsmoke.com.au',
    tagline: "Looking for a Supercheapsmoke alternative? You're in the right place.",
    intro:
      "If you've been buying from Supercheapsmoke and want better prices, faster dispatch, or a wider catalogue, Aussie Smoke Store is the Australian-owned alternative thousands of customers are switching to. Same categories — cigarettes, rolling tobacco, vapes and pouches — with transparent pricing, secure bank transfer, and Australia-wide delivery.",
    comparison: [
      { feature: 'Australia-wide delivery', us: 'Yes — every state & territory', them: 'Yes', usWins: false },
      { feature: 'Free shipping threshold', us: 'A$50', them: 'Varies', usWins: true },
      { feature: 'Dispatch time', us: '1–3 business days', them: '2–5 business days', usWins: true },
      { feature: 'Catalogue breadth', us: 'Cigarettes, rolling tobacco, vapes, pouches, accessories', them: 'Mostly cigarettes & rolling', usWins: true },
      { feature: 'Bank transfer payments', us: 'Yes — secure, no card fees', them: 'Yes', usWins: false },
      { feature: 'Adult age verification', us: '18+ enforced', them: '18+', usWins: false },
      { feature: 'Bulk pricing', us: 'Yes — see bulk page', them: 'Limited', usWins: true },
      { feature: 'Live order recovery support', us: 'Yes — email + cart recovery', them: 'No', usWins: true },
    ],
    faqs: [
      { question: 'Is Aussie Smoke Store a good alternative to Supercheapsmoke?', answer: 'Yes. Aussie Smoke Store offers a broader catalogue, faster dispatch, and free shipping over A$50 across Australia. Many former Supercheapsmoke customers switch for the wider range of vapes, pouches, and rolling tobacco.' },
      { question: 'Do you ship to the same areas as Supercheapsmoke?', answer: "Yes — we deliver Australia-wide including NSW, VIC, QLD, WA, SA, ACT, TAS and NT." },
      { question: 'Are your prices cheaper than Supercheapsmoke?', answer: 'Prices vary by product and time, but our bulk and category pages consistently show competitive pricing. We also run regular deals on /deals.' },
    ],
  },
  aussiesmokes: {
    slug: 'aussiesmokes',
    name: 'Aussiesmokes',
    domain: 'aussiesmokes.com',
    tagline: 'A faster, broader alternative to Aussiesmokes.',
    intro:
      "Aussiesmokes customers often ask us for a cheaper-shipping, broader-catalogue option. Aussie Smoke Store delivers across Australia with 1–3 business day dispatch, free shipping over A$50, and a deeper range of vapes and nicotine pouches alongside the classics.",
    comparison: [
      { feature: 'Australia-wide delivery', us: 'Yes', them: 'Yes', usWins: false },
      { feature: 'Free shipping threshold', us: 'A$50', them: 'Varies', usWins: true },
      { feature: 'Dispatch time', us: '1–3 business days', them: '2–5 business days', usWins: true },
      { feature: 'Vape range (IGET, UWELL, Alibarbar)', us: 'Yes — full range', them: 'Partial', usWins: true },
      { feature: 'Nicotine pouches', us: 'Yes — ZYN-style alternatives', them: 'Limited', usWins: true },
      { feature: 'Bank transfer payments', us: 'Yes — no card fees', them: 'Yes', usWins: false },
      { feature: 'City-specific delivery pages', us: '10+ cities', them: 'Few', usWins: true },
    ],
    faqs: [
      { question: 'Why switch from Aussiesmokes to Aussie Smoke Store?', answer: 'Wider catalogue (vapes + pouches), faster dispatch, and city-specific delivery information for Sydney, Melbourne, Brisbane, Perth, Adelaide and more.' },
      { question: 'Do you deliver to regional Australia?', answer: 'Yes — every postcode in Australia. Regional delivery typically takes 3–7 business days.' },
    ],
  },
  smokersconnect: {
    slug: 'smokersconnect',
    name: 'Smokers Connect',
    domain: 'smokersconnect.com.au',
    tagline: 'A cleaner, faster alternative to Smokers Connect.',
    intro:
      "Looking for a Smokers Connect alternative with clearer pricing and quicker dispatch? Aussie Smoke Store ships Australia-wide in 1–3 business days, offers free shipping over A$50, and carries an expanded vape and pouch catalogue at upfront prices.",
    comparison: [
      { feature: 'Transparent pricing (no hidden fees)', us: 'Yes', them: 'Yes', usWins: false },
      { feature: 'Free shipping threshold', us: 'A$50', them: 'A$50+', usWins: false },
      { feature: 'Dispatch time', us: '1–3 business days', them: '2–5 business days', usWins: true },
      { feature: 'Mobile-optimised checkout', us: 'Yes — sticky place-order, one tap', them: 'Basic', usWins: true },
      { feature: 'IGET & disposable vape range', us: 'Full range', them: 'Partial', usWins: true },
      { feature: 'Bulk cigarette pricing', us: 'Dedicated bulk page', them: 'Limited', usWins: true },
    ],
    faqs: [
      { question: 'Is Aussie Smoke Store a Smokers Connect alternative?', answer: 'Yes. We offer the same categories with a faster checkout, broader vape range, and a dedicated bulk-cigarette pricing page.' },
      { question: 'Do you offer the same brands?', answer: 'We stock Marlboro, Manchester, Benson & Hedges, Double Happiness, UWELL, Alibarbar, IGET and more — see our brand pages.' },
    ],
  },
  cheapcigarettes: {
    slug: 'cheapcigarettes',
    name: 'Cheap Cigarettes',
    domain: 'cheapcigarettes.com.au',
    tagline: 'A broader, more modern alternative to Cheap Cigarettes.',
    intro:
      "Cheap Cigarettes is well known for tobacco, but customers regularly switch to Aussie Smoke Store for the broader catalogue (vapes, pouches, accessories), faster dispatch, and a modern mobile checkout. Same Australia-wide delivery, more product variety.",
    comparison: [
      { feature: 'Cigarettes & rolling tobacco', us: 'Yes — full range', them: 'Yes', usWins: false },
      { feature: 'Vapes (IGET, UWELL, disposable)', us: 'Yes — full range', them: 'Limited', usWins: true },
      { feature: 'Nicotine pouches', us: 'Yes', them: 'No', usWins: true },
      { feature: 'Dispatch time', us: '1–3 business days', them: '2–5 business days', usWins: true },
      { feature: 'Free shipping threshold', us: 'A$50', them: 'A$50', usWins: false },
      { feature: 'Modern mobile checkout', us: 'Yes — sticky place-order', them: 'Basic', usWins: true },
      { feature: 'Order tracking & email recovery', us: 'Yes', them: 'Limited', usWins: true },
    ],
    faqs: [
      { question: 'Why is Aussie Smoke Store a better alternative?', answer: 'Broader catalogue including vapes and nicotine pouches, faster dispatch (1–3 business days), and a modern checkout experience designed for mobile.' },
      { question: 'Are your tobacco prices similar?', answer: 'Yes — tobacco pricing is competitive across the category. Visit our bulk-cigarettes-australia page for volume pricing.' },
    ],
  },
};

const AlternativeTo = () => {
  const { competitor } = useParams<{ competitor: string }>();
  const data = competitor ? COMPETITORS[competitor] : undefined;
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!data) return;
    const fetchProducts = async () => {
      const { data: rows } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(8);
      if (rows) setProducts(rows as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, [data]);

  if (!data) return <Navigate to="/" replace />;

  const title = `${data.name} Alternative Australia | Aussie Smoke Store`;
  const description = `Switch from ${data.name} to Aussie Smoke Store: Australia-wide dispatch, free shipping over A$50, wider range of cigarettes, vapes & pouches.`;


  return (
    <Layout>
      <SEOHead
        title={title}
        description={description}
        canonical={`/alternatives/${data.slug}`}
        keywords={`${data.name} alternative, ${data.name} vs Aussie Smoke Store, better than ${data.name}, ${data.domain} alternative, cheap smokes australia`}
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: 'Alternatives', url: '/alternatives' },
            { name: data.name, url: `/alternatives/${data.slug}` },
          ]),
          faqJsonLd(data.faqs),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container max-w-4xl text-center">
          <p className="text-sm uppercase tracking-wider text-primary font-semibold mb-3">
            Looking for a {data.name} alternative?
          </p>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            {data.tagline}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8">{data.intro}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link to="/products">
                Shop the Catalogue <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/deals">See Today's Deals</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">
            Aussie Smoke Store vs {data.name}
          </h2>
          <div className="overflow-x-auto rounded-lg border">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50">
                <tr>
                  <th className="text-left p-4 font-semibold">Feature</th>
                  <th className="text-left p-4 font-semibold text-primary">Aussie Smoke Store</th>
                  <th className="text-left p-4 font-semibold text-muted-foreground">{data.name}</th>
                </tr>
              </thead>
              <tbody>
                {data.comparison.map((row, i) => (
                  <tr key={i} className="border-t">
                    <td className="p-4 font-medium">{row.feature}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        {row.usWins ? (
                          <Check className="h-4 w-4 text-success shrink-0" />
                        ) : (
                          <Check className="h-4 w-4 text-muted-foreground shrink-0" />
                        )}
                        <span>{row.us}</span>
                      </div>
                    </td>
                    <td className="p-4 text-muted-foreground">{row.them}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground mt-4 text-center">
            Comparison based on publicly available information at time of writing. {data.name} is a trademark of its respective owner; Aussie Smoke Store is not affiliated with {data.name}.
          </p>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Popular with switchers</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">
                Browse All Products <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">
            FAQs about switching from {data.name}
          </h2>
          <div className="space-y-6">
            {data.faqs.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default AlternativeTo;
