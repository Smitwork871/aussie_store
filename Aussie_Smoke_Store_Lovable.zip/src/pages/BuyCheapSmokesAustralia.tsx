import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap smokes in Australia?', answer: 'Aussie Smoke Store is the best place to buy cheap smokes in Australia. We stock all major cigarette, tobacco, and vape brands at wholesale-level prices with Australia-wide delivery.' },
  { question: 'Is it legal to buy smokes online in Australia?', answer: 'Tobacco purchasing regulations vary by state. Aussie Smoke Store operates within applicable guidelines and requires age verification (18+) for all purchases.' },
  { question: 'How fast is delivery for cheap smokes in Australia?', answer: 'Standard delivery takes 3-7 business days to all Australian postcodes. Metro areas typically receive orders within 3-5 days. Free shipping on orders over A$50.' },
  { question: 'Do you deliver cheap smokes to rural Australia?', answer: 'Yes! We deliver to every Australian postcode — Sydney, Melbourne, Brisbane, Perth, Adelaide, Hobart, Darwin, Canberra, and all regional and remote areas.' },
];

const BuyCheapSmokesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('price', { ascending: true })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Buy Cheap Smokes Australia — Lowest Prices"
        description="Buy cheap smokes in Australia at the lowest prices online. Cigarettes, tobacco, vapes delivered to Sydney, Melbourne, Brisbane, Perth & all of Australia. Free shipping over A$50."
        canonical="/buy-cheap-smokes-australia"
        keywords="buy cheap smokes Australia, cheap smokes Australia, buy smokes online Australia, cheapest smokes Australia, smokes delivery Australia, buy cigarettes cheap Australia, affordable smokes Australia, smokes online Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Buy Cheap Smokes Australia', url: '/buy-cheap-smokes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Cheap Smokes in Australia
              <span className="text-primary block mt-2">Delivered to Your Door</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              <strong>Buy cheap smokes in Australia</strong> from Aussie Smoke Store. The lowest prices on cigarettes, tobacco, and vapes with <strong>free shipping over A$50</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Buy Cheap Smokes Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-smokes-online">Cheap Smokes Online</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Smokes Online — Australia-Wide Delivery</h2>
            <p>
              Looking to <strong>buy cheap smokes in Australia</strong>? Aussie Smoke Store delivers the cheapest cigarettes, rolling tobacco, vapes, and accessories to every corner of Australia — from Sydney and Melbourne to remote outback towns.
            </p>
            <h3>We Deliver Cheap Smokes to Every Australian City</h3>
            <ul>
              <li><strong>Sydney</strong> — Buy cheap smokes online with fast Sydney delivery</li>
              <li><strong>Melbourne</strong> — Cheapest smokes delivered to Melbourne metro & suburbs</li>
              <li><strong>Brisbane</strong> — Discount cigarettes shipped to Brisbane & Gold Coast</li>
              <li><strong>Perth</strong> — Affordable smokes delivered across Western Australia</li>
              <li><strong>Adelaide</strong> — Cheap tobacco and cigarettes to South Australia</li>
              <li><strong>Hobart & Darwin</strong> — Even Tasmania and NT get our best prices</li>
              <li><strong>Canberra</strong> — Capital city delivery at wholesale prices</li>
            </ul>
            <h3>Why Australians Choose Aussie Smoke Store</h3>
            <p>
              We're Australia's most trusted online smoke shop. Genuine products, unbeatable prices, and <strong>free shipping on orders over A$50</strong>. Join thousands of happy Australian customers.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/best-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Best Cigarettes Australia</Link>
            <Link to="/discount-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Discount Tobacco Online</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes Online</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheapest Smokes in Australia</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions — Buy Cheap Smokes Australia</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BuyCheapSmokesAustralia;
