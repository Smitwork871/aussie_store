import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap rolling tobacco online in Australia?', answer: 'Aussie Smoke Store offers the best prices on rolling tobacco in Australia. We stock premium and regular blends with free shipping on orders over A$50.' },
  { question: 'What rolling tobacco brands do you carry?', answer: 'We carry a wide range of rolling tobacco including premium and regular blends. Browse our full selection to find your favourite blend at the cheapest price.' },
  { question: 'Is rolling tobacco cheaper than cigarettes?', answer: 'Yes, rolling tobacco is generally more affordable per smoke than pre-made cigarettes. Buy rolling tobacco online in bulk from Aussie Smoke Store to save even more.' },
  { question: 'Do you sell rolling tobacco accessories?', answer: 'Yes! We sell filters, rolling papers, tubes, and pipes alongside our rolling tobacco range. Everything you need for the perfect roll-your-own experience.' },
];

const CheapRollingTobaccoOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data: cats } = await supabase
        .from('categories')
        .select('id')
        .or('slug.ilike.%rolling%,name.ilike.%rolling%')
        .eq('is_active', true);

      let query = supabase.from('public_products').select('*').eq('is_active', true);
      if (cats && cats.length > 0) {
        query = query.in('category_id', cats.map(c => c.id));
      }
      const { data } = await query.order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Rolling Tobacco Online Australia — Best Prices"
        description="Buy cheap rolling tobacco online in Australia. Premium and regular rolling tobacco blends at the lowest prices. Free shipping over A$50. Shop rolling tobacco online at Aussie Smoke Store."
        canonical="/cheap-rolling-tobacco-online"
        keywords="cheap rolling tobacco online, rolling tobacco online Australia, buy rolling tobacco online, cheap rolling tobacco Australia, roll your own tobacco online, loose tobacco online Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Rolling Tobacco Online', url: '/cheap-rolling-tobacco-online' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Rolling Tobacco Online
              <span className="text-primary block mt-2">Australia's Best Prices</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Buy <strong>cheap rolling tobacco online</strong> in Australia. Premium blends at unbeatable prices with <strong>free shipping over A$50</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products?category=rolling-tobacco">Shop Rolling Tobacco <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-tobacco-online">All Cheap Tobacco</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Rolling Tobacco Online in Australia</h2>
            <p>
              Aussie Smoke Store offers the <strong>cheapest rolling tobacco online</strong> in Australia. Whether you prefer premium or regular blends, we have the perfect rolling tobacco for your roll-your-own needs.
            </p>
            <h3>Why Roll Your Own?</h3>
            <ul>
              <li><strong>Save Money</strong> — Rolling tobacco is significantly cheaper per smoke than pre-made cigarettes</li>
              <li><strong>Customise Your Smoke</strong> — Control the size, tightness, and blend of every cigarette</li>
              <li><strong>Fresher Tobacco</strong> — Rolling tobacco stays fresher longer in sealed pouches</li>
              <li><strong>More Choice</strong> — Choose from a variety of blends and strengths</li>
            </ul>
            <h3>Rolling Tobacco Accessories</h3>
            <p>
              Complete your roll-your-own setup with our range of <strong>filters, rolling papers, tubes, and pipes</strong>. Everything you need at the cheapest prices, delivered Australia-wide.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes Online</Link>
            <Link to="/cheap-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Tobacco Online</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes Online</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheap Rolling Tobacco — Best Sellers</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Cheap Rolling Tobacco Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapRollingTobaccoOnline;
