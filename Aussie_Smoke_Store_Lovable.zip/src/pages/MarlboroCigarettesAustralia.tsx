import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy Marlboro cigarettes online in Australia?', answer: 'Aussie Smoke Store is Australia\'s trusted online store for Marlboro cigarettes. We stock Marlboro Red, Marlboro Gold, and other Marlboro varieties at the cheapest prices with Australia-wide delivery.' },
  { question: 'How much are Marlboro cigarettes in Australia online?', answer: 'At Aussie Smoke Store, Marlboro cigarettes are priced well below retail. Check our product pages for current pricing and take advantage of free shipping on orders over A$50.' },
  { question: 'Do you sell Marlboro Red and Marlboro Gold?', answer: 'Yes! We carry a full range of Marlboro products including Marlboro Red, Marlboro Gold, and other popular Marlboro varieties.' },
  { question: 'Is fast shipping available for Marlboro cigarettes?', answer: 'Yes, we offer fast, discreet shipping across Australia. Orders are processed within 1-3 business days with delivery in 3-7 business days.' },
];

const MarlboroCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Buy Marlboro Cigarettes Online Australia — Cheapest Prices"
        description="Buy Marlboro cigarettes online in Australia at the cheapest prices. Marlboro Red, Gold & more. Free shipping over A$50. Fast, discreet delivery Australia-wide."
        canonical="/marlboro-cigarettes-australia"
        keywords="Marlboro cigarettes Australia, buy Marlboro online Australia, Marlboro Red Australia, Marlboro Gold Australia, cheap Marlboro cigarettes, Marlboro carton price Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Marlboro Cigarettes Australia', url: '/marlboro-cigarettes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Marlboro Cigarettes Online
              <span className="text-primary block mt-2">Cheapest Prices in Australia</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Get <strong>Marlboro cigarettes</strong> delivered to your door at Australia's lowest online prices. Marlboro Red, Marlboro Gold and more — all with <strong>free shipping over A$50</strong>.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Marlboro <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Marlboro Cigarettes at the Cheapest Prices in Australia</h2>
            <p>
              <strong>Marlboro</strong> is the world's most iconic cigarette brand, and Aussie Smoke Store brings it to Australian smokers at unbeatable prices. Whether you prefer the bold flavour of <strong>Marlboro Red</strong> or the smooth taste of <strong>Marlboro Gold</strong>, we've got your favourite at prices you won't find cheaper anywhere online.
            </p>
            <h3>Why Buy Marlboro Online from Aussie Smoke Store?</h3>
            <ul>
              <li><strong>Cheapest prices</strong> — guaranteed lowest prices on Marlboro in Australia</li>
              <li><strong>Genuine products</strong> — authentic Marlboro cigarettes only</li>
              <li><strong>Free shipping</strong> — on all orders over A$50</li>
              <li><strong>Discreet packaging</strong> — plain, secure delivery</li>
              <li><strong>Australia-wide delivery</strong> — Sydney, Melbourne, Brisbane, Perth, Adelaide and beyond</li>
            </ul>
            <h3>Marlboro Range Available</h3>
            <p>
              We stock a complete range of Marlboro products including <strong>Marlboro Red</strong> (full flavour), <strong>Marlboro Gold</strong> (lights), and carton options for maximum savings. Buy in bulk and save even more with our volume discounts.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes Online</Link>
            <Link to="/best-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Best Cigarettes Australia</Link>
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes Online</Link>
            <Link to="/buy-cigarettes-online-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Buy Cigarettes Australia</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Our Cigarette Range</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Marlboro Cigarettes FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default MarlboroCigarettesAustralia;
