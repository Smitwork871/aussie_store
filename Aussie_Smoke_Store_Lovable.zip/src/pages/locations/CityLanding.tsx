import { useEffect, useMemo, useState } from "react";
import { useParams, Link, Navigate } from "react-router-dom";
import DOMPurify from "dompurify";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Truck, MapPin, ShieldCheck } from "lucide-react";

const CATEGORY_MAP: Record<string, { label: string; productCategory: string }> = {
  cigarettes: { label: "Cigarettes", productCategory: "cigarettes" },
  vapes: { label: "Vapes", productCategory: "vapes" },
  pouches: { label: "Nicotine Pouches", productCategory: "pouches" },
  tobacco: { label: "Rolling Tobacco", productCategory: "tobacco" },
};

interface City {
  id: string;
  slug: string;
  name: string;
  state: string;
  state_full: string;
  tier: number;
  population: number | null;
  region: string | null;
  nearest_capital: string | null;
  delivery_eta_days: string | null;
  intro_html: string | null;
  local_faq: { q: string; a: string }[] | null;
}

interface Props { category?: keyof typeof CATEGORY_MAP; }

export default function CityLanding({ category }: Props) {
  const params = useParams<{ citySlug: string; category?: string }>();
  const categoryKey = (category ?? (params.category as keyof typeof CATEGORY_MAP | undefined)) ?? undefined;
  const [city, setCity] = useState<City | null>(null);
  const [neighbors, setNeighbors] = useState<{ slug: string; name: string; state: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("seo_cities").select("*")
        .eq("slug", params.citySlug!).eq("is_active", true).maybeSingle();
      if (!active) return;
      if (error || !data) { setNotFound(true); setLoading(false); return; }
      setCity(data as unknown as City);
      const { data: nbs } = await supabase
        .from("seo_cities").select("slug, name, state")
        .eq("state", (data as { state: string }).state).eq("is_active", true)
        .neq("slug", params.citySlug!).limit(6);
      if (active) setNeighbors(nbs ?? []);
      setLoading(false);
    })();
    return () => { active = false; };
  }, [params.citySlug]);

  const categoryMeta = categoryKey ? CATEGORY_MAP[categoryKey] : null;
  const path = categoryKey ? `/locations/${params.citySlug}/${categoryKey}` : `/locations/${params.citySlug}`;

  const title = useMemo(() => {
    if (!city) return "Loading";
    if (categoryMeta) return `Cheap ${categoryMeta.label} Delivered to ${city.name}, ${city.state}`;
    return `Cheap Smokes & Vapes Delivered to ${city.name}, ${city.state}`;
  }, [city, categoryMeta]);

  const description = useMemo(() => {
    if (!city) return "";
    if (categoryMeta) return `${categoryMeta.label} delivered to ${city.name}, ${city.state}. ${city.delivery_eta_days ?? "2-5 business days"} delivery, free shipping over A$300, bank transfer checkout.`;
    return `Fast, discreet delivery of cigarettes, rolling tobacco, vapes and nicotine pouches to ${city.name}, ${city.state}. ${city.delivery_eta_days ?? "2-5 business days"}, free shipping over A$300.`;
  }, [city, categoryMeta]);

  const jsonLd = useMemo(() => {
    if (!city) return undefined;
    const SITE = "https://cheapsmokescentral.com";
    const breadcrumbs = {
      "@context": "https://schema.org", "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: SITE },
        { "@type": "ListItem", position: 2, name: `${city.name}, ${city.state}`, item: `${SITE}/locations/${city.slug}` },
        ...(categoryMeta ? [{ "@type": "ListItem", position: 3, name: categoryMeta.label, item: `${SITE}${path}` }] : []),
      ],
    };
    const localBusiness = {
      "@context": "https://schema.org", "@type": "Store",
      name: "Aussie Smoke Store", url: `${SITE}${path}`,
      areaServed: { "@type": "City", name: city.name, containedInPlace: { "@type": "State", name: city.state_full } },
      description,
    };
    const faqs = (city.local_faq && city.local_faq.length > 0) ? {
      "@context": "https://schema.org", "@type": "FAQPage",
      mainEntity: city.local_faq.map(f => ({
        "@type": "Question", name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    } : null;
    return faqs ? [breadcrumbs, localBusiness, faqs] : [breadcrumbs, localBusiness];
  }, [city, categoryMeta, description, path]);

  if (notFound) return <Navigate to="/not-found" replace />;
  if (loading || !city) return <div className="min-h-screen bg-background" />;
  if (categoryKey && !categoryMeta) return <Navigate to="/not-found" replace />;

  const h1 = categoryMeta
    ? `Cheap ${categoryMeta.label} Delivered to ${city.name}, ${city.state}`
    : `Cheap Smokes, Vapes & Pouches Delivered to ${city.name}, ${city.state}`;
  const productsHref = categoryMeta ? `/products?category=${categoryMeta.productCategory}` : `/products`;

  return (
    <div className="min-h-screen bg-background">
      <SEOHead title={title} description={description} canonical={path} jsonLd={jsonLd} />
      <Header />
      <main className="container mx-auto px-4 py-10 max-w-5xl">
        <nav aria-label="Breadcrumb" className="text-sm text-muted-foreground mb-4">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <span className="mx-2">/</span>
          <Link to={`/locations/${city.slug}`} className="hover:text-foreground">{city.name}, {city.state}</Link>
          {categoryMeta && (<><span className="mx-2">/</span><span>{categoryMeta.label}</span></>)}
        </nav>

        <h1 className="text-3xl md:text-4xl font-bold mb-3">{h1}</h1>
        <p className="text-muted-foreground mb-8">
          {city.region ? `${city.region} region · ` : ""}{city.state_full}
          {city.population ? ` · Population ~${city.population.toLocaleString()}` : ""}
        </p>

        <div className="grid md:grid-cols-3 gap-4 mb-10">
          <Card><CardContent className="pt-6 flex items-start gap-3">
            <Truck className="h-5 w-5 mt-1 text-primary" />
            <div><div className="font-semibold">Delivery to {city.name}</div>
              <div className="text-sm text-muted-foreground">{city.delivery_eta_days ?? "2-5 business days"} from dispatch</div></div>
          </CardContent></Card>
          <Card><CardContent className="pt-6 flex items-start gap-3">
            <MapPin className="h-5 w-5 mt-1 text-primary" />
            <div><div className="font-semibold">Nearest hub</div>
              <div className="text-sm text-muted-foreground">{city.nearest_capital ?? "Australia-wide network"}</div></div>
          </CardContent></Card>
          <Card><CardContent className="pt-6 flex items-start gap-3">
            <ShieldCheck className="h-5 w-5 mt-1 text-primary" />
            <div><div className="font-semibold">Free shipping ≥ A$300</div>
              <div className="text-sm text-muted-foreground">A$10 flat under threshold</div></div>
          </CardContent></Card>
        </div>

        {city.intro_html ? (
          <article className="max-w-none mb-10 [&_p]:text-foreground/90 [&_p]:leading-relaxed [&_p]:mb-4"
            dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(city.intro_html, {
              ALLOWED_TAGS: ['p', 'strong', 'em', 'a', 'br', 'ul', 'ol', 'li', 'h2', 'h3'],
              ALLOWED_ATTR: ['href', 'rel', 'target'],
              ALLOW_DATA_ATTR: false,
            }) }} />
        ) : (
          <p className="mb-10 text-foreground/90 leading-relaxed">
            We deliver {categoryMeta ? categoryMeta.label.toLowerCase() : "cigarettes, rolling tobacco, vapes and nicotine pouches"} to addresses across {city.name} and the broader {city.region ?? city.state_full} area. Most {city.name} orders arrive within {city.delivery_eta_days ?? "2-5 business days"} from our dispatch hub near {city.nearest_capital ?? "the nearest capital"}, with discreet packaging and bank-transfer checkout.
          </p>
        )}

        <div className="flex flex-wrap gap-3 mb-12">
          <Button asChild size="lg"><Link to={productsHref}>Shop {categoryMeta?.label ?? "Catalogue"}</Link></Button>
          {!categoryMeta && (<>
            <Button asChild variant="outline"><Link to={`/locations/${city.slug}/cigarettes`}>Cigarettes in {city.name}</Link></Button>
            <Button asChild variant="outline"><Link to={`/locations/${city.slug}/vapes`}>Vapes in {city.name}</Link></Button>
            <Button asChild variant="outline"><Link to={`/locations/${city.slug}/pouches`}>Pouches in {city.name}</Link></Button>
            <Button asChild variant="outline"><Link to={`/locations/${city.slug}/tobacco`}>Tobacco in {city.name}</Link></Button>
          </>)}
        </div>

        {city.local_faq && city.local_faq.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4">FAQs about delivery to {city.name}</h2>
            <div className="space-y-4">
              {city.local_faq.map((f, i) => (
                <div key={i} className="border border-border rounded-lg p-4">
                  <h3 className="font-semibold mb-2">{f.q}</h3>
                  <p className="text-foreground/80">{f.a}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {neighbors.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xl font-bold mb-3">Also serving nearby in {city.state}</h2>
            <div className="flex flex-wrap gap-2">
              {neighbors.map(n => (
                <Link key={n.slug} to={`/locations/${n.slug}`}
                  className="px-3 py-1.5 rounded-full border border-border text-sm hover:bg-accent">{n.name}</Link>
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}
