import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight, Store, Truck, Clock, ShieldCheck } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'How much do cigarettes cost at Coles and Woolworths in 2026?', answer: 'At major Australian supermarkets, a pack of 20 cigarettes typically costs between A$35 and A$55 depending on the brand. Premium brands like Marlboro and Dunhill sit at the higher end, while budget brands like Bond Street and Horizon are closer to A$35-A$40. Cartons of 10 packs can exceed A$400-$500 at checkout counters.' },
  { question: 'Is it cheaper to buy cigarettes online or at supermarkets?', answer: 'Buying cigarettes online from stores like Aussie Smoke Store is significantly cheaper than purchasing at Coles, Woolworths, or retail tobacconists. Online stores have lower overheads and can offer the same brands at a fraction of supermarket prices, plus deliver directly to your door.' },
  { question: 'Do Coles and Woolworths sell rolling tobacco?', answer: 'Yes, Coles and Woolworths sell limited rolling tobacco brands like Champion Ruby, JPS, and Port Royal. However, prices are high due to excise taxes, and stock is often limited compared to dedicated online tobacco shops.' },
  { question: 'Can you buy cigarettes online in Australia legally?', answer: 'Yes, purchasing tobacco products online is legal in Australia for adults aged 18+. Aussie Smoke Store operates in compliance with Australian tobacco regulations and requires age verification at checkout.' },
  { question: 'How much can I save buying cigarettes online instead of supermarkets?', answer: 'Savings vary by brand, but online shoppers typically save 30-60% compared to supermarket shelf prices. On a carton of 10 packs, the difference can be well over A$100-$200 depending on the brand and current promotions.' },
  { question: 'Do online tobacco shops offer free shipping like supermarkets?', answer: 'Aussie Smoke Store offers free shipping on orders over A$50 Australia-wide. Unlike supermarkets where you must travel and queue, online orders arrive at your door — saving both money and time.' },
];

const BRAND_COMPARISONS = [
  { brand: 'Marlboro Red', pack: 'Pack (20)', supermarket: '$45-$52', online: 'Significantly less' },
  { brand: 'Marlboro Gold', pack: 'Pack (20)', supermarket: '$45-$52', online: 'Significantly less' },
  { brand: 'Benson & Hedges', pack: 'Pack (20)', supermarket: '$42-$50', online: 'Significantly less' },
  { brand: 'Peter Jackson', pack: 'Pack (20)', supermarket: '$40-$48', online: 'Significantly less' },
  { brand: 'Winfield', pack: 'Pack (20)', supermarket: '$38-$46', online: 'Significantly less' },
  { brand: 'Bond Street', pack: 'Pack (20)', supermarket: '$35-$42', online: 'Significantly less' },
  { brand: 'Manchester', pack: 'Pack (20)', supermarket: '$36-$43', online: 'Significantly less' },
  { brand: 'Champion Ruby (30g)', pack: 'Pouch', supermarket: '$55-$68', online: 'Significantly less' },
  { brand: 'JPS Blue (30g)', pack: 'Pouch', supermarket: '$52-$65', online: 'Significantly less' },
  { brand: 'Drum (50g)', pack: 'Pouch', supermarket: '$80-$95', online: 'Significantly less' },
];

const SupermarketPriceComparison = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Tobacco Price Comparison: Supermarkets vs Online Australia"
        description="Compare cigarette and tobacco prices at Coles, Woolworths vs online. See how much you save buying cheap smokes online at Aussie Smoke Store. Free shipping over A$50."
        canonical="/tobacco-price-comparison-supermarkets"
        keywords="price of smokes in australia, cigarette prices coles, cigarette prices woolworths, supermarket tobacco prices australia, cheapest cigarettes australia, buy cheap cigarettes online, tobacco price comparison, coles cigarette prices, woolworths cigarette prices, online vs supermarket cigarettes"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Tobacco Price Comparison', url: '/tobacco-price-comparison-supermarkets' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Price of Smokes in Australia
              <span className="text-primary block mt-2">Supermarkets vs Online</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Compare <strong>cigarette prices at Coles, Woolworths</strong> and other major Australian supermarkets against online tobacco shops. See exactly how much you can save ordering online from Aussie Smoke Store.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" asChild>
                <Link to="/products">Shop Online Prices <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cigarette-prices-australia">Cigarette Price Guide 2026</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>How Much Are Cigarettes at Coles and Woolworths in 2026?</h2>
              <p>
                Australia has the highest cigarette prices in the world thanks to steep government excise taxes. When you walk into a <strong>Coles</strong> or <strong>Woolworths</strong> and head to the tobacco counter, expect to pay between <strong>A$35 and A$55+ per pack</strong> of 20 cigarettes. Premium brands like Marlboro, Dunhill, and Benson &amp; Hedges sit at the top of that range, while budget options such as Bond Street and Horizon are at the lower end.
              </p>
              <p>
                For smokers buying cartons — that's 10 packs — the checkout total can easily hit <strong>A$400 to A$550+</strong>. And that's before you factor in the time, fuel, and inconvenience of visiting a physical store.
              </p>

              <h2>Cigarette Price Comparison: Coles, Woolworths vs Online</h2>
              <p>
                Below is a price comparison table showing what you can expect to pay at major Australian supermarkets versus the dramatically lower prices available when you buy online from Aussie Smoke Store.
              </p>
            </div>

            <div className="overflow-x-auto mb-12">
              <table className="w-full border-collapse border rounded-lg">
                <thead>
                  <tr className="bg-secondary">
                    <th className="p-3 text-left font-semibold border-b">Brand / Product</th>
                    <th className="p-3 text-left font-semibold border-b">Size</th>
                    <th className="p-3 text-left font-semibold border-b">Coles / Woolworths</th>
                    <th className="p-3 text-left font-semibold border-b">Aussie Smoke Store</th>
                  </tr>
                </thead>
                <tbody>
                  {BRAND_COMPARISONS.map((item, i) => (
                    <tr key={i} className="hover:bg-secondary/30">
                      <td className="p-3 border-b font-medium">{item.brand}</td>
                      <td className="p-3 border-b">{item.pack}</td>
                      <td className="p-3 border-b text-muted-foreground">{item.supermarket}</td>
                      <td className="p-3 border-b">
                        <Link to="/products" className="text-primary font-semibold hover:underline">{item.online}</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="prose prose-neutral dark:prose-invert mb-12">
              <h2>Why Are Supermarket Cigarette Prices So High?</h2>
              <p>
                There are several reasons why the <strong>price of smokes in Australia</strong> at Coles and Woolworths is so steep:
              </p>
              <ol>
                <li><strong>Excise Tax</strong> — The Australian government imposes one of the highest tobacco excise rates globally. This tax increases every year and now makes up the majority of the retail price.</li>
                <li><strong>Retail Markups</strong> — Supermarkets and tobacconists add their own margin on top of wholesale costs to cover rent, wages, and other overheads.</li>
                <li><strong>Plain Packaging Laws</strong> — Since 2012, all tobacco products in Australia must be sold in plain packaging, but this regulation did not lower prices — it simply removed brand differentiation at the counter.</li>
                <li><strong>Minimum Pricing Policies</strong> — Some states enforce minimum pricing rules that prevent deep discounting.</li>
              </ol>

              <h2>The Online Advantage: Savings and Convenience</h2>
              <p>
                Buying cigarettes and tobacco online from Aussie Smoke Store offers two major advantages over supermarket purchases: <strong>lower prices</strong> and <strong>greater convenience</strong>.
              </p>
              <p>
                Online tobacco shops do not have the same overheads as bricks-and-mortar stores. There is no expensive retail lease, no checkout staff, and no physical display costs. These savings are passed directly to customers. The result is the same premium brands — Marlboro, Benson &amp; Hedges, Manchester, Peter Jackson, and more — at a fraction of the supermarket shelf price.
              </p>
              <p>
                Convenience is equally important. Instead of driving to Coles or Woolworths, queuing at the service desk, and walking out with overpriced packs, you can order from your phone or laptop and have your cigarettes delivered to your door. Aussie Smoke Store offers <strong>free shipping on orders over A$50</strong> Australia-wide, with discreet plain packaging and reliable delivery times.
              </p>

              <h2>Rolling Tobacco Prices: Supermarkets vs Online</h2>
              <p>
                Rolling tobacco is another area where online shops dramatically undercut supermarkets. A 30g pouch of <strong>Champion Ruby</strong> or <strong>JPS Blue</strong> at Coles or Woolworths can cost A$55 to A$68. A 50g pouch of <strong>Drum</strong> may reach A$80 to A$95. For smokers who roll their own, buying online can cut these costs substantially.
              </p>
              <p>
                Aussie Smoke Store stocks a wide range of rolling tobacco brands including Champion Ruby, JPS, Drum, Port Royal, and more. Browse our <Link to="/cheap-rolling-tobacco-online" className="text-primary hover:underline">cheap rolling tobacco</Link> selection for current pricing.
              </p>

              <h2>Vape and E-Cigarette Prices: Supermarkets vs Online</h2>
              <p>
                While Coles and Woolworths have started stocking limited vape products in some locations, the range is narrow and prices are high. Online vape shops like Aussie Smoke Store offer a far broader selection — from disposable vapes to refillable pod systems from brands like U Well, IGET, Kuz, and Alibarbar — at significantly better prices.
              </p>
              <p>
                Check our <Link to="/cheap-vapes-online" className="text-primary hover:underline">cheap vapes online</Link> page for the latest deals and product range.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
              <div className="p-6 rounded-lg bg-secondary/50 text-center">
                <Store className="mx-auto h-8 w-8 text-primary mb-3" />
                <h3 className="font-semibold mb-1">No Retail Markup</h3>
                <p className="text-sm text-muted-foreground">Skip the supermarket surcharge and buy direct.</p>
              </div>
              <div className="p-6 rounded-lg bg-secondary/50 text-center">
                <Truck className="mx-auto h-8 w-8 text-primary mb-3" />
                <h3 className="font-semibold mb-1">Free Delivery</h3>
                <p className="text-sm text-muted-foreground">Free shipping on orders over A$50 nationwide.</p>
              </div>
              <div className="p-6 rounded-lg bg-secondary/50 text-center">
                <Clock className="mx-auto h-8 w-8 text-primary mb-3" />
                <h3 className="font-semibold mb-1">Save Time</h3>
                <p className="text-sm text-muted-foreground">No queues, no trips — order from home in minutes.</p>
              </div>
              <div className="p-6 rounded-lg bg-secondary/50 text-center">
                <ShieldCheck className="mx-auto h-8 w-8 text-primary mb-3" />
                <h3 className="font-semibold mb-1">Discreet Packaging</h3>
                <p className="text-sm text-muted-foreground">Plain packaging delivered straight to your door.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheapest Cigarettes &amp; Tobacco Online</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Supermarket vs Online Cigarette Prices</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl text-center">
          <h2 className="text-2xl font-bold mb-4">Related Guides &amp; Comparisons</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/cigarette-prices-australia" className="text-primary hover:underline">Cigarette Prices Australia 2026</Link>
            <Link to="/cheap-cigarettes-online" className="text-primary hover:underline">Cheap Cigarettes Online</Link>
            <Link to="/cheapest-cigarettes-australia" className="text-primary hover:underline">Cheapest Cigarettes Australia</Link>
            <Link to="/cheap-rolling-tobacco-online" className="text-primary hover:underline">Rolling Tobacco Prices</Link>
            <Link to="/cheap-vapes-online" className="text-primary hover:underline">Vape Price Comparison</Link>
            <Link to="/buy-cigarettes-online-australia" className="text-primary hover:underline">Buy Cigarettes Online</Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default SupermarketPriceComparison;
