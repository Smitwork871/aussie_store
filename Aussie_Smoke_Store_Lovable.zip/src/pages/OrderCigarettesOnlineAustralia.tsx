import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'How do I order cigarettes online in Australia?', answer: 'Simply browse our products at Aussie Smoke Store, add items to your cart, and checkout. We offer secure payment and fast delivery to all Australian addresses.' },
  { question: 'Is ordering cigarettes online legal in Australia?', answer: 'Yes, adults aged 18 and over can legally purchase tobacco products online in Australia for personal use. Age verification is required.' },
  { question: 'How long does cigarette delivery take in Australia?', answer: 'We process orders within 1-3 business days. Delivery takes 3-7 business days depending on your location. Free shipping on orders over A$50.' },
];

const OrderCigarettesOnlineAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .eq('is_featured', true)
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Order Cigarettes Online Australia"
        description="Order cigarettes online in Australia with fast delivery. Cheapest prices on Marlboro, Manchester & more. Free shipping over A$50. Aussie Smoke Store."
        canonical="/order-cigarettes-online-australia"
        keywords="order cigarettes online Australia, order smokes online Australia, order cigarettes Australia, cigarette delivery Australia, order darts online Australia, cigarette home delivery Australia, order tobacco online Australia"
        jsonLd={[
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Order Cigarettes Online Australia', url: '/order-cigarettes-online-australia' }]),
          faqJsonLd(FAQS),
          localBusinessJsonLd(),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16">
        <div className="container max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-center">
            Order Cigarettes Online Australia
          </h1>
          <p className="text-lg text-muted-foreground text-center mb-8 max-w-2xl mx-auto">
            Ready to <strong>order cigarettes online</strong>? Aussie Smoke Store makes it easy — browse, add to cart, and we'll deliver the <strong>cheapest cigarettes</strong> right to your door anywhere in Australia.
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" asChild>
              <Link to="/products">Order Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8 text-center">Popular Cigarettes to Order Online</h2>
          <ProductGrid products={products} isLoading={isLoading} />
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">How to Order Cigarettes Online in Australia</h2>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
            <p>Ordering cigarettes online from Aussie Smoke Store is simple and secure:</p>
            <ol className="list-decimal pl-6 space-y-2">
              <li><strong>Browse</strong> our range of <Link to="/cheap-cigarettes-online" className="text-primary hover:underline">cheap cigarettes</Link>, <Link to="/cheap-rolling-tobacco-online" className="text-primary hover:underline">rolling tobacco</Link> and <Link to="/cheap-vapes-online" className="text-primary hover:underline">vapes</Link></li>
              <li><strong>Add to cart</strong> — buy cartons for the best per-pack price</li>
              <li><strong>Checkout</strong> with secure payment</li>
              <li><strong>Receive</strong> your order in discreet packaging within 3-7 business days</li>
            </ol>
            <p>Orders over A$50 qualify for <strong>free shipping</strong> Australia-wide. We deliver to every state and territory including NSW, VIC, QLD, WA, SA, TAS, NT and ACT.</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-4xl">
          <h2 className="text-3xl font-bold mb-6">FAQ — Order Cigarettes Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default OrderCigarettesOnlineAustralia;
