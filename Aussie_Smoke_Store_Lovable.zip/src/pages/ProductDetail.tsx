import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ProductGrid } from '@/components/products/ProductGrid';
import { useCart } from '@/contexts/CartContext';
import { useWishlist } from '@/contexts/WishlistContext';
import { supabase } from '@/integrations/supabase/client';
import { Product, Review } from '@/types/database';
import { 
  ShoppingCart, 
  Heart, 
  Minus, 
  Plus, 
  Truck, 
  Shield, 
  Star,
  ChevronLeft,
} from 'lucide-react';
import { toast } from 'sonner';
import { SEOHead, productJsonLd, breadcrumbJsonLd } from '@/components/SEOHead';
import { imgSize } from '@/lib/imageUtils';

const ProductDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!slug) return;
      
      setIsLoading(true);
      
      const { data: productData } = await supabase
        .from('public_products')
        .select('*, categories(*)')
        .eq('slug', slug)
        .eq('is_active', true)
        .single();

      if (productData) {
        setProduct(productData as unknown as Product);

        // Fetch related products
        const { data: related } = await supabase
          .from('public_products')
          .select('*')
          .eq('is_active', true)
          .eq('category_id', productData.category_id)
          .neq('id', productData.id)
          .limit(4);

        if (related) setRelatedProducts(related as Product[]);

        // Fetch reviews
        const { data: reviewsData } = await supabase
          .from('reviews')
          .select('*, profiles(*)')
          .eq('product_id', productData.id)
          .eq('is_approved', true)
          .order('created_at', { ascending: false });

        if (reviewsData) setReviews(reviewsData as unknown as Review[]);
      } else {
        navigate('/products');
        toast.error('Product not found');
      }
      
      setIsLoading(false);
    };

    fetchProduct();
  }, [slug, navigate]);

  const handleAddToCart = () => {
    if (product) {
      addToCart(product.id, quantity);
    }
  };

  const handleWishlistToggle = () => {
    if (!product) return;
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product.id);
    }
  };

  const inWishlist = product ? isInWishlist(product.id) : false;

  const discount = product?.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0;

  const avgRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-8">
          <div className="animate-pulse">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="aspect-square bg-secondary rounded-lg" />
              <div className="space-y-4">
                <div className="h-8 bg-secondary rounded w-3/4" />
                <div className="h-6 bg-secondary rounded w-1/4" />
                <div className="h-24 bg-secondary rounded" />
                <div className="h-12 bg-secondary rounded w-1/2" />
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!product) return null;

  const images = product.images?.length > 0 ? product.images : ['/placeholder.svg'];

  return (
    <Layout>
      <SEOHead
        title={`${product.name} — Buy Online Australia | Cheap Smokes`}
        description={product.short_description || product.description?.slice(0, 120) || `Buy ${product.name} online at cheap prices in Australia. Free shipping over A$50. Shop at Aussie Smoke Store.`}
        canonical={`/products/${product.slug}`}
        keywords={`${product.name}, buy ${product.name} online, cheap ${product.name}, ${product.brand || ''} online Australia, cheap smokes, cheap cigarettes online`}
        ogType="product"
        ogImage={product.images?.[0]}
        jsonLd={[
          productJsonLd({ ...product, avgRating: avgRating || undefined, reviewCount: reviews.length || undefined }),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: 'Products', url: '/products' },
            { name: product.name, url: `/products/${product.slug}` },
          ]),
        ]}
      />
      <div className="container py-8">
        {/* Breadcrumb */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back
        </Button>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Images */}
          <div className="space-y-4">
            <div className="relative aspect-square overflow-hidden rounded-xl bg-secondary">
              <img
                src={imgSize.detail(images[selectedImage])}
                alt={`${product.name} — buy online at Aussie Smoke Store`}
                className="h-full w-full object-cover"
                loading="eager"
              />
              {discount > 0 && (
                <Badge className="absolute top-4 left-4 bg-destructive text-lg">
                  -{discount}%
                </Badge>
              )}
            </div>
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {images.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === index ? 'border-primary' : 'border-transparent'
                    }`}
                  >
                    <img
                      src={imgSize.detailThumb(img)}
                      alt={`${product.name} ${index + 1}`}
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {product.brand && (
              <p className="text-sm text-muted-foreground uppercase tracking-wide">
                {product.brand}
              </p>
            )}
            
            <h1 className="text-3xl lg:text-4xl font-bold">{product.name}</h1>

            {/* Rating */}
            {reviews.length > 0 && (
              <div className="flex items-center gap-2">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-5 w-5 ${
                        star <= avgRating ? 'fill-primary text-primary' : 'text-muted'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  ({reviews.length} reviews)
                </span>
              </div>
            )}

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-bold text-primary">
                A${product.price.toFixed(2)}
              </span>
              {product.compare_at_price && (
                <span className="text-xl text-muted-foreground line-through">
                  A${product.compare_at_price.toFixed(2)}
                </span>
              )}
            </div>

            {/* Short Description */}
            {product.short_description && (
              <p className="text-muted-foreground">{product.short_description}</p>
            )}

            <Separator />

            {/* Stock Status */}
            <div>
              {product.stock_quantity > 0 ? (
                <Badge variant="secondary" className="bg-success/10 text-success">
                  In Stock ({product.stock_quantity} available)
                </Badge>
              ) : (
                <Badge variant="destructive">Out of Stock</Badge>
              )}
            </div>

            {/* Quantity & Add to Cart */}
            {product.stock_quantity > 0 && (
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center border rounded-lg">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                    aria-label="Decrease quantity"
                  >
                    <Minus className="h-4 w-4" aria-hidden="true" />
                  </Button>
                  <span className="w-12 text-center font-medium" aria-live="polite" aria-label={`Quantity ${quantity}`}>{quantity}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}
                    disabled={quantity >= product.stock_quantity}
                    aria-label="Increase quantity"
                  >
                    <Plus className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </div>
                <Button size="lg" onClick={handleAddToCart} className="flex-1">
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Add to Cart
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={handleWishlistToggle}
                  aria-label={inWishlist ? `Remove ${product?.name ?? 'product'} from wishlist` : `Add ${product?.name ?? 'product'} to wishlist`}
                  aria-pressed={inWishlist}
                  className={inWishlist ? 'text-destructive border-destructive' : ''}
                >
                  <Heart aria-hidden="true" className={`h-5 w-5 ${inWishlist ? 'fill-current' : ''}`} />
                </Button>
              </div>
            )}

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Truck className="h-5 w-5" />
                <span>Free shipping over A$50</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="h-5 w-5" />
                <span>Secure payment</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="description" className="mt-12">
          <TabsList>
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="reviews">Reviews ({reviews.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="mt-6">
            <div className="prose prose-neutral dark:prose-invert max-w-none">
              {product.description || 'No description available.'}
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="mt-6">
            {reviews.length > 0 ? (
              <div className="space-y-6">
                {reviews.map((review) => (
                  <div key={review.id} className="border-b pb-6 last:border-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-4 w-4 ${
                                star <= review.rating ? 'fill-primary text-primary' : 'text-muted'
                              }`}
                            />
                          ))}
                        </div>
                        {review.is_verified_purchase && (
                          <Badge variant="secondary" className="text-xs">Verified Purchase</Badge>
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {new Date(review.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    {review.title && <h3 className="text-base font-semibold mb-1">{review.title}</h3>}
                    {review.comment && <p className="text-muted-foreground">{review.comment}</p>}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No reviews yet.</p>
            )}
          </TabsContent>
        </Tabs>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <section className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Related Products</h2>
            <ProductGrid products={relatedProducts} />
          </section>
        )}
      </div>
    </Layout>
  );
};

export default ProductDetail;
