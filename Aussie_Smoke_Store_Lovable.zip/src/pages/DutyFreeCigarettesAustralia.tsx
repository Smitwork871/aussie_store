import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Can I buy duty-free cigarettes online in Australia?', answer: 'Aussie Smoke Store offers cigarettes at prices comparable to duty-free, delivered straight to your door. No need to travel to an airport — get duty-free level savings from home.' },
  { question: 'Are your prices really as cheap as duty-free?', answer: 'Our prices are among the lowest in Australia, often matching or beating duty-free prices. Plus, with free shipping over A$50, the savings are even greater.' },
  { question: 'What brands do you carry at duty-free prices?', answer: 'We stock Marlboro, Manchester, Benson & Hedges, Dunhill, and many more premium brands at the cheapest online prices in Australia.' },
  { question: 'How much can I save buying cigarettes online vs retail?', answer: 'Online prices at Aussie Smoke Store can save you significantly compared to retail tobacconist prices. Buy in bulk for even bigger savings.' },
];

const DutyFreeCigarettesAustralia = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Duty Free Cigarettes Australia — Cheapest Cigarettes Online"
        description="Buy cigarettes at duty-free prices online in Australia. Marlboro, Manchester & more at the cheapest prices. Free shipping over A$50. Fast delivery Australia-wide."
        canonical="/duty-free-cigarettes-australia"
        keywords="duty free cigarettes Australia, cheap duty free cigarettes, buy duty free cigarettes online, cheapest cigarettes Australia, duty free tobacco online, cigarette prices Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Duty Free Cigarettes Australia', url: '/duty-free-cigarettes-australia' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Duty Free Cigarettes Australia
              <span className="text-primary block mt-2">Cheapest Prices Online</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Get <strong>duty-free level prices</strong> on cigarettes and tobacco without leaving home. Premium brands at the <strong>cheapest prices in Australia</strong> — delivered to your door.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Cheap Cigarettes <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Duty-Free Level Savings on Cigarettes Online</h2>
            <p>
              Why wait for your next trip to buy <strong>duty-free cigarettes</strong>? Aussie Smoke Store offers premium cigarette brands at prices that rival duty-free shops — all from the comfort of your home with Australia-wide delivery.
            </p>
            <h3>Premium Brands at Unbeatable Prices</h3>
            <p>
              Our range includes all the brands you'd find at a duty-free store: <strong>Marlboro</strong>, <strong>Manchester</strong>, <strong>Benson &amp; Hedges</strong>, <strong>Dunhill</strong>, and more. Buy by the carton for maximum savings.
            </p>
            <h3>Save More with Aussie Smoke Store</h3>
            <ul>
              <li><strong>Lowest online prices</strong> — comparable to duty-free</li>
              <li><strong>No travel required</strong> — delivered to your door</li>
              <li><strong>Free shipping</strong> on orders over A$50</li>
              <li><strong>Bulk discounts</strong> — buy more, save more</li>
              <li><strong>All major brands</strong> available</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/marlboro-cigarettes-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Marlboro Cigarettes</Link>
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/discount-tobacco-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Discount Tobacco</Link>
            <Link to="/tobacco-delivery-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Tobacco Delivery</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Shop Cigarettes at Duty-Free Prices</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Duty Free Cigarettes FAQ</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default DutyFreeCigarettesAustralia;
