import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap cigarettes online in Australia?', answer: 'Aussie Smoke Store offers the cheapest cigarettes online in Australia. Browse our wide range of premium cigarette brands including Marlboro, Manchester and more — all at unbeatable prices with free delivery over A$50.' },
  { question: 'What are the cheapest cigarettes you sell?', answer: 'We stock a variety of budget-friendly cigarettes starting from competitive prices. Check our products page for the latest deals on cheap cigarettes online.' },
  { question: 'Can I buy Marlboro cigarettes online in Australia?', answer: 'Yes! Aussie Smoke Store stocks Marlboro and many other popular cigarette brands for purchase online. We deliver Australia-wide with discreet packaging.' },
  { question: 'How much does shipping cost for cigarettes?', answer: 'Shipping is FREE on all orders over A$50. For orders under A$50, a flat rate of A$10 applies for Australia-wide delivery.' },
  { question: 'Are the cigarettes you sell authentic?', answer: 'Absolutely. All cigarettes sold on Aussie Smoke Store are 100% authentic and sourced from authorised distributors. We guarantee quality on every product.' },
];

const CheapCigarettesOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      // Try to get cigarettes category products first
      const { data: cats } = await supabase
        .from('categories')
        .select('id')
        .ilike('name', '%cigarette%')
        .eq('is_active', true);

      let query = supabase.from('public_products').select('*').eq('is_active', true);

      if (cats && cats.length > 0) {
        query = query.in('category_id', cats.map(c => c.id));
      }

      const { data } = await query.order('is_featured', { ascending: false }).limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cheap Cigarettes Online Australia"
        description="Buy cheap cigarettes online in Australia. Marlboro, Manchester & top brands at the lowest prices. Free shipping over A$50. Order today."
        canonical="/cheap-cigarettes-online"
        keywords="cheap cigarettes, cheap cigarettes online, buy cigarettes online Australia, cheap cigarettes Australia, buy cheap cigarettes online, Marlboro online Australia, Manchester cigarettes online, cigarettes online Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Cigarettes Online', url: '/cheap-cigarettes-online' }]),
          faqJsonLd(FAQS),
        ]}
      />

      {/* Hero */}
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Cigarettes Online Australia
              <span className="text-primary block mt-2">Lowest Prices Guaranteed</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Buy <strong>cheap cigarettes online</strong> from Australia's most trusted tobacco store. Premium brands like Marlboro and Manchester at unbeatable prices. <strong>Free shipping over A$50</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products?category=cigarettes">Shop Cigarettes <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/cheap-smokes-online">All Cheap Smokes</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Buy Cheap Cigarettes Online — Australia's Best Selection</h2>
            <p>
              Aussie Smoke Store is the best place to <strong>buy cheap cigarettes online in Australia</strong>. We offer an extensive range of premium cigarette brands at prices you won't find anywhere else. Whether you prefer <strong>Marlboro</strong>, <strong>Manchester</strong>, or other popular brands, we have them all in stock and ready to ship.
            </p>
            <p>
              Our <strong>cheap cigarettes</strong> are 100% authentic and sourced from authorised distributors. We believe that premium quality shouldn't come with a premium price tag — that's why we offer the lowest prices on <strong>cigarettes online in Australia</strong>.
            </p>
            <h3>Cigarette Varieties Available</h3>
            <ul>
              <li><strong>Regular Cigarettes</strong> — Classic full-flavour cigarettes from top brands</li>
              <li><strong>Slim Cigarettes</strong> — Elegant slim-format cigarettes for a refined smoke</li>
              <li><strong>Menthol Cigarettes</strong> — Cool and refreshing menthol options</li>
            </ul>
            <h3>Fast & Discreet Delivery Across Australia</h3>
            <p>
              We deliver <strong>cheap cigarettes</strong> to every corner of Australia — including Sydney, Melbourne, Brisbane, Perth, Adelaide, Gold Coast, Canberra and beyond. All orders are shipped in discreet packaging for your privacy.
            </p>
          </div>

          {/* Quick Links */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Cheap Smokes Online
            </Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Cheap Vapes Online
            </Link>
            <Link to="/products?category=rolling-tobacco" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Rolling Tobacco
            </Link>
            <Link to="/categories" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              All Categories
            </Link>
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cheap Cigarettes — Top Sellers</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions About Cheap Cigarettes Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapCigarettesOnline;
