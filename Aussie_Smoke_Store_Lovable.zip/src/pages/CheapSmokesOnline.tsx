import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cheap smokes online in Australia?', answer: 'Aussie Smoke Store is your go-to online store for cheap smokes in Australia. We offer a wide range of premium cigarettes, rolling tobacco, vapes and accessories at the lowest prices with free shipping on orders over A$50.' },
  { question: 'Is it legal to buy cigarettes online in Australia?', answer: 'Yes, it is legal for adults aged 18 and over to purchase tobacco products online in Australia for personal use. Aussie Smoke Store only sells to verified adults.' },
  { question: 'What brands of cheap smokes do you sell?', answer: 'We carry popular brands including Marlboro, Manchester, and many more premium cigarette brands. We also stock rolling tobacco, vapes from U Well, Alibabar, Iget and Kuz, plus tobacco pouches and accessories.' },
  { question: 'Do you offer free shipping on cheap smokes?', answer: 'Yes! We offer free shipping Australia-wide on all orders over A$50. Orders under A$50 incur a flat shipping fee of A$10.' },
  { question: 'How fast is delivery for online cigarette orders?', answer: 'We process orders within 1-3 business days and delivery typically takes 3-7 business days depending on your location in Australia.' },
];

const CheapSmokesOnline = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Order Cheap Smokes Online — Australia-Wide Delivery"
        description="Order cheap smokes online with Australia-wide delivery. Cheapest cigarettes, rolling tobacco, vapes & accessories. Free shipping over A$50."
        canonical="/cheap-smokes-online"
        keywords="cheap smokes, cheap smokes online, cheap smokes Australia, buy cheap smokes online, cheap cigarettes online Australia, cheap tobacco online, buy smokes online Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cheap Smokes Online', url: '/cheap-smokes-online' }]),
          faqJsonLd(FAQS),
        ]}
      />

      {/* Hero */}
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Cheap Smokes Online Australia
              <span className="text-primary block mt-2">Best Prices Guaranteed</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Looking for <strong>cheap smokes online</strong>? Aussie Smoke Store offers Australia's widest range of premium cigarettes, rolling tobacco, vapes and smoking accessories at unbeatable prices. Enjoy <strong>free shipping on orders over A$50</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">Shop All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/categories">Browse Categories</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Why Buy Cheap Smokes Online from Aussie Smoke Store?</h2>
            <p>
              At Aussie Smoke Store, we make it easy to <strong>buy cheap smokes online in Australia</strong>. Whether you're looking for <strong>cheap cigarettes</strong>, premium rolling tobacco, or the latest vapes, we've got you covered with the best prices and fastest delivery across Australia.
            </p>
            <p>
              Our extensive catalogue includes top brands like <strong>Marlboro</strong>, <strong>Manchester</strong>, and more. We also carry a huge range of <strong>vapes</strong> from leading brands including U Well, Alibabar, Iget and Kuz — plus rolling tobacco, tobacco pouches from Velo and ZYN, and all the accessories you need.
            </p>
            <h3>Australia-Wide Delivery on Cheap Smokes</h3>
            <p>
              We deliver <strong>cheap smokes</strong> to every state and territory in Australia — Sydney, Melbourne, Brisbane, Perth, Adelaide, Hobart, Darwin and Canberra. Orders over A$50 qualify for <strong>free shipping</strong>, making Aussie Smoke Store the smartest choice for buying tobacco products online.
            </p>
          </div>

          {/* Quick Links */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Cheap Cigarettes Online
            </Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Cheap Vapes Online
            </Link>
            <Link to="/products?category=rolling-tobacco" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Rolling Tobacco
            </Link>
            <Link to="/products?category=tobacco-pouches" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">
              Tobacco Pouches
            </Link>
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Cheap Smokes</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Frequently Asked Questions About Cheap Smokes Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CheapSmokesOnline;
