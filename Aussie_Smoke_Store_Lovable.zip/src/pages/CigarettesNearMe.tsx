import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'Where can I buy cigarettes near me online?', answer: 'Aussie Smoke Store delivers cigarettes to your door anywhere in Australia — it\'s like having a cigarette shop near you, but with cheaper prices and no need to leave home.' },
  { question: 'Is buying cigarettes online cheaper than a tobacconist near me?', answer: 'Yes! Online prices at Aussie Smoke Store are significantly lower than brick-and-mortar tobacco shops. Save even more with free shipping on orders over A$50.' },
  { question: 'How fast can I get cigarettes delivered?', answer: 'Orders are processed within 1-3 business days with 3-7 day delivery Australia-wide. Much faster than waiting for a sale at your local shop!' },
  { question: 'Do you deliver to regional areas?', answer: 'Yes, we deliver everywhere in Australia — major cities and regional towns alike. No matter where you are, we\'ll get your order to you.' },
];

const CigarettesNearMe = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .order('is_featured', { ascending: false })
        .limit(12);
      if (data) setProducts(data as Product[]);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Cigarettes Near Me — Delivered Australia-Wide"
        description="Looking for cigarettes near me? Buy cheap cigarettes online and get them delivered to your door anywhere in Australia. Cheapest prices, free shipping over A$50."
        canonical="/cigarettes-near-me"
        keywords="cigarettes near me, buy cigarettes near me, tobacco shop near me, cheap cigarettes near me, cigarettes online delivery, tobacconist near me online, cigarettes delivered Australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Cigarettes Near Me', url: '/cigarettes-near-me' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Buy Cigarettes Near Me
              <span className="text-primary block mt-2">Delivered to Your Door</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Searching for <strong>cigarettes near me</strong>? Skip the trip — Aussie Smoke Store delivers the cheapest cigarettes, tobacco &amp; vapes straight to your door anywhere in Australia.
            </p>
            <Button size="lg" asChild>
              <Link to="/products">Shop Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-neutral dark:prose-invert mb-12">
            <h2>Your Online Tobacconist — Cheaper Than Any Shop Near You</h2>
            <p>
              Instead of searching for <strong>cigarettes near me</strong> or <strong>tobacco shop near me</strong>, save time and money by ordering online from Aussie Smoke Store. We offer prices far below what you'll find at any local tobacconist, with the convenience of home delivery.
            </p>
            <h3>We Deliver Cigarettes to Every City in Australia</h3>
            <p>
              No matter where you live — <strong>Sydney</strong>, <strong>Melbourne</strong>, <strong>Brisbane</strong>, <strong>Perth</strong>, <strong>Adelaide</strong>, <strong>Gold Coast</strong>, <strong>Newcastle</strong>, <strong>Canberra</strong>, <strong>Hobart</strong>, or <strong>Darwin</strong> — Aussie Smoke Store is your online tobacco shop that delivers.
            </p>
            <h3>Why Order Online Instead of Buying Locally?</h3>
            <ul>
              <li><strong>Lower prices</strong> — save significantly vs retail tobacconists</li>
              <li><strong>Wider selection</strong> — more brands and products than any local shop</li>
              <li><strong>Convenience</strong> — order from your couch, delivered to your door</li>
              <li><strong>Discreet</strong> — plain packaging for your privacy</li>
              <li><strong>Free shipping</strong> — on orders over A$50</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            <Link to="/cheap-cigarettes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Cigarettes</Link>
            <Link to="/tobacco-delivery-australia" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Tobacco Delivery</Link>
            <Link to="/cheap-smokes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Smokes</Link>
            <Link to="/cheap-vapes-online" className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-center font-medium">Cheap Vapes</Link>
          </div>
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Popular Cigarettes &amp; Tobacco</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">View All Products <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">FAQ — Buying Cigarettes Online</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default CigarettesNearMe;
