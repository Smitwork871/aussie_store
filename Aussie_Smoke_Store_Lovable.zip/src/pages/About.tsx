import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Shield, Truck, Award, Users } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd } from '@/components/SEOHead';

const About = () => {
  return (
    <Layout>
      <SEOHead
        title="About Aussie Smoke Store — Cheap Smokes Online Australia"
        description="Aussie Smoke Store is Australia's trusted source for cheap smokes online. Premium cigarettes, vapes & tobacco at the best prices. Fast delivery."
        canonical="/about"
        keywords="cheap smokes online Australia, about Aussie Smoke Store, buy cigarettes online Australia"
        jsonLd={breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'About', url: '/about' }])}
      />
      <div className="container py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">About Aussie Smoke Store</h1>
          <p className="text-xl text-muted-foreground mb-8">
            Your trusted source for premium tobacco products since 2020.
          </p>

          <div className="prose prose-gray max-w-none mb-12">
            <p>
             At Aussie Smoke Store, we are committed to providing our customers with the finest 
              selection of tobacco products. Our curated collection includes premium cigarettes, 
              high-quality cigarettes, traditional pipes, and various tobacco accessories.
            </p>
            <p>
              We believe in quality, authenticity, and exceptional customer service. Every 
              product in our store is carefully selected to meet the highest standards, 
              ensuring that our customers receive only the best.
            </p>
          </div>

          <h2 className="text-2xl font-bold mb-6">Why Choose Us</h2>
          <div className="grid sm:grid-cols-2 gap-6 mb-12">
            <Card>
              <CardContent className="flex items-start gap-4 pt-6">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Authentic Products</h3>
                  <p className="text-sm text-muted-foreground">
                    100% genuine products sourced directly from authorized distributors.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex items-start gap-4 pt-6">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Truck className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Fast Delivery</h3>
                  <p className="text-sm text-muted-foreground">
                    Quick and discreet shipping to your doorstep across Australia.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex items-start gap-4 pt-6">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Award className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Premium Quality</h3>
                  <p className="text-sm text-muted-foreground">
                    Only the finest tobacco products make it to our collection.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex items-start gap-4 pt-6">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Expert Support</h3>
                  <p className="text-sm text-muted-foreground">
                    Our knowledgeable team is here to help you find the perfect product.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="bg-secondary/50 rounded-lg p-6 text-center">
            <p className="text-sm text-muted-foreground">
              ⚠️ Statutory Warning: Cigarette smoking is injurious to health. 
              Tobacco causes cancer. This website is intended for adults aged 21 and above only.
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default About;
