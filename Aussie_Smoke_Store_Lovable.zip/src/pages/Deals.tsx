import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { TrustStrip } from '@/components/TrustStrip';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight, Flame, Truck, ShieldCheck, Clock } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';

const FAQS = [
  { question: 'What deals does Aussie Smoke Store offer?', answer: 'We rotate weekly deals across cigarettes, rolling tobacco, vapes and nicotine pouches. Free shipping is automatic on orders over A$50.' },
  { question: 'How fast is delivery?', answer: 'Orders dispatch within 1–3 business days; delivery Australia-wide takes 3–7 business days.' },
  { question: 'How do I pay?', answer: 'We accept secure bank transfer only — no card surcharges. You receive bank details on the order confirmation page.' },
  { question: 'Do I need to be 18+?', answer: 'Yes — every order requires adult age verification (18+).' },
];

const Deals = () => {
  const [featured, setFeatured] = useState<Product[]>([]);
  const [discounted, setDiscounted] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const [{ data: f }, { data: d }] = await Promise.all([
        supabase
          .from('public_products')
          .select('*')
          .eq('is_active', true)
          .eq('is_featured', true)
          .limit(8),
        supabase
          .from('public_products')
          .select('*')
          .eq('is_active', true)
          .not('compare_at_price', 'is', null)
          .limit(12),
      ]);
      if (f) setFeatured(f as Product[]);
      if (d) setDiscounted(d as Product[]);
      setLoading(false);
    };
    load();
  }, []);

  return (
    <Layout>
      <SEOHead
        title="Today's Deals — Cheap Smokes, Vapes & Pouches Australia"
        description="Daily deals on cigarettes, rolling tobacco, vapes and nicotine pouches. Free shipping over A$50, 1–3 day dispatch Australia-wide."
        canonical="/deals"
        keywords="cheap smokes deals, vape deals australia, cigarette deals, tobacco discount australia"
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([{ name: 'Home', url: '/' }, { name: 'Deals', url: '/deals' }]),
          faqJsonLd(FAQS),
        ]}
      />

      <section className="relative overflow-hidden bg-gradient-to-br from-primary/20 via-background to-accent/20 py-16 md:py-24">
        <div className="container max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-6">
            <Flame className="h-4 w-4" /> Live Deals — Updated Daily
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">
            Australia's Best Deals on<br />
            <span className="text-primary">Smokes, Vapes & Pouches</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8">
            Save more every day. <strong>Free shipping over A$50</strong>, dispatched in 1–3 business days, delivered Australia-wide.
          </p>
          <Button size="lg" asChild>
            <Link to="/products">
              Shop Deals Now <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="container py-6">
        <TrustStrip />
      </section>

      <section className="py-12">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">🔥 Top Deals This Week</h2>
          <ProductGrid products={discounted} isLoading={loading} />
        </div>
      </section>

      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">⭐ Bestsellers</h2>
          <ProductGrid products={featured} isLoading={loading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">
                Browse All Products <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 rounded-lg border bg-card">
              <Truck className="h-8 w-8 mx-auto mb-3 text-primary" />
              <h3 className="font-semibold mb-2">Free Shipping over A$50</h3>
              <p className="text-sm text-muted-foreground">Flat A$10 below threshold. Australia-wide.</p>
            </div>
            <div className="text-center p-6 rounded-lg border bg-card">
              <Clock className="h-8 w-8 mx-auto mb-3 text-primary" />
              <h3 className="font-semibold mb-2">Fast Dispatch</h3>
              <p className="text-sm text-muted-foreground">Orders ship within 1–3 business days.</p>
            </div>
            <div className="text-center p-6 rounded-lg border bg-card">
              <ShieldCheck className="h-8 w-8 mx-auto mb-3 text-primary" />
              <h3 className="font-semibold mb-2">Secure Bank Transfer</h3>
              <p className="text-sm text-muted-foreground">No card fees. Reference code on every order.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Deals FAQs</h2>
          <div className="space-y-6">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Deals;
