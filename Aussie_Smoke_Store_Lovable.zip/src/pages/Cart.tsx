import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { useCart } from '@/contexts/CartContext';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Truck } from 'lucide-react';
import { SEOHead } from '@/components/SEOHead';
import { TrustStrip } from '@/components/TrustStrip';
import { imgSize } from '@/lib/imageUtils';

const FREE_SHIPPING_THRESHOLD = 50;

const Cart = () => {
  const navigate = useNavigate();
  const { items, updateQuantity, removeFromCart, subtotal, itemCount, isLoading } = useCart();

  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : 10;
  const total = subtotal + shipping;
  const remainingForFreeShip = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const freeShipProgress = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-8">
          <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-secondary rounded-lg" />
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  if (items.length === 0) {
    return (
      <Layout>
        <SEOHead title="Shopping Cart" description="Your Aussie Smoke Store shopping cart is empty. Browse our cheap cigarettes, rolling tobacco, vapes and nicotine pouches and enjoy free Australia-wide shipping on orders over A$50." canonical="/cart" noindex />
        <div className="container py-16">

          <div className="max-w-md mx-auto text-center">
            <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h1 className="text-2xl font-bold mb-2">Your cart is empty</h1>
            <p className="text-muted-foreground mb-6">
              Looks like you haven't added anything to your cart yet.
            </p>
            <Button asChild>
              <Link to="/products">
                Continue Shopping <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <SEOHead title="Shopping Cart" description="Review the cheap smokes, cigarettes, tobacco and vapes in your Aussie Smoke Store cart. Update quantities, apply discount codes and checkout with free Australia-wide shipping over A$50." canonical="/cart" noindex />
      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-6">Shopping Cart ({itemCount} items)</h1>


        {/* Free shipping progress */}
        <div className="mb-6 rounded-lg border bg-card/50 p-4">
          <div className="flex items-center justify-between mb-2 text-sm">
            <span className="inline-flex items-center gap-2">
              <Truck className="h-4 w-4 text-primary" aria-hidden />
              {remainingForFreeShip > 0 ? (
                <>Add <strong>A${remainingForFreeShip.toFixed(2)}</strong> more for free shipping</>
              ) : (
                <strong className="text-primary">🎉 You've unlocked free shipping!</strong>
              )}
            </span>
            <span className="text-xs text-muted-foreground">A${subtotal.toFixed(2)} / A${FREE_SHIPPING_THRESHOLD}</span>
          </div>
          <Progress value={freeShipProgress} className="h-2" />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <Link to={`/products/${item.product.slug}`} className="flex-shrink-0">
                      <img
                        src={imgSize.cartItem(item.product.images?.[0])}
                        alt={item.product.name}
                        className="w-24 h-24 object-cover rounded-lg"
                      />
                    </Link>
                    <div className="flex-1 min-w-0">
                      <Link
                        to={`/products/${item.product.slug}`}
                        className="font-semibold hover:text-primary transition-colors line-clamp-2"
                      >
                        {item.product.name}
                      </Link>
                      {item.product.brand && (
                        <p className="text-sm text-muted-foreground">{item.product.brand}</p>
                      )}
                      <p className="font-bold text-primary mt-1">
                        A${item.product.price.toFixed(2)}
                      </p>
                    </div>
                    <div className="flex flex-col items-end justify-between">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFromCart(item.product_id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <div className="flex items-center border rounded-lg">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-8 text-center text-sm">{item.quantity}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                          disabled={item.quantity >= item.product.stock_quantity}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div>
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>A${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `A$${shipping.toFixed(2)}`}</span>
                </div>
                {shipping > 0 && (
                  <p className="text-sm text-muted-foreground">
                    Add A${remainingForFreeShip.toFixed(2)} more for free shipping
                  </p>
                )}
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-primary">A${total.toFixed(2)}</span>
                </div>
                <TrustStrip variant="compact" className="pt-2 justify-center" />
              </CardContent>
              <CardFooter className="flex-col gap-3">
                <Button className="w-full" size="lg" onClick={() => navigate('/checkout')}>
                  Proceed to Checkout
                </Button>
                <Button variant="outline" className="w-full" asChild>
                  <Link to="/products">Continue Shopping</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Cart;
