import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Unsubscribe() {
  const [status, setStatus] = useState<"loading" | "done" | "error">("loading");
  const [email, setEmail] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const e = (params.get("email") || "").trim().toLowerCase();
    setEmail(e);
    if (!e) { setStatus("error"); return; }
    supabase.functions
      .invoke("broadcast-unsubscribe", { body: { email: e } })
      .then(({ error }) => setStatus(error ? "error" : "done"));
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <Card className="max-w-md w-full">
        <CardHeader><CardTitle>Email preferences</CardTitle></CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-3">
          {status === "loading" && <p>Processing your request…</p>}
          {status === "done" && (
            <p><strong className="text-foreground">{email}</strong> has been unsubscribed from Aussie Smoke Store broadcast emails. You will still receive transactional emails related to your orders.</p>
          )}
          {status === "error" && <p>Could not process request. Please contact support.</p>}
        </CardContent>
      </Card>
    </div>
  );
}
