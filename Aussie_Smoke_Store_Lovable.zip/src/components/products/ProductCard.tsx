import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Product } from '@/types/database';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';
import { useWishlist } from '@/contexts/WishlistContext';
import { ShoppingCart, Heart, Zap } from 'lucide-react';
import { imgSize } from '@/lib/imageUtils';

interface ProductCardProps {
  product: Product & { categories?: { image_url?: string | null } | null };
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const navigate = useNavigate();
  const inWishlist = isInWishlist(product.id);
  
  const discount = product.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product.id);
  };

  const handleBuyNow = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    await addToCart(product.id);
    navigate('/checkout');
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (inWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product.id);
    }
  };

  const imageUrl = imgSize.card(product.images?.[0] || product.categories?.image_url);
  const productPath = `/products/${product.slug}`;

  return (
    <article className="group relative overflow-hidden rounded-lg border bg-card text-card-foreground">
        <div className="relative aspect-square overflow-hidden bg-secondary/40">
          <Link to={productPath} aria-label={product.name}>
            <img src={imageUrl} alt={product.name} loading="lazy" className="h-full w-full object-contain p-4" />
          </Link>
          {discount > 0 && (
            <Badge className="absolute top-2 left-2 bg-destructive">
              -{discount}%
            </Badge>
          )}
          <Button
            variant="ghost"
            size="icon"
            aria-label={inWishlist ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
            aria-pressed={inWishlist}
            className={`absolute top-2 right-2 bg-background/80 hover:bg-background ${
              inWishlist ? 'text-destructive' : 'text-muted-foreground'
            }`}
            onClick={handleWishlistToggle}
          >
            <Heart aria-hidden="true" className={`h-5 w-5 ${inWishlist ? 'fill-current' : ''}`} />
          </Button>
          {product.is_featured && !discount && (
            <Badge className="absolute top-12 right-2 bg-primary">
              Featured
            </Badge>
          )}
          {product.stock_quantity <= 0 && (
            <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
              <Badge variant="secondary" className="text-lg">Out of Stock</Badge>
            </div>
          )}
          <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300 p-3 bg-gradient-to-t from-background/95 to-transparent">
            <Button
              onClick={handleAddToCart}
              className="w-full"
              disabled={product.stock_quantity <= 0}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </Button>
          </div>
        </div>
        <CardContent className="p-4">
          {product.brand && (
            <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
              {product.brand}
            </p>
          )}
          <h3 className="font-semibold line-clamp-2 mb-2 group-hover:text-primary transition-colors">
            <Link to={productPath}>{product.name}</Link>
          </h3>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-primary">
              A${product.price.toFixed(2)}
            </span>
            {product.compare_at_price && (
              <span className="text-sm text-muted-foreground line-through">
                A${product.compare_at_price.toFixed(2)}
              </span>
            )}
          </div>
          {product.stock_quantity > 0 && product.stock_quantity <= 10 && (
            <p className="text-xs text-warning mt-2">
              Only {product.stock_quantity} left in stock
            </p>
          )}
          {/* Always-visible mobile CTAs (no hover on touch) - stacked to avoid overflow on narrow cards */}
          <div className="mt-3 flex flex-col gap-2 sm:hidden">
            <Button
              size="sm"
              onClick={handleBuyNow}
              disabled={product.stock_quantity <= 0}
              aria-label={`Buy ${product.name} now`}
              className="w-full px-2"
            >
              <Zap className="mr-1 h-4 w-4 shrink-0" aria-hidden />
              <span className="truncate">Buy Now</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleAddToCart}
              disabled={product.stock_quantity <= 0}
              aria-label={`Add ${product.name} to cart`}
              className="w-full px-2"
            >
              <ShoppingCart className="mr-1 h-4 w-4 shrink-0" aria-hidden />
              <span className="truncate">Add to Cart</span>
            </Button>
          </div>
          {/* Desktop: Buy Now under the price (hover overlay still has Add to Cart) */}
          <Button
            size="sm"
            variant="outline"
            onClick={handleBuyNow}
            disabled={product.stock_quantity <= 0}
            className="mt-3 w-full hidden sm:inline-flex"
            aria-label={`Buy ${product.name} now`}
          >
            <Zap className="mr-1 h-4 w-4" aria-hidden />
            Buy Now
          </Button>
        </CardContent>
    </article>
  );
};
