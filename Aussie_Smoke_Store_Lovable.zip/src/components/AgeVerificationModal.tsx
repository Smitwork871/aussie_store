import React from 'react';
import { useAgeVerification } from '@/contexts/AgeVerificationContext';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';


export const AgeVerificationModal: React.FC = () => {
  const { showModal, verify, decline } = useAgeVerification();

  return (
    <AlertDialog open={showModal}>
      <AlertDialogContent className="age-panel">
        <div className="age-mast"><img src="/aussie-mark.png" width="48" height="48" alt="" className="brand-mark" /><span>Aussie Smoke Store</span></div>
        <AlertDialogHeader className="age-copy">
          <p className="store-kicker">Age verification</p>
          <AlertDialogTitle className="store-title">Are you 18 or older?</AlertDialogTitle>
          <AlertDialogDescription className="text-base">This store sells tobacco products. Please confirm your age to enter.</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="age-actions">
          <AlertDialogCancel onClick={decline}>I am under 18</AlertDialogCancel>
          <AlertDialogAction onClick={verify}>Yes, enter store</AlertDialogAction>
        </AlertDialogFooter>
        <p className="age-warning">Health warning · Smoking causes cancer.</p>
      </AlertDialogContent>
    </AlertDialog>
  );
};
