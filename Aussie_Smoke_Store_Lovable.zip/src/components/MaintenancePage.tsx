import React from 'react';
import { AlertTriangle } from 'lucide-react';

const MaintenancePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6 py-12">
      <div className="max-w-2xl w-full text-center space-y-8">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/15 text-primary">
          <AlertTriangle className="h-8 w-8" aria-hidden="true" />
        </div>
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">
            Important Notice
          </h1>
          <p className="text-base md:text-lg leading-relaxed text-muted-foreground">
            Due to an ongoing server disruption, we are temporarily suspending the acceptance
            of new orders until Monday. Customers who have completed payment via direct bank
            transfer may be assured that their orders remain secure and will be dispatched
            promptly. We appreciate your understanding and patience during this time.
          </p>
        </div>
        <div className="pt-4 text-xs text-muted-foreground/70">
          — The Aussie Smoke Store Team
        </div>
      </div>
    </div>
  );
};

export default MaintenancePage;
