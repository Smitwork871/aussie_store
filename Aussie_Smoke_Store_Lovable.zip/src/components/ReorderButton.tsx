import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { RotateCcw, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { OrderItem } from '@/types/database';

interface ReorderButtonProps {
  items: Pick<OrderItem, 'product_id' | 'quantity'>[];
  className?: string;
  variant?: 'default' | 'outline' | 'secondary';
}

/**
 * One-click reorder: adds every product from a past order back to the cart
 * and routes the user to /cart. Skips silently if a product is no longer active.
 */
export const ReorderButton: React.FC<ReorderButtonProps> = ({ items, className, variant = 'default' }) => {
  const { addToCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handle = async () => {
    if (!items?.length) {
      toast.error('Nothing to reorder');
      return;
    }
    setLoading(true);
    let added = 0;
    for (const it of items) {
      if (!it.product_id) continue;
      try {
        await addToCart(it.product_id, it.quantity || 1);
        added++;
      } catch {
        // product may be inactive — skip
      }
    }
    setLoading(false);
    if (added > 0) {
      toast.success(`Added ${added} item${added === 1 ? '' : 's'} to your cart`);
      navigate('/cart');
    } else {
      toast.error('These products are no longer available');
    }
  };

  return (
    <Button onClick={handle} disabled={loading} variant={variant} className={className}>
      {loading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Adding…
        </>
      ) : (
        <>
          <RotateCcw className="mr-2 h-4 w-4" /> Reorder
        </>
      )}
    </Button>
  );
};
