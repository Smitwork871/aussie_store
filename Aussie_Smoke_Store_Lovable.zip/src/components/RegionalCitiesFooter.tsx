import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

interface CityLink { slug: string; name: string; state: string; }

export default function RegionalCitiesFooter() {
  const [cities, setCities] = useState<CityLink[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    supabase.from("seo_cities")
      .select("slug, name, state")
      .eq("is_active", true)
      .order("state").order("name")
      .then(({ data }) => setCities(data ?? []));
  }, []);

  if (cities.length === 0) return null;
  const byState = cities.reduce<Record<string, CityLink[]>>((acc, c) => {
    (acc[c.state] ??= []).push(c); return acc;
  }, {});

  return (
    <section className="border-t border-border bg-card/30">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <button onClick={() => setOpen(o => !o)} className="text-sm font-semibold text-foreground/80 hover:text-foreground">
          {open ? "−" : "+"} Also delivering to {cities.length}+ regional towns across Australia
        </button>
        {open && (
          <div className="mt-4 grid sm:grid-cols-2 md:grid-cols-4 gap-6 text-sm">
            {Object.entries(byState).map(([state, list]) => (
              <div key={state}>
                <div className="font-semibold mb-2">{state}</div>
                <ul className="space-y-1">
                  {list.map(c => (
                    <li key={c.slug}>
                      <Link to={`/locations/${c.slug}`} className="text-muted-foreground hover:text-foreground">
                        {c.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
