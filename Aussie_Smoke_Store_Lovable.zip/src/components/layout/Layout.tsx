import React from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { AgeVerificationModal } from '@/components/AgeVerificationModal';
import RegionalCitiesFooter from '@/components/RegionalCitiesFooter';

interface LayoutProps {
  children: React.ReactNode;
  showFooter?: boolean;
}

export const Layout: React.FC<LayoutProps> = ({ children, showFooter = true }) => {
  return (
    <div className="flex min-h-screen flex-col">
      <AgeVerificationModal />
      <Header />
      <main className="flex-1">{children}</main>
      {showFooter && <RegionalCitiesFooter />}
      {showFooter && <Footer />}
    </div>
  );
};
