import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';


export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsSubscribing(true);
    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .insert({ email: email.trim(), is_active: true });

      if (error) {
        if (error.code === '23505') {
          toast.info('You are already subscribed!');
        } else {
          throw error;
        }
      } else {
        toast.success('Successfully subscribed to our newsletter!');
        setEmail('');
      }
    } catch (error) {
      toast.error('Failed to subscribe. Please try again.');
    } finally {
      setIsSubscribing(false);
    }
  };

  return (
    <footer className="border-t bg-secondary/30">
      <div className="container py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-6">
          {/* Brand & Newsletter */}
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <img src="/favicon-small.png" alt="Aussie Smoke Store" width={32} height={32} className="h-8 w-8 rounded-lg" />
              <span className="font-bold text-xl">Aussie Smoke Store</span>
            </Link>
            <p className="text-muted-foreground mb-6 max-w-md">
              Premium tobacco products delivered to your doorstep. Quality and satisfaction guaranteed.
            </p>
            
            {/* Newsletter */}
            <div className="max-w-sm">
              <h4 className="font-semibold mb-2">Subscribe to our newsletter</h4>
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <Input
                  type="email"
                  aria-label="Newsletter email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1"
                  required
                />
                <Button type="submit" disabled={isSubscribing}>
                  {isSubscribing ? 'Subscribing...' : 'Subscribe'}
                </Button>
              </form>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/products" className="text-muted-foreground hover:text-foreground transition-colors">
                  All Products
                </Link>
              </li>
              <li>
                <Link to="/categories" className="text-muted-foreground hover:text-foreground transition-colors">
                  Categories
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/deals" className="text-muted-foreground hover:text-foreground transition-colors">
                  Today's Deals
                </Link>
              </li>
            </ul>
            <h4 className="font-semibold mb-4 mt-6">Compare</h4>
            <ul className="space-y-2">
              <li><Link to="/alternatives/supercheapsmoke" className="text-muted-foreground hover:text-foreground transition-colors">vs Supercheapsmoke</Link></li>
              <li><Link to="/alternatives/aussiesmokes" className="text-muted-foreground hover:text-foreground transition-colors">vs Aussiesmokes</Link></li>
              <li><Link to="/alternatives/smokersconnect" className="text-muted-foreground hover:text-foreground transition-colors">vs Smokers Connect</Link></li>
              <li><Link to="/alternatives/cheapcigarettes" className="text-muted-foreground hover:text-foreground transition-colors">vs Cheap Cigarettes</Link></li>
            </ul>
          </div>

          {/* Popular Searches */}
          <div>
            <h4 className="font-semibold mb-4">Popular Searches</h4>
            <ul className="space-y-2">
              <li><Link to="/cheap-smokes-online" className="text-muted-foreground hover:text-foreground transition-colors">Cheap Smokes Online</Link></li>
              <li><Link to="/cheap-cigarettes-online" className="text-muted-foreground hover:text-foreground transition-colors">Cheap Cigarettes Online</Link></li>
              <li><Link to="/cheap-vapes-online" className="text-muted-foreground hover:text-foreground transition-colors">Cheap Vapes Online</Link></li>
              <li><Link to="/buy-cigarettes-online-australia" className="text-muted-foreground hover:text-foreground transition-colors">Buy Cigarettes Online Australia</Link></li>
              <li><Link to="/cheapest-cigarettes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Cheapest Cigarettes Australia</Link></li>
              <li><Link to="/cheap-darts-online" className="text-muted-foreground hover:text-foreground transition-colors">Cheap Darts Online</Link></li>
              <li><Link to="/cheap-durries-online" className="text-muted-foreground hover:text-foreground transition-colors">Cheap Durries Online</Link></li>
              <li><Link to="/cheap-tobacco-online" className="text-muted-foreground hover:text-foreground transition-colors">Cheap Tobacco Online</Link></li>
              <li><Link to="/cheap-rolling-tobacco-online" className="text-muted-foreground hover:text-foreground transition-colors">Cheap Rolling Tobacco</Link></li>
              <li><Link to="/online-smoke-shop-australia" className="text-muted-foreground hover:text-foreground transition-colors">Online Smoke Shop</Link></li>
              <li><Link to="/bulk-cigarettes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Bulk Cigarettes Australia</Link></li>
              <li><Link to="/order-cigarettes-online-australia" className="text-muted-foreground hover:text-foreground transition-colors">Order Cigarettes Online</Link></li>
              <li><Link to="/discount-tobacco-online" className="text-muted-foreground hover:text-foreground transition-colors">Discount Tobacco Online</Link></li>
              <li><Link to="/duty-free-cigarettes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Duty Free Cigarettes</Link></li>
              <li><Link to="/cigarettes-near-me" className="text-muted-foreground hover:text-foreground transition-colors">Cigarettes Near Me</Link></li>
            </ul>
          </div>

          {/* Shop by State */}
          <div>
            <h4 className="font-semibold mb-4">Shop by State</h4>
            <ul className="space-y-2">
              <li><Link to="/cheap-smokes-nsw" className="text-muted-foreground hover:text-foreground transition-colors">New South Wales</Link></li>
              <li><Link to="/cheap-smokes-vic" className="text-muted-foreground hover:text-foreground transition-colors">Victoria</Link></li>
              <li><Link to="/cheap-smokes-qld" className="text-muted-foreground hover:text-foreground transition-colors">Queensland</Link></li>
              <li><Link to="/cheap-smokes-wa" className="text-muted-foreground hover:text-foreground transition-colors">Western Australia</Link></li>
              <li><Link to="/cheap-smokes-sa" className="text-muted-foreground hover:text-foreground transition-colors">South Australia</Link></li>
            </ul>
            <h4 className="font-semibold mb-4 mt-6">Shop by City</h4>
            <ul className="space-y-2">
              <li><Link to="/cheap-smokes-sydney" className="text-muted-foreground hover:text-foreground transition-colors">Sydney</Link></li>
              <li><Link to="/cheap-smokes-melbourne" className="text-muted-foreground hover:text-foreground transition-colors">Melbourne</Link></li>
              <li><Link to="/cheap-smokes-brisbane" className="text-muted-foreground hover:text-foreground transition-colors">Brisbane</Link></li>
              <li><Link to="/cheap-smokes-perth" className="text-muted-foreground hover:text-foreground transition-colors">Perth</Link></li>
              <li><Link to="/cheap-smokes-adelaide" className="text-muted-foreground hover:text-foreground transition-colors">Adelaide</Link></li>
              <li><Link to="/cheap-smokes-canberra" className="text-muted-foreground hover:text-foreground transition-colors">Canberra</Link></li>
              <li><Link to="/cheap-smokes-gold-coast" className="text-muted-foreground hover:text-foreground transition-colors">Gold Coast</Link></li>
              <li><Link to="/cheap-smokes-hobart" className="text-muted-foreground hover:text-foreground transition-colors">Hobart</Link></li>
              <li><Link to="/cheap-smokes-darwin" className="text-muted-foreground hover:text-foreground transition-colors">Darwin</Link></li>
              <li><Link to="/cheap-smokes-newcastle" className="text-muted-foreground hover:text-foreground transition-colors">Newcastle</Link></li>
            </ul>
          </div>

          {/* Shop by Brand & Legal */}
          <div>
            <h4 className="font-semibold mb-4">Shop by Brand</h4>
            <ul className="space-y-2">
              <li><Link to="/marlboro-cigarettes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Marlboro</Link></li>
              <li><Link to="/manchester-cigarettes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Manchester</Link></li>
              <li><Link to="/benson-hedges-cigarettes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Benson &amp; Hedges</Link></li>
              <li><Link to="/double-happiness-cigarettes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Double Happiness</Link></li>
              <li><Link to="/uwell-vapes-australia" className="text-muted-foreground hover:text-foreground transition-colors">UWELL Vapes</Link></li>
              <li><Link to="/alibarbar-vapes-australia" className="text-muted-foreground hover:text-foreground transition-colors">Alibarbar Vapes</Link></li>
            </ul>
            <h4 className="font-semibold mb-4 mt-6">Legal</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} Aussie Smoke Store. All rights reserved.</p>
            <div className="flex gap-4">
              <Link to="/privacy" className="hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="hover:text-foreground transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-4">
            ⚠️ Statutory Warning: Cigarette smoking is injurious to health. Tobacco causes cancer.
          </p>
        </div>
      </div>
    </footer>
  );
};
