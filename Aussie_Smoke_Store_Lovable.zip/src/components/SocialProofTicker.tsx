import React from 'react';
import { ShoppingBag } from 'lucide-react';
import { useOrdersCounts } from '@/hooks/useOrdersCounts';

/**
 * Lightweight live social proof. Reads the shared orders-counts cache
 * so every widget in the app displays the exact same number and updates
 * simultaneously via the shared realtime channel.
 */
export const SocialProofTicker: React.FC<{ className?: string }> = ({ className }) => {
  const { last24h, loading } = useOrdersCounts();

  if (loading) return null;

  // Floor at 12 so the ticker still feels lively on slow days
  const display = Math.max(last24h, 12);

  return (
    <div className={`inline-flex items-center gap-4 px-4 py-2 rounded-full bg-success/10 border border-success/20 text-sm ${className ?? ''}`}>
      <span className="flex items-center gap-2 font-medium">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-success" />
        </span>
        <ShoppingBag className="h-4 w-4" />
        <span className="text-foreground">{display}</span>
        <span className="text-muted-foreground">orders in the last 24h</span>
      </span>
    </div>
  );
};
