import React from 'react';
import { Lock, Truck, Package, MapPin } from 'lucide-react';

interface TrustStripProps {
  variant?: 'full' | 'compact';
  className?: string;
}

const items = [
  { icon: MapPin, label: 'AU-based', sub: 'Local team' },
  { icon: Truck, label: '48h dispatch', sub: 'From Australia' },
  { icon: Package, label: 'Discreet packaging', sub: 'Plain box' },
  { icon: Lock, label: 'Bank-grade encrypted', sub: 'Secure checkout' },
];

export const TrustStrip: React.FC<TrustStripProps> = ({ variant = 'full', className = '' }) => {
  if (variant === 'compact') {
    return (
      <div className={`flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground ${className}`}>
        {items.map(({ icon: Icon, label }) => (
          <span key={label} className="inline-flex items-center gap-1.5">
            <Icon className="h-3.5 w-3.5 text-primary" aria-hidden />
            {label}
          </span>
        ))}
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-2 sm:grid-cols-4 gap-3 ${className}`}>
      {items.map(({ icon: Icon, label, sub }) => (
        <div
          key={label}
          className="flex items-center gap-2.5 rounded-lg border bg-card/50 px-3 py-2.5"
        >
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Icon className="h-4 w-4" aria-hidden />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold leading-tight">{label}</p>
            <p className="text-[11px] text-muted-foreground leading-tight">{sub}</p>
          </div>
        </div>
      ))}
    </div>
  );
};
