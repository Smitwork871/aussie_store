import { useEffect } from 'react';

const SITE_NAME = 'Aussie Smoke Store';
const DEFAULT_DESCRIPTION = 'Buy cheap cigarettes, tobacco, vapes & accessories online in Australia. Free shipping over A$50. Shop at Aussie Smoke Store.';
const SITE_URL = 'https://cheapsmokescentral.com';
const DEFAULT_OG_IMAGE = `${SITE_URL}/og-image.jpg`;

interface SEOHeadProps {
  title: string;
  description?: string;
  canonical?: string;
  ogType?: 'website' | 'product' | 'article';
  ogImage?: string;
  noindex?: boolean;
  keywords?: string;
  jsonLd?: Record<string, unknown> | Record<string, unknown>[];
}

export const SEOHead = ({
  title,
  description = DEFAULT_DESCRIPTION,
  canonical,
  ogType = 'website',
  ogImage,
  noindex = false,
  keywords,
  jsonLd,
}: SEOHeadProps) => {
  // Default to branded OG image (absolute URL required for social crawlers)
  const resolvedOgImage = ogImage
    ? (ogImage.startsWith('http') ? ogImage : `${SITE_URL}${ogImage.startsWith('/') ? '' : '/'}${ogImage}`)
    : DEFAULT_OG_IMAGE;
  // Append the brand suffix only when it keeps the final title under ~60 chars (Google SERP cap).
  const SUFFIX = ` | ${SITE_NAME}`;
  const fullTitle = title === SITE_NAME || title.includes(SITE_NAME) || (title.length + SUFFIX.length) > 60
    ? title
    : `${title}${SUFFIX}`;
  const canonicalUrl = canonical ? `${SITE_URL}${canonical}` : undefined;

  useEffect(() => {
    document.title = fullTitle;

    const setMeta = (attr: string, key: string, content: string) => {
      let el = document.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, key);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    setMeta('name', 'description', description);
    if (keywords) {
      setMeta('name', 'keywords', keywords);
    }
    if (noindex) {
      setMeta('name', 'robots', 'noindex, nofollow');
    } else {
      setMeta('name', 'robots', 'index, follow, max-image-preview:large, max-snippet:-1');
    }

    // Open Graph
    setMeta('property', 'og:title', fullTitle);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:type', ogType);
    setMeta('property', 'og:site_name', SITE_NAME);
    setMeta('property', 'og:locale', 'en_AU');
    if (canonicalUrl) setMeta('property', 'og:url', canonicalUrl);
    setMeta('property', 'og:image', resolvedOgImage);
    setMeta('property', 'og:image:width', '1216');
    setMeta('property', 'og:image:height', '640');
    setMeta('property', 'og:image:alt', `${SITE_NAME} — ${title}`);

    // Twitter
    setMeta('name', 'twitter:card', 'summary_large_image');
    setMeta('name', 'twitter:title', fullTitle);
    setMeta('name', 'twitter:description', description);
    setMeta('name', 'twitter:image', resolvedOgImage);
    setMeta('name', 'twitter:image:alt', `${SITE_NAME} — ${title}`);

    // Canonical link
    let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (canonicalUrl) {
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      link.setAttribute('href', canonicalUrl);
    } else if (link) {
      link.remove();
    }

    // JSON-LD structured data
    const existingScripts = document.querySelectorAll('script[data-seo-jsonld]');
    existingScripts.forEach((s) => s.remove());

    if (jsonLd) {
      const items = Array.isArray(jsonLd) ? jsonLd : [jsonLd];
      items.forEach((item) => {
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.setAttribute('data-seo-jsonld', 'true');
        script.textContent = JSON.stringify(item);
        document.head.appendChild(script);
      });
    }

    return () => {
      document.querySelectorAll('script[data-seo-jsonld]').forEach((s) => s.remove());
    };
  }, [fullTitle, description, canonicalUrl, ogType, resolvedOgImage, noindex, keywords, jsonLd, title]);

  return null;
};

// Reusable JSON-LD generators
export const organizationJsonLd = () => ({
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: SITE_NAME,
  url: SITE_URL,
  logo: `${SITE_URL}/favicon.png`,
  description: 'Buy cheap smokes and cigarettes online in Australia. Premium tobacco products at the best prices with free shipping over A$50.',
  contactPoint: {
    '@type': 'ContactPoint',
    contactType: 'customer service',
    availableLanguage: 'English',
  },
});

export const websiteJsonLd = () => ({
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: SITE_NAME,
  url: SITE_URL,
  potentialAction: {
    '@type': 'SearchAction',
    target: `${SITE_URL}/products?search={search_term_string}`,
    'query-input': 'required name=search_term_string',
  },
});

export const localBusinessJsonLd = () => ({
  '@context': 'https://schema.org',
  '@type': 'Store',
  name: SITE_NAME,
  url: SITE_URL,
  logo: `${SITE_URL}/favicon.png`,
  description: 'Buy cheap smokes online Australia. Cheap cigarettes, rolling tobacco, vapes and accessories delivered Australia-wide.',
  address: {
    '@type': 'PostalAddress',
    addressCountry: 'AU',
    addressRegion: 'NSW',
    addressLocality: 'Sydney',
  },
  geo: {
    '@type': 'GeoCoordinates',
    latitude: '-25.2744',
    longitude: '133.7751',
  },
  areaServed: {
    '@type': 'Country',
    name: 'Australia',
  },
  priceRange: '$$',
  openingHoursSpecification: {
    '@type': 'OpeningHoursSpecification',
    dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    opens: '00:00',
    closes: '23:59',
  },
});

export const faqJsonLd = (faqs: { question: string; answer: string }[]) => ({
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.map((faq) => ({
    '@type': 'Question',
    name: faq.question,
    acceptedAnswer: {
      '@type': 'Answer',
      text: faq.answer,
    },
  })),
});

export const itemListJsonLd = (items: { name: string; url: string; image?: string; position: number }[]) => ({
  '@context': 'https://schema.org',
  '@type': 'ItemList',
  itemListElement: items.map((item) => ({
    '@type': 'ListItem',
    position: item.position,
    name: item.name,
    url: `${SITE_URL}${item.url}`,
    ...(item.image ? { image: item.image } : {}),
  })),
});

export const productJsonLd = (product: {
  name: string;
  description?: string;
  price: number;
  images?: string[];
  sku?: string;
  brand?: string;
  slug: string;
  stock_quantity: number;
  compare_at_price?: number | null;
  avgRating?: number;
  reviewCount?: number;
}) => {
  const schema: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    description: product.description || product.name,
    image: product.images?.[0],
    sku: product.sku || product.slug,
    brand: product.brand ? { '@type': 'Brand', name: product.brand } : undefined,
    ...(product.reviewCount && product.reviewCount > 0
      ? {
          aggregateRating: {
            '@type': 'AggregateRating',
            ratingValue: product.avgRating?.toFixed(1) || '4.5',
            reviewCount: product.reviewCount,
            bestRating: '5',
            worstRating: '1',
          },
        }
      : {}),
    offers: {
      '@type': 'Offer',
      url: `${SITE_URL}/products/${product.slug}`,
      priceCurrency: 'AUD',
      price: product.price.toFixed(2),
      availability:
        product.stock_quantity > 0
          ? 'https://schema.org/InStock'
          : 'https://schema.org/OutOfStock',
      seller: { '@type': 'Organization', name: SITE_NAME },
      shippingDetails: [
        {
          '@type': 'OfferShippingDetails',
          name: 'Free shipping on orders over A$50',
          shippingRate: { '@type': 'MonetaryAmount', value: '0.00', currency: 'AUD' },
          shippingDestination: { '@type': 'DefinedRegion', addressCountry: 'AU' },
          freeShippingThreshold: {
            '@type': 'DeliveryChargeSpecification',
            eligibleTransactionVolume: {
              '@type': 'PriceSpecification',
              minPrice: '50.00',
              priceCurrency: 'AUD',
            },
          },
          deliveryTime: {
            '@type': 'ShippingDeliveryTime',
            handlingTime: { '@type': 'QuantitativeValue', minValue: 1, maxValue: 3, unitCode: 'DAY' },
            transitTime: { '@type': 'QuantitativeValue', minValue: 3, maxValue: 7, unitCode: 'DAY' },
          },
        },
        {
          '@type': 'OfferShippingDetails',
          name: 'Standard shipping (orders under A$50)',
          shippingRate: { '@type': 'MonetaryAmount', value: '10.00', currency: 'AUD' },
          shippingDestination: { '@type': 'DefinedRegion', addressCountry: 'AU' },
          deliveryTime: {
            '@type': 'ShippingDeliveryTime',
            handlingTime: { '@type': 'QuantitativeValue', minValue: 1, maxValue: 3, unitCode: 'DAY' },
            transitTime: { '@type': 'QuantitativeValue', minValue: 3, maxValue: 7, unitCode: 'DAY' },
          },
        },
      ],
    },
  };
  return schema;
};

export const breadcrumbJsonLd = (items: { name: string; url: string }[]) => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: items.map((item, i) => ({
    '@type': 'ListItem',
    position: i + 1,
    name: item.name,
    item: `${SITE_URL}${item.url}`,
  })),
});

export const articleJsonLd = (article: {
  headline: string;
  description?: string;
  url: string;
  datePublished?: string;
  dateModified?: string;
  image?: string;
  author?: string;
}) => ({
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: article.headline,
  description: article.description,
  mainEntityOfPage: { '@type': 'WebPage', '@id': `${SITE_URL}${article.url}` },
  datePublished: article.datePublished || '2026-01-01',
  dateModified: article.dateModified || new Date().toISOString().slice(0, 10),
  image: article.image || DEFAULT_OG_IMAGE,
  author: { '@type': 'Organization', name: article.author || SITE_NAME },
  publisher: {
    '@type': 'Organization',
    name: SITE_NAME,
    logo: { '@type': 'ImageObject', url: `${SITE_URL}/favicon.png` },
  },
});
