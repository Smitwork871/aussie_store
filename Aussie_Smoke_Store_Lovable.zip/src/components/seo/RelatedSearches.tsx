import { Link } from 'react-router-dom';

interface RelatedSearchesProps {
  title?: string;
  links: { label: string; to: string }[];
}

/**
 * Internal-link block that surfaces related SEO landing pages with
 * exact-match anchor text. Drop into the bottom of any SEO page to
 * strengthen the internal link graph.
 */
export const RelatedSearches = ({ title = 'Related Searches', links }: RelatedSearchesProps) => (
  <section className="py-10 md:py-12 bg-secondary/20 border-y">
    <div className="container">
      <h2 className="text-xl md:text-2xl font-bold mb-5 text-center">{title}</h2>
      <div className="flex flex-wrap gap-2 justify-center max-w-4xl mx-auto">
        {links.map((l) => (
          <Link
            key={l.to}
            to={l.to}
            className="px-4 py-2 rounded-full bg-background border text-sm hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors"
          >
            {l.label}
          </Link>
        ))}
      </div>
    </div>
  </section>
);
