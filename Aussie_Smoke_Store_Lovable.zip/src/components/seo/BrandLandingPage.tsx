import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types/database';
import { ArrowRight, Truck, Shield, Package } from 'lucide-react';
import { SEOHead, breadcrumbJsonLd, faqJsonLd, localBusinessJsonLd } from '@/components/SEOHead';
import { RelatedSearches } from '@/components/seo/RelatedSearches';

export interface BrandLandingConfig {
  /** URL path, e.g. "/marlboro-ice-blast-australia" */
  path: string;
  /** SEO <title> */
  metaTitle: string;
  /** Meta description */
  metaDescription: string;
  /** Comma-separated keywords */
  metaKeywords: string;
  /** Breadcrumb label for this page */
  breadcrumbName: string;
  /** Hero <h1> first line */
  h1Line1: string;
  /** Hero <h1> highlighted second line */
  h1Line2: string;
  /** Hero paragraph (supports HTML) */
  heroParagraph: string;
  /** Primary subject (e.g. "Marlboro Ice Blast") used in content body */
  subject: string;
  /** Long-form body paragraphs (HTML) */
  bodyHtml: string;
  /** ilike pattern to filter products by brand or name, e.g. "%Marlboro%" */
  productFilter: { column: 'brand' | 'name'; pattern: string };
  /** FAQ entries */
  faqs: { question: string; answer: string }[];
}

/**
 * Reusable, SEO-optimised brand/product landing page.
 * Used by the 10 competitor-targeting brand routes built to capture
 * traffic from supercheapsmoke.com.au, aussiesmokes.com, etc.
 */
export const BrandLandingPage = ({ config }: { config: BrandLandingConfig }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const fetchProducts = async () => {
      const { data } = await supabase
        .from('public_products')
        .select('*')
        .eq('is_active', true)
        .ilike(config.productFilter.column, config.productFilter.pattern)
        .order('is_featured', { ascending: false })
        .limit(12);

      if (cancelled) return;

      if (data && data.length > 0) {
        setProducts(data as Product[]);
      } else {
        const { data: fallback } = await supabase
          .from('public_products')
          .select('*')
          .eq('is_active', true)
          .order('is_featured', { ascending: false })
          .limit(8);
        if (!cancelled && fallback) setProducts(fallback as Product[]);
      }
      if (!cancelled) setIsLoading(false);
    };
    fetchProducts();
    return () => {
      cancelled = true;
    };
  }, [config.productFilter.column, config.productFilter.pattern]);

  return (
    <Layout>
      <SEOHead
        title={config.metaTitle}
        description={config.metaDescription}
        canonical={config.path}
        keywords={config.metaKeywords}
        jsonLd={[
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: 'Home', url: '/' },
            { name: config.breadcrumbName, url: config.path },
          ]),
          faqJsonLd(config.faqs),
        ]}
      />

      {/* Hero */}
      <section className="bg-gradient-to-br from-secondary via-background to-accent/20 py-14 md:py-20">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-5">
              {config.h1Line1}
              <span className="text-primary block mt-2">{config.h1Line2}</span>
            </h1>
            <p
              className="text-base md:text-lg text-muted-foreground mb-7"
              dangerouslySetInnerHTML={{ __html: config.heroParagraph }}
            />
            <div className="flex flex-wrap gap-3 justify-center">
              <Button size="lg" asChild>
                <Link to="/products">
                  Shop Now <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/deals">View Deals</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="py-6 bg-background border-y">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="flex items-center justify-center gap-2 text-sm">
              <Truck className="h-5 w-5 text-primary" /> Free shipping over A$50
            </div>
            <div className="flex items-center justify-center gap-2 text-sm">
              <Package className="h-5 w-5 text-primary" /> 48h dispatch from AU stock
            </div>
            <div className="flex items-center justify-center gap-2 text-sm">
              <Shield className="h-5 w-5 text-primary" /> Discreet, tracked delivery
            </div>
          </div>
        </div>
      </section>

      {/* Long-form content */}
      <section className="py-10 md:py-14">
        <div className="container">
          <div
            className="max-w-3xl mx-auto prose prose-neutral dark:prose-invert"
            dangerouslySetInnerHTML={{ __html: config.bodyHtml }}
          />
        </div>
      </section>

      {/* Products */}
      <section className="py-10 bg-secondary/30">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-6">{config.subject} — In Stock</h2>
          <ProductGrid products={products} isLoading={isLoading} />
          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link to="/products">
                Browse All Products <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-10 md:py-14">
        <div className="container max-w-3xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center">{config.subject} FAQ</h2>
          <div className="space-y-4">
            {config.faqs.map((faq, i) => (
              <div key={i} className="border rounded-lg p-5">
                <h3 className="font-semibold text-base md:text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground text-sm md:text-base">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Related searches */}
      <RelatedSearches
        title="Related Brands & Searches"
        links={[
          { label: 'Marlboro Cigarettes Australia', to: '/marlboro-cigarettes-australia' },
          { label: 'Manchester Cigarettes', to: '/manchester-cigarettes-australia' },
          { label: 'Benson & Hedges Australia', to: '/benson-hedges-cigarettes-australia' },
          { label: 'Double Happiness', to: '/double-happiness-cigarettes-australia' },
          { label: 'Cheap Cigarettes Online', to: '/cheap-cigarettes-online' },
          { label: 'Cheap Smokes Online', to: '/cheap-smokes-online' },
          { label: 'Cheap Tobacco', to: '/cheap-tobacco-online' },
          { label: 'Best Cigarettes Australia', to: '/best-cigarettes-australia' },
          { label: 'Cheapest Cigarettes', to: '/cheapest-cigarettes-australia' },
          { label: 'Bulk Cigarettes', to: '/bulk-cigarettes-australia' },
        ]}
      />
    </Layout>
  );
};
