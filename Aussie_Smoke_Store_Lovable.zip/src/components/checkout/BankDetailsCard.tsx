import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, Check } from 'lucide-react';

const baseBankDetails = [
  { label: 'Account Name', value: 'K P TRADERS' },
  { label: 'BSB Code', value: '067-873' },
  { label: 'Account Number', value: '2544 7750' },
];

interface BankDetailsCardProps {
  orderNumber?: string;
  amount?: number;
}

const BankDetailsCard: React.FC<BankDetailsCardProps> = ({ orderNumber, amount }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const details = [
    ...baseBankDetails,
    ...(typeof amount === 'number'
      ? [{ label: 'Amount', value: `A$${amount.toFixed(2)}` }]
      : []),
    ...(orderNumber
      ? [{ label: 'Reference Code', value: orderNumber }]
      : []),
  ];

  const copyToClipboard = async (value: string, index: number) => {
    await navigator.clipboard.writeText(value);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <Card className="border-primary/30 bg-primary/5">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Bank Transfer Details</CardTitle>
        <p className="text-sm text-muted-foreground">
          Please make a payment to the following bank account to complete your order.
        </p>
        <div className="mt-2 p-3 bg-destructive/10 border border-destructive/30 rounded-lg">
          <p className="text-sm font-semibold text-destructive">
            {orderNumber ? (
              <>
                ⚠️ IMPORTANT: Please add your unique reference number{' '}
                <span className="font-mono font-bold">{orderNumber}</span> in the bank transfer description so we can match your payment to this order.
              </>
            ) : (
              <>
                ⚠️ IMPORTANT: Use your <span className="font-bold">order reference code</span> as the bank transfer description so we can identify your payment quickly.
              </>
            )}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Transfer the exact order total. Orders unpaid after 48 hours are automatically cancelled.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {details.map((item, i) => (
            <div key={i} className="flex items-center justify-between p-2.5 bg-background rounded-lg border">
              <div>
                <p className="text-xs text-muted-foreground">{item.label}</p>
                <p className="text-sm font-medium font-mono">{item.value}</p>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => copyToClipboard(item.value, i)}
              >
                {copiedIndex === i ? <Check className="h-3.5 w-3.5 text-primary" /> : <Copy className="h-3.5 w-3.5" />}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default BankDetailsCard;
