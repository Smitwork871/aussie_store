import React from 'react';
import { Truck, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Props {
  className?: string;
  variant?: 'hero' | 'compact';
}

export const FreeShippingBanner: React.FC<Props> = ({ className, variant = 'hero' }) => {
  if (variant === 'compact') {
    return (
      <div
        className={cn(
          'relative overflow-hidden rounded-xl border border-primary/30 bg-gradient-to-r from-primary/15 via-primary/10 to-accent/20 px-4 py-3 flex items-center gap-3',
          className
        )}
      >
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
          <Truck className="h-4.5 w-4.5" />
        </div>
        <div className="text-sm">
          <p className="font-semibold leading-tight">
            🚚 Free Shipping on orders over <span className="text-primary">A$50</span>
          </p>
          <p className="text-xs text-muted-foreground">Australia-wide · Fast &amp; discreet delivery</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-2xl border-2 border-primary/60 bg-gradient-to-r from-primary via-primary/90 to-accent text-primary-foreground shadow-xl shadow-primary/20',
        className
      )}
      role="region"
      aria-label="Free shipping offer"
    >

      <div className="relative flex flex-col md:flex-row items-center justify-between gap-4 px-6 py-5 md:px-8 md:py-6">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm ring-1 ring-white/30">
            <Truck className="h-7 w-7" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest opacity-90">
              <Sparkles className="h-3.5 w-3.5" />
              Limited time offer
            </div>
            <h2 className="text-xl md:text-2xl font-bold leading-tight">
              FREE Shipping on orders over <span className="underline decoration-white/60 underline-offset-4">A$50</span>
            </h2>
            <p className="text-sm md:text-base opacity-90">
              Fast, discreet delivery Australia-wide. No code needed — auto-applied at checkout.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2.5 rounded-full bg-white px-5 py-3 text-base md:text-sm font-bold text-primary shadow-lg shadow-black/10 whitespace-nowrap">
          <span className="text-lg md:text-base shrink-0">🇦🇺</span>
          <span className="leading-snug">Australia-wide · <span className="underline decoration-primary/30 underline-offset-2">48h dispatch</span></span>
        </div>
      </div>
    </div>
  );
};

export default FreeShippingBanner;
