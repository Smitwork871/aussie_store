import { useRef, useState } from "react";
import * as XLSX from "xlsx";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { logActivity } from "@/lib/activityLog";
import { Download, FileSpreadsheet, Loader2, Truck, Upload } from "lucide-react";

type OrderRow = {
  id: string;
  order_number: string;
  status: string;
};

type PreviewRow = {
  orderNumber: string;
  currentStatus: string;
  tracking: string[];
  action: "Will mark Shipped" | "Skipped — not in Processing" | "Not Found" | "Skipped — no tracking number";
  orderId?: string;
};

type ResultRow = {
  orderNumber: string;
  previousStatus: string;
  action: string;
  newStatus: string;
};

const TEMPLATE_HEADERS = [
  "Order Number",
  "Tracking Number 1",
  "Tracking Number 2",
  "Tracking Number 3",
];

const downloadTemplate = () => {
  const ws = XLSX.utils.aoa_to_sheet([
    TEMPLATE_HEADERS,
    ["ORD-XXXXXXXXXXXX", "TRACK1234567890", "", ""],
  ]);
  ws["!cols"] = [{ wch: 22 }, { wch: 22 }, { wch: 22 }, { wch: 22 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Shipping");
  XLSX.writeFile(wb, "bulk-shipping-tracking-template.xlsx");
};

const ShippingTrackingUploadTool = () => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [parsing, setParsing] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [preview, setPreview] = useState<PreviewRow[] | null>(null);
  const [results, setResults] = useState<ResultRow[] | null>(null);

  const reset = () => {
    setFileName(null);
    setPreview(null);
    setResults(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const handleFile = async (file: File) => {
    setParsing(true);
    setPreview(null);
    setResults(null);
    setFileName(file.name);
    try {
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      if (!sheet) throw new Error("The file has no readable sheet");
      const rows = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, blankrows: false });

      const dataRows = rows.filter((r, i) => {
        if (i === 0 && String(r?.[0] ?? "").toLowerCase().includes("order")) return false;
        return String(r?.[0] ?? "").trim().length > 0;
      });

      if (dataRows.length === 0) {
        toast.error("No order rows found in the file");
        return;
      }

      const parsed = dataRows.map((r) => ({
        orderNumber: String(r[0]).trim().toUpperCase(),
        tracking: r
          .slice(1)
          .map((v: any) => String(v ?? "").trim())
          .filter(Boolean),
      }));

      const numbers = Array.from(new Set(parsed.map((p) => p.orderNumber)));
      const { data, error } = await supabase
        .from("orders")
        .select("id, order_number, status")
        .in("order_number", numbers);
      if (error) throw error;

      const byNumber = new Map(
        ((data ?? []) as OrderRow[]).map((o) => [o.order_number.toUpperCase(), o])
      );

      const previewRows: PreviewRow[] = parsed.map((p) => {
        const order = byNumber.get(p.orderNumber);
        if (!order) {
          return { orderNumber: p.orderNumber, currentStatus: "—", tracking: p.tracking, action: "Not Found" };
        }
        if (p.tracking.length === 0) {
          return {
            orderNumber: order.order_number,
            currentStatus: order.status,
            tracking: [],
            action: "Skipped — no tracking number",
            orderId: order.id,
          };
        }
        if (order.status !== "processing") {
          return {
            orderNumber: order.order_number,
            currentStatus: order.status,
            tracking: p.tracking,
            action: "Skipped — not in Processing",
            orderId: order.id,
          };
        }
        return {
          orderNumber: order.order_number,
          currentStatus: order.status,
          tracking: p.tracking,
          action: "Will mark Shipped",
          orderId: order.id,
        };
      });

      setPreview(previewRows);
    } catch (error: any) {
      toast.error(`Could not read file: ${error.message}`);
      setFileName(null);
    } finally {
      setParsing(false);
    }
  };

  const confirmAndUpdate = async () => {
    if (!preview) return;
    setProcessing(true);
    try {
      const toShip = preview.filter((r) => r.action === "Will mark Shipped");
      const shipped: string[] = [];

      for (const row of toShip) {
        const { error } = await supabase
          .from("orders")
          .update({
            tracking_numbers: row.tracking,
            tracking_number: row.tracking[0],
            tracking_carrier: "AusPost",
            status: "shipped" as const,
            shipped_at: new Date().toISOString(),
          })
          .eq("id", row.orderId!);
        if (error) {
          toast.error(`${row.orderNumber}: ${error.message}`);
          continue;
        }
        shipped.push(row.orderNumber);
        supabase.functions
          .invoke("send-order-email", { body: { order_id: row.orderId, email_type: "shipped" } })
          .catch(() => undefined);
      }

      const shippedSet = new Set(shipped);
      const rows: ResultRow[] = preview.map((r) => {
        if (r.action === "Will mark Shipped" && shippedSet.has(r.orderNumber)) {
          return {
            orderNumber: r.orderNumber,
            previousStatus: "processing",
            action: `Marked Shipped (${r.tracking.length} tracking no.)`,
            newStatus: "shipped",
          };
        }
        if (r.action === "Will mark Shipped") {
          return {
            orderNumber: r.orderNumber,
            previousStatus: r.currentStatus,
            action: "Update failed",
            newStatus: r.currentStatus,
          };
        }
        return {
          orderNumber: r.orderNumber,
          previousStatus: r.currentStatus,
          action: r.action,
          newStatus: r.currentStatus,
        };
      });

      setResults(rows);
      setPreview(null);
      logActivity({
        actionType: "Bulk Shipping Upload",
        description:
          `Bulk shipping upload: ${shipped.length} order(s) marked Shipped with tracking` +
          (shipped.length > 0 ? ` — ${shipped.join(", ")}` : ""),
        metadata: { shipped, total: rows.length, file: fileName },
      });
      toast.success("Bulk shipping update completed");
    } catch (error: any) {
      toast.error(`Update failed: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const counts = (rows: { action: string }[]) => ({
    shipped: rows.filter((r) => r.action.startsWith("Marked Shipped") || r.action === "Will mark Shipped").length,
    notProcessing: rows.filter((r) => r.action === "Skipped — not in Processing").length,
    noTracking: rows.filter((r) => r.action === "Skipped — no tracking number").length,
    notFound: rows.filter((r) => r.action === "Not Found").length,
  });

  const badgeVariant = (action: string) =>
    action === "Not Found" || action === "Update failed"
      ? ("destructive" as const)
      : action.startsWith("Skipped")
      ? ("secondary" as const)
      : ("default" as const);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Upload shipping file
          </CardTitle>
          <CardDescription>
            Column A: Order Number · Columns B, C, D: Tracking Number 1–3 (extra columns are also
            read). Only orders in Processing are updated. Nothing is saved until you confirm.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleFile(file);
            }}
            className={`flex flex-col items-center justify-center gap-3 rounded-md border-2 border-dashed p-8 text-center transition-colors ${
              dragging ? "border-primary bg-primary/5" : "border-muted"
            }`}
          >
            <FileSpreadsheet className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              {fileName ? fileName : "Drag and drop an .xlsx file here, or"}
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              <Button onClick={() => inputRef.current?.click()} disabled={parsing || processing}>
                {parsing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Reading...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" /> Upload Excel File
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={downloadTemplate}>
                <Download className="mr-2 h-4 w-4" /> Download Template
              </Button>
              {(preview || results) && (
                <Button variant="ghost" onClick={reset} disabled={processing}>
                  Clear
                </Button>
              )}
            </div>
            <input
              ref={inputRef}
              type="file"
              accept=".xlsx,.xls"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFile(file);
              }}
            />
          </div>
          <p className="text-xs text-muted-foreground">
            If an order has more than three tracking numbers, add extra “Tracking Number 4, 5…”
            columns, or re-run the tool with a follow-up file for the leftovers.
          </p>
        </CardContent>
      </Card>

      {preview && (
        <Card>
          <CardHeader>
            <CardTitle>Preview</CardTitle>
            <CardDescription>
              {counts(preview).shipped} will be marked Shipped · {counts(preview).notProcessing}{" "}
              skipped (not in Processing) · {counts(preview).noTracking} skipped (no tracking) ·{" "}
              {counts(preview).notFound} not found
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order Number</TableHead>
                    <TableHead>Current Status</TableHead>
                    <TableHead>Tracking Number(s) Found</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {preview.map((r, i) => (
                    <TableRow key={`${r.orderNumber}-${i}`}>
                      <TableCell className="font-mono text-xs">{r.orderNumber}</TableCell>
                      <TableCell className="capitalize">{r.currentStatus}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {r.tracking.length ? r.tracking.join(", ") : "—"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={badgeVariant(r.action)}>{r.action}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <Button
              onClick={confirmAndUpdate}
              disabled={processing || counts(preview).shipped === 0}
            >
              {processing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Updating...
                </>
              ) : (
                "Confirm & Update"
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {results && (
        <Card>
          <CardHeader>
            <CardTitle>Results</CardTitle>
            <CardDescription>
              {counts(results).shipped} order{counts(results).shipped === 1 ? "" : "s"} marked
              Shipped, {counts(results).notProcessing} skipped (not in Processing),{" "}
              {counts(results).noTracking} skipped (no tracking number), {counts(results).notFound}{" "}
              not found.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order Number</TableHead>
                    <TableHead>Previous Status</TableHead>
                    <TableHead>Action Taken</TableHead>
                    <TableHead>New Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {results.map((r, i) => (
                    <TableRow key={`${r.orderNumber}-${i}`}>
                      <TableCell className="font-mono text-xs">{r.orderNumber}</TableCell>
                      <TableCell className="capitalize">{r.previousStatus}</TableCell>
                      <TableCell>
                        <Badge variant={badgeVariant(r.action)}>{r.action}</Badge>
                      </TableCell>
                      <TableCell className="capitalize">{r.newStatus}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ShippingTrackingUploadTool;
