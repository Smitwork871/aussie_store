import { useCallback, useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { logActivity } from "@/lib/activityLog";
import { CheckCircle2, Loader2, ShieldCheck } from "lucide-react";

type OrderRow = {
  id: string;
  order_number: string;
  status: string;
  payment_status: string;
};

type ResultRow = {
  orderNumber: string;
  previousStatus: string;
  action: string;
  newStatus: string;
};

const parseOrderNumbers = (raw: string): string[] => {
  const seen = new Set<string>();
  const out: string[] = [];
  raw
    .split(/[\n,;\t]+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .forEach((v) => {
      const key = v.toUpperCase();
      if (!seen.has(key)) {
        seen.add(key);
        out.push(key);
      }
    });
  return out;
};

const PaymentVerificationTool = () => {
  const [input, setInput] = useState("");
  const [scanning, setScanning] = useState(true);
  const [checking, setChecking] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [movingConfirmed, setMovingConfirmed] = useState(false);

  // Step 1 — site-wide confirmed orders
  const [confirmedCount, setConfirmedCount] = useState(0);
  const [step1Answered, setStep1Answered] = useState(false);
  const [step1Outcome, setStep1Outcome] = useState<string | null>(null);

  // Step 2
  const [entered, setEntered] = useState<string[]>([]);
  const [found, setFound] = useState<OrderRow[]>([]);
  const [precheckDone, setPrecheckDone] = useState(false);
  const [results, setResults] = useState<ResultRow[] | null>(null);

  const pendingOrders = found.filter((o) => o.status === "pending");

  const resetStep2 = () => {
    setEntered([]);
    setFound([]);
    setPrecheckDone(false);
    setResults(null);
  };

  const scanConfirmed = useCallback(async () => {
    setScanning(true);
    try {
      const { count, error } = await supabase
        .from("orders")
        .select("id", { count: "exact", head: true })
        .eq("status", "confirmed");
      if (error) throw error;
      const c = count ?? 0;
      setConfirmedCount(c);
      if (c === 0) {
        setStep1Answered(true);
        setStep1Outcome(null);
      } else {
        setStep1Answered(false);
        setStep1Outcome(null);
      }
    } catch (error: any) {
      toast.error(`Could not scan orders: ${error.message}`);
    } finally {
      setScanning(false);
    }
  }, []);

  useEffect(() => {
    scanConfirmed();
  }, [scanConfirmed]);

  const answerStep1 = async (moveToProcessing: boolean) => {
    if (!moveToProcessing) {
      setStep1Answered(true);
      setStep1Outcome(`Left ${confirmedCount} confirmed order(s) untouched.`);
      return;
    }
    setMovingConfirmed(true);
    try {
      const { error } = await supabase
        .from("orders")
        .update({ status: "processing" as const })
        .eq("status", "confirmed");
      if (error) throw error;
      setStep1Outcome(`Moved ${confirmedCount} confirmed order(s) to Processing.`);
      logActivity({
        actionType: "Bulk Status Change",
        description: `Bulk move: ${confirmedCount} confirmed order(s) moved to Processing`,
        metadata: { count: confirmedCount, from: "confirmed", to: "processing" },
      });
      setStep1Answered(true);
      setConfirmedCount(0);
      toast.success("Confirmed orders moved to Processing");
    } catch (error: any) {
      toast.error(`Update failed: ${error.message}`);
    } finally {
      setMovingConfirmed(false);
    }
  };

  const handleCheck = async () => {
    const numbers = parseOrderNumbers(input);
    if (numbers.length === 0) {
      toast.error("Please enter at least one order number");
      return;
    }
    setChecking(true);
    resetStep2();
    try {
      const { data, error } = await supabase
        .from("orders")
        .select("id, order_number, status, payment_status")
        .in("order_number", numbers);
      if (error) throw error;
      setEntered(numbers);
      setFound((data ?? []) as OrderRow[]);
      setPrecheckDone(true);
    } catch (error: any) {
      toast.error(`Lookup failed: ${error.message}`);
    } finally {
      setChecking(false);
    }
  };

  const runVerification = async () => {
    setProcessing(true);
    try {
      const byNumber = new Map(found.map((o) => [o.order_number.toUpperCase(), o]));

      if (pendingOrders.length > 0) {
        const { error } = await supabase
          .from("orders")
          .update({ status: "confirmed" as const, payment_status: "paid" as const })
          .in(
            "id",
            pendingOrders.map((o) => o.id)
          );
        if (error) throw error;
      }

      const rows: ResultRow[] = entered.map((num) => {
        const order = byNumber.get(num);
        if (!order) {
          return { orderNumber: num, previousStatus: "—", action: "Not Found", newStatus: "—" };
        }
        if (order.status === "pending") {
          return {
            orderNumber: order.order_number,
            previousStatus: "pending",
            action: "Confirmed + Marked Paid",
            newStatus: "confirmed",
          };
        }
        return {
          orderNumber: order.order_number,
          previousStatus: order.status,
          action: "Skipped — not Pending",
          newStatus: order.status,
        };
      });

      setResults(rows);
      setPrecheckDone(false);
      const updatedNumbers = pendingOrders.map((o) => o.order_number);
      logActivity({
        actionType: "Payment Verified (Bulk)",
        description:
          `Bulk payment verification: ${updatedNumbers.length} order(s) confirmed and marked paid` +
          (updatedNumbers.length > 0 ? ` — ${updatedNumbers.join(", ")}` : "") +
          `; ${entered.length - updatedNumbers.length} skipped of ${entered.length} entered`,
        metadata: { updated: updatedNumbers, entered, skipped: entered.length - updatedNumbers.length },
      });
      toast.success("Bulk verification completed");
    } catch (error: any) {
      toast.error(`Update failed: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const notFoundCount = entered.length - found.length;
  const step2Locked = !step1Answered;

  return (
      <div className="space-y-6">
        {/* STEP 1 */}
        <Card>
          <CardHeader>
            <CardTitle>Step 1 — Store-wide confirmed orders</CardTitle>
            <CardDescription>
              This check runs across all orders in the store, independently of the list below.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {scanning ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Scanning all orders...
              </div>
            ) : confirmedCount > 0 && !step1Answered ? (
              <Alert>
                <CheckCircle2 className="h-4 w-4" />
                <AlertTitle>Confirmed orders detected</AlertTitle>
                <AlertDescription className="space-y-3">
                  <p>
                    {confirmedCount} order{confirmedCount === 1 ? "" : "s"} across the store{" "}
                    {confirmedCount === 1 ? "is" : "are"} currently in Confirmed status. Do you want
                    to move these to Processing status?
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => answerStep1(true)} disabled={movingConfirmed}>
                      {movingConfirmed ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                      Yes, move to Processing
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => answerStep1(false)}
                      disabled={movingConfirmed}
                    >
                      No, leave as is
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            ) : (
              <div className="flex flex-wrap items-center gap-3">
                <p className="text-sm text-muted-foreground">
                  {step1Outcome ??
                    "No orders are currently in Confirmed status. You can proceed to payment verification."}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setStep1Outcome(null);
                    scanConfirmed();
                  }}
                >
                  Re-scan
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* STEP 2 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5" />
              Step 2 — Bulk payment verification
            </CardTitle>
            <CardDescription>
              One order number per line (commas also work). Only Pending orders are updated. Nothing
              is changed until you confirm.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {step2Locked && (
              <p className="text-sm text-muted-foreground">
                Answer the Step 1 prompt above before running payment verification.
              </p>
            )}
            <Textarea
              rows={8}
              placeholder={"ORD-XXXXXXXXXXXX\nORD-YYYYYYYYYYYY"}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="font-mono text-sm"
              disabled={step2Locked}
            />
            <div className="flex gap-2">
              <Button onClick={handleCheck} disabled={step2Locked || checking || processing}>
                {checking ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Checking...
                  </>
                ) : (
                  "Check Orders"
                )}
              </Button>
              {(precheckDone || results) && (
                <Button
                  variant="outline"
                  onClick={() => {
                    setInput("");
                    resetStep2();
                  }}
                  disabled={processing}
                >
                  Clear
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {precheckDone && (
          <Card>
            <CardHeader>
              <CardTitle>Pre-check summary</CardTitle>
              <CardDescription>
                {entered.length} unique order number{entered.length === 1 ? "" : "s"} entered ·{" "}
                {pendingOrders.length} pending · {found.length - pendingOrders.length} other status ·{" "}
                {notFoundCount} not found
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={runVerification} disabled={processing}>
                {processing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                  </>
                ) : (
                  "Verify payments"
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        {results && (
          <Card>
            <CardHeader>
              <CardTitle>Results</CardTitle>
              <CardDescription>{results.length} order numbers processed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order Number</TableHead>
                      <TableHead>Previous Status</TableHead>
                      <TableHead>Action Taken</TableHead>
                      <TableHead>New Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {results.map((r) => (
                      <TableRow key={r.orderNumber}>
                        <TableCell className="font-mono text-xs">{r.orderNumber}</TableCell>
                        <TableCell className="capitalize">{r.previousStatus}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              r.action === "Not Found"
                                ? "destructive"
                                : r.action.startsWith("Skipped")
                                ? "secondary"
                                : "default"
                            }
                          >
                            {r.action}
                          </Badge>
                        </TableCell>
                        <TableCell className="capitalize">{r.newStatus}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
  );
};

export default PaymentVerificationTool;
