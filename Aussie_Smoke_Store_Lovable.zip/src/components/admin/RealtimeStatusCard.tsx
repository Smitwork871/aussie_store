import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Radio, Signal, Wifi, WifiOff, Zap } from "lucide-react";

type RealtimeStatus = "SUBSCRIBING" | "SUBSCRIBED" | "CLOSED" | "CHANNEL_ERROR" | "TIMED_OUT";

type LogEntry = {
  id: string;
  event: string;
  detail: string;
  time: string;
};

const statusConfig: Record<RealtimeStatus, { label: string; color: string; icon: typeof Signal }> = {
  SUBSCRIBING: { label: "Connecting", color: "bg-warning text-warning-foreground", icon: Signal },
  SUBSCRIBED: { label: "Connected", color: "bg-success text-success-foreground", icon: Wifi },
  CLOSED: { label: "Closed", color: "bg-muted text-muted-foreground", icon: WifiOff },
  CHANNEL_ERROR: { label: "Error", color: "bg-destructive text-destructive-foreground", icon: WifiOff },
  TIMED_OUT: { label: "Timed out", color: "bg-destructive text-destructive-foreground", icon: WifiOff },
};

export function RealtimeStatusCard() {
  const [status, setStatus] = useState<RealtimeStatus>("SUBSCRIBING");
  const [eventCount, setEventCount] = useState(0);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const logId = useRef(0);

  useEffect(() => {
    const channel = supabase
      .channel("dashboard-realtime-status")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "orders" },
        (payload) => {
          const event = payload.eventType;
          const id =
            ((payload.new as Record<string, unknown>)?.id as string) ??
            ((payload.old as Record<string, unknown>)?.id as string) ??
            "unknown";
          const time = new Date().toLocaleTimeString();
          const newLog: LogEntry = {
            id: `${++logId.current}`,
            event: `${event} orders`,
            detail: id.slice(0, 8),
            time,
          };
          setEventCount((c) => c + 1);
          setLogs((prev) => [newLog, ...prev].slice(0, 5));
        }
      )
      .subscribe((state, err) => {
        if (state === "SUBSCRIBED") setStatus("SUBSCRIBED");
        else if (state === "CLOSED") setStatus("CLOSED");
        else if (state === "CHANNEL_ERROR") setStatus("CHANNEL_ERROR");
        else if (state === "TIMED_OUT") setStatus("TIMED_OUT");

        if (err) {
          console.error("Dashboard realtime status error:", err);
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="flex items-center gap-2 text-base">
          <Radio className="h-4 w-4" />
          Orders Realtime
        </CardTitle>
        <Badge className={config.color}>
          <Icon className="h-3 w-3 mr-1" />
          {config.label}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Events received</span>
          <span className="font-semibold tabular-nums">{eventCount}</span>
        </div>

        {logs.length > 0 && (
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
              <Zap className="h-3 w-3 text-warning" />
              Recent events
            </div>
            <ul className="text-xs space-y-1 max-h-28 overflow-y-auto pr-1">
              {logs.map((log) => (
                <li key={log.id} className="flex items-center gap-2">
                  <span className="font-mono uppercase">{log.event}</span>
                  <span className="text-muted-foreground">#{log.detail}</span>
                  <span className="ml-auto tabular-nums text-muted-foreground">{log.time}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {status !== "SUBSCRIBED" && (
          <p className="text-xs text-muted-foreground">
            {status === "SUBSCRIBING"
              ? "Waiting for the realtime subscription to confirm…"
              : "Realtime connection is down. Dashboard counters may not update until it reconnects."}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
