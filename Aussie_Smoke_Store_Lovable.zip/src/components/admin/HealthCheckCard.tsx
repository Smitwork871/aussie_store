import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Activity, CheckCircle2, XCircle, Loader2, PlayCircle } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

type Step = { name: string; ok: boolean; ms: number; detail?: string };
type Run = {
  id: string;
  status: "running" | "success" | "failed";
  started_at: string;
  completed_at: string | null;
  duration_ms: number | null;
  test_order_number: string | null;
  failed_step: string | null;
  error_message: string | null;
  steps: Step[];
  trigger: string;
};

export function HealthCheckCard() {
  const [runs, setRuns] = useState<Run[]>([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);

  const load = async () => {
    const { data } = await supabase
      .from("health_check_runs")
      .select("*")
      .order("started_at", { ascending: false })
      .limit(5);
    setRuns(((data as unknown) as Run[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const runNow = async () => {
    setTriggering(true);
    try {
      const { data, error } = await supabase.functions.invoke("daily-health-check");
      if (error) throw error;
      if ((data as any)?.status === "success") {
        toast.success("Health check passed");
      } else {
        toast.error(`Health check failed at: ${(data as any)?.failed_step}`);
      }
      await load();
    } catch (e: any) {
      toast.error(e.message || "Failed to trigger health check");
    } finally {
      setTriggering(false);
    }
  };

  const latest = runs[0];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="flex items-center gap-2 text-base">
          <Activity className="h-4 w-4" />
          End-to-end health check
        </CardTitle>
        <Button size="sm" variant="outline" onClick={runNow} disabled={triggering}>
          {triggering ? (
            <Loader2 className="h-4 w-4 animate-spin mr-1" />
          ) : (
            <PlayCircle className="h-4 w-4 mr-1" />
          )}
          Run now
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : !latest ? (
          <p className="text-sm text-muted-foreground">
            No checks yet. Runs automatically every day at 9:00 AM AEST, or click "Run now".
          </p>
        ) : (
          <>
            <div className="flex items-center gap-2">
              {latest.status === "success" ? (
                <Badge className="bg-green-600 hover:bg-green-600">
                  <CheckCircle2 className="h-3 w-3 mr-1" /> Passing
                </Badge>
              ) : latest.status === "running" ? (
                <Badge variant="secondary">
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" /> Running
                </Badge>
              ) : (
                <Badge variant="destructive">
                  <XCircle className="h-3 w-3 mr-1" /> Failed
                </Badge>
              )}
              <span className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(latest.started_at), { addSuffix: true })}
                {latest.duration_ms != null && ` · ${(latest.duration_ms / 1000).toFixed(1)}s`}
              </span>
            </div>

            {latest.failed_step && (
              <div className="text-sm rounded-md border border-destructive/30 bg-destructive/10 p-2">
                <div className="font-medium">Failed at: {latest.failed_step}</div>
                <div className="text-xs text-muted-foreground break-all">{latest.error_message}</div>
              </div>
            )}

            <ul className="text-xs space-y-1">
              {(latest.steps || []).map((s, i) => (
                <li key={i} className="flex items-start gap-2">
                  {s.ok ? (
                    <CheckCircle2 className="h-3.5 w-3.5 text-green-600 mt-0.5 flex-shrink-0" />
                  ) : (
                    <XCircle className="h-3.5 w-3.5 text-destructive mt-0.5 flex-shrink-0" />
                  )}
                  <span className="flex-1">
                    <span className="font-mono">{s.name}</span>
                    {s.detail && <span className="text-muted-foreground"> — {s.detail}</span>}
                  </span>
                  <span className="text-muted-foreground">{s.ms}ms</span>
                </li>
              ))}
            </ul>

            {runs.length > 1 && (
              <div className="pt-2 border-t">
                <div className="text-xs font-medium mb-1 text-muted-foreground">Recent runs</div>
                <ul className="text-xs space-y-0.5">
                  {runs.slice(1).map((r) => (
                    <li key={r.id} className="flex items-center gap-2">
                      {r.status === "success" ? (
                        <CheckCircle2 className="h-3 w-3 text-green-600" />
                      ) : (
                        <XCircle className="h-3 w-3 text-destructive" />
                      )}
                      <span className="text-muted-foreground">
                        {formatDistanceToNow(new Date(r.started_at), { addSuffix: true })}
                      </span>
                      {r.failed_step && (
                        <span className="text-destructive truncate">— {r.failed_step}</span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}

          </>

        )}
      </CardContent>
    </Card>
  );
}
