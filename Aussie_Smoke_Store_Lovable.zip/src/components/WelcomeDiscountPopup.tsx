import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Gift, Loader2 } from 'lucide-react';
import { z } from 'zod';

const STORAGE_KEY = 'welcome_popup_state_v1';
const DISMISS_DAYS = 7;
const MOBILE_DELAY_MS = 20_000;

type Stored = { dismissedAt?: number; submitted?: boolean };

function readState(): Stored {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
  } catch {
    return {};
  }
}
function writeState(s: Stored) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
}

const emailSchema = z.string().trim().email('Please enter a valid email');

export const WelcomeDiscountPopup: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const state = readState();
    if (state.submitted) return;
    if (state.dismissedAt && Date.now() - state.dismissedAt < DISMISS_DAYS * 86_400_000) return;

    // Don't show on checkout/cart
    if (/^\/(checkout|cart|admin)/.test(window.location.pathname)) return;

    const isMobile = window.matchMedia('(max-width: 768px)').matches;

    let timer: number | undefined;
    const onMouseOut = (e: MouseEvent) => {
      if (e.clientY <= 0 && !open) setOpen(true);
    };

    if (isMobile) {
      timer = window.setTimeout(() => setOpen(true), MOBILE_DELAY_MS);
    } else {
      document.addEventListener('mouseout', onMouseOut);
    }

    return () => {
      if (timer) window.clearTimeout(timer);
      document.removeEventListener('mouseout', onMouseOut);
    };
  }, [open]);

  const handleClose = () => {
    setOpen(false);
    writeState({ ...readState(), dismissedAt: Date.now() });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = emailSchema.safeParse(email);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .insert({ email: parsed.data.toLowerCase(), is_active: true });

      // 23505 = already subscribed - treat as success
      if (error && error.code !== '23505') throw error;

      writeState({ submitted: true });
      setSubmitted(true);
      toast.success('Check your inbox for your discount code!');
    } catch {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? setOpen(true) : handleClose())}>
      <DialogContent className="max-w-md p-0 overflow-hidden">
        <div className="bg-gradient-to-br from-primary/15 via-primary/5 to-transparent p-6 sm:p-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/15 text-primary">
            <Gift className="h-7 w-7" aria-hidden />
          </div>
          {submitted ? (
            <>
              <h2 className="text-xl font-bold mb-2">You're in! 🎉</h2>
              <p className="text-sm text-muted-foreground mb-5">
                Use code <span className="font-mono font-bold text-primary">WELCOME5</span> at checkout for A$5 off your first order.
              </p>
              <Button onClick={handleClose} className="w-full">Start shopping</Button>
            </>
          ) : (
            <>
              <h2 className="text-xl sm:text-2xl font-bold mb-2">Get A$5 off your first order</h2>
              <p className="text-sm text-muted-foreground mb-5">
                Drop your email and we'll send a one-time discount code instantly.
              </p>
              <form onSubmit={handleSubmit} className="space-y-3">
                <Input
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="text-center"
                />
                <Button type="submit" className="w-full" disabled={submitting}>
                  {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Send me my code
                </Button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="text-xs text-muted-foreground hover:text-foreground underline"
                >
                  No thanks
                </button>
              </form>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
