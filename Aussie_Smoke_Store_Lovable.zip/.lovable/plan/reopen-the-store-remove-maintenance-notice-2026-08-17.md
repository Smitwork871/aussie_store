# Reopen the store (remove maintenance notice)

Turn off the maintenance barrier so all visitors reach the normal site and can place orders again.

## Changes
1. `src/App.tsx` — set `MAINTENANCE_MODE` to `false`, so every public route renders normally instead of the notice page. The private unlock route stays in place, unused, in case the gate is needed again.
2. `public/robots.txt` — restore crawling (allow all, keep the sitemap reference) so search engines re-index the site.

Nothing else changes: the notice component, admin pages, data, and all features stay exactly as they are.

## Verify
Build check plus a quick load of the home page to confirm the storefront renders instead of the notice.
