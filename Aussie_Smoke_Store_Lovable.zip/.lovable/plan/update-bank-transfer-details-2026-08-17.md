# Update bank transfer details

Replace the current bank account details with the new ones everywhere they appear. Nothing else changes.

## New details
- Account Name: K P TRADERS
- BSB: 067-873
- Account Number: 2544 7750

## Where they appear
1. Checkout / order confirmation bank details card (`src/components/checkout/BankDetailsCard.tsx`) — currently K M Patel / 062 948 / 3035 5704.
2. Order email template in the `send-order-email` backend function — same three lines in the payment instructions table.

## Steps
- Update the three values in the checkout card.
- Update the three matching lines in the order email template.
- Redeploy the order email function so new emails carry the new details.
- Run a build check to confirm nothing else broke.

No layout, copy, or logic changes beyond the three values.
