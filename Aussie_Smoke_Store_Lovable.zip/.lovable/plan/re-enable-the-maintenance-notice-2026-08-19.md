# Re-enable the maintenance notice

Hide the whole public site behind the "Important Notice" page again, keeping all data, admin pages and features intact.

## Changes
1. `src/App.tsx` — set `MAINTENANCE_MODE` back to `true`, so every public route renders the notice page instead of the storefront. Users cannot browse products or place orders.
2. `public/robots.txt` — set `Disallow: /` again so search engines don't crawl the site while it's closed.

The notice wording stays exactly as it is in `src/components/MaintenancePage.tsx`.

## Private access
Unchanged: visit `/admin-access-8f3a2c` once to unlock the site on your device, then log in and use the dashboard normally. `/admin-access-lock` removes the bypass.

## Verify
Build check plus a load of the home page to confirm the notice shows, and the unlock link still reveals the site.
