DO $$ DECLARE t text; BEGIN
FOREACH t IN ARRAY ARRAY['categories','products','coupons','coupon_usages','orders','order_items','order_attributions','inventory_logs','newsletter_subscribers','abandoned_carts','broadcasts','broadcast_sends','broadcast_unsubscribes','health_check_runs'] LOOP
  EXECUTE format('ALTER TABLE public.%I ENABLE TRIGGER USER', t);
END LOOP; END $$;