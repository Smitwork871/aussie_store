REVOKE ALL ON FUNCTION public.log_order_activity() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.log_product_activity() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.log_inventory_activity() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.log_customer_note_activity() FROM PUBLIC, anon, authenticated;

REVOKE ALL ON FUNCTION public.log_activity(text, text, text, uuid, text, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_activity(text, text, text, uuid, text, jsonb) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.log_activity(
  p_action_type text,
  p_description text,
  p_ref_type text DEFAULT NULL,
  p_ref_id uuid DEFAULT NULL,
  p_ref_label text DEFAULT NULL,
  p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_email text;
  v_name text;
  v_label text;
  v_id uuid;
BEGIN
  -- Direct calls (not from a trigger) are admin-only; trigger context has no restriction
  IF pg_trigger_depth() = 0 AND v_uid IS NOT NULL AND NOT public.has_role(v_uid, 'admin'::app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  IF v_uid IS NOT NULL THEN
    SELECT email, full_name INTO v_email, v_name
      FROM public.profiles WHERE user_id = v_uid LIMIT 1;
    v_label := COALESCE(NULLIF(v_name, ''), v_email, 'Admin');
  ELSE
    v_label := 'System';
  END IF;

  INSERT INTO public.activity_logs(actor_id, actor_email, actor_label, action_type, description, ref_type, ref_id, ref_label, metadata)
  VALUES (v_uid, v_email, v_label, p_action_type, p_description, p_ref_type, p_ref_id, p_ref_label, COALESCE(p_metadata, '{}'::jsonb))
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;