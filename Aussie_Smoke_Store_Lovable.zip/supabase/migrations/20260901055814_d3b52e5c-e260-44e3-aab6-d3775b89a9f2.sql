ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_numbers text[] NOT NULL DEFAULT '{}';

UPDATE public.orders
SET tracking_numbers = ARRAY[tracking_number]
WHERE tracking_number IS NOT NULL
  AND btrim(tracking_number) <> ''
  AND cardinality(tracking_numbers) = 0;