CREATE TABLE public.activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  actor_id uuid,
  actor_email text,
  actor_label text NOT NULL DEFAULT 'System',
  action_type text NOT NULL,
  description text NOT NULL,
  ref_type text,
  ref_id uuid,
  ref_label text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_activity_logs_created_at ON public.activity_logs (created_at DESC);
CREATE INDEX idx_activity_logs_action_type ON public.activity_logs (action_type);
CREATE INDEX idx_activity_logs_actor ON public.activity_logs (actor_id);

GRANT SELECT ON public.activity_logs TO authenticated;
GRANT ALL ON public.activity_logs TO service_role;

ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view activity logs"
ON public.activity_logs FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Core writer: SECURITY DEFINER so inserts always succeed, even from triggers/system paths
CREATE OR REPLACE FUNCTION public.log_activity(
  p_action_type text,
  p_description text,
  p_ref_type text DEFAULT NULL,
  p_ref_id uuid DEFAULT NULL,
  p_ref_label text DEFAULT NULL,
  p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_email text;
  v_name text;
  v_label text;
  v_id uuid;
BEGIN
  IF v_uid IS NOT NULL THEN
    SELECT email, full_name INTO v_email, v_name
      FROM public.profiles WHERE user_id = v_uid LIMIT 1;
    v_label := COALESCE(NULLIF(v_name, ''), v_email, 'Admin');
  ELSE
    v_label := 'System';
  END IF;

  INSERT INTO public.activity_logs(actor_id, actor_email, actor_label, action_type, description, ref_type, ref_id, ref_label, metadata)
  VALUES (v_uid, v_email, v_label, p_action_type, p_description, p_ref_type, p_ref_id, p_ref_label, COALESCE(p_metadata, '{}'::jsonb))
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.log_activity(text, text, text, uuid, text, jsonb) TO authenticated, service_role;

-- ORDERS -------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.log_order_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_old text[];
  v_new text[];
  v_added text[];
  v_removed text[];
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.log_activity(
      'Order Created',
      'Order #' || NEW.order_number || ' placed for ' || to_char(NEW.total, 'FM999999990.00'),
      'order', NEW.id, NEW.order_number, '{}'::jsonb
    );
    RETURN NEW;
  END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    PERFORM public.log_activity(
      CASE WHEN NEW.status = 'cancelled' THEN 'Order Cancelled' ELSE 'Order Status Changed' END,
      'Order #' || NEW.order_number || ': Status changed from ' || OLD.status || ' to ' || NEW.status,
      'order', NEW.id, NEW.order_number,
      jsonb_build_object('from', OLD.status, 'to', NEW.status)
    );
  END IF;

  IF NEW.payment_status IS DISTINCT FROM OLD.payment_status THEN
    PERFORM public.log_activity(
      'Payment Status Changed',
      'Order #' || NEW.order_number || ': Payment changed from ' || OLD.payment_status || ' to ' || NEW.payment_status,
      'order', NEW.id, NEW.order_number,
      jsonb_build_object('from', OLD.payment_status, 'to', NEW.payment_status)
    );
  END IF;

  v_old := COALESCE(OLD.tracking_numbers, '{}') ;
  IF COALESCE(array_length(v_old, 1), 0) = 0 AND OLD.tracking_number IS NOT NULL THEN
    v_old := ARRAY[OLD.tracking_number];
  END IF;
  v_new := COALESCE(NEW.tracking_numbers, '{}');
  IF COALESCE(array_length(v_new, 1), 0) = 0 AND NEW.tracking_number IS NOT NULL THEN
    v_new := ARRAY[NEW.tracking_number];
  END IF;

  IF v_old IS DISTINCT FROM v_new THEN
    SELECT COALESCE(array_agg(x), '{}') INTO v_added
      FROM unnest(v_new) AS x WHERE NOT (x = ANY(v_old));
    SELECT COALESCE(array_agg(x), '{}') INTO v_removed
      FROM unnest(v_old) AS x WHERE NOT (x = ANY(v_new));

    IF COALESCE(array_length(v_added, 1), 0) > 0 THEN
      PERFORM public.log_activity(
        'Tracking Number Added',
        'Order #' || NEW.order_number || ': Tracking number ''' || array_to_string(v_added, ''', ''') || ''' added',
        'order', NEW.id, NEW.order_number,
        jsonb_build_object('added', to_jsonb(v_added))
      );
    END IF;
    IF COALESCE(array_length(v_removed, 1), 0) > 0 THEN
      PERFORM public.log_activity(
        'Tracking Number Removed',
        'Order #' || NEW.order_number || ': Tracking number ''' || array_to_string(v_removed, ''', ''') || ''' removed',
        'order', NEW.id, NEW.order_number,
        jsonb_build_object('removed', to_jsonb(v_removed))
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_log_order_insert
AFTER INSERT ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.log_order_activity();

CREATE TRIGGER trg_log_order_update
AFTER UPDATE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.log_order_activity();

-- PRODUCTS -----------------------------------------------------------
CREATE OR REPLACE FUNCTION public.log_product_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_changes text[] := '{}';
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.log_activity('Product Added', 'Product "' || NEW.name || '" created', 'product', NEW.id, NEW.name, '{}'::jsonb);
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM public.log_activity('Product Deleted', 'Product "' || OLD.name || '" deleted', 'product', OLD.id, OLD.name, '{}'::jsonb);
    RETURN OLD;
  END IF;

  IF NEW.name IS DISTINCT FROM OLD.name THEN
    v_changes := v_changes || ('name "' || OLD.name || '" to "' || NEW.name || '"');
  END IF;
  IF NEW.price IS DISTINCT FROM OLD.price THEN
    v_changes := v_changes || ('price ' || to_char(OLD.price, 'FM999999990.00') || ' to ' || to_char(NEW.price, 'FM999999990.00'));
  END IF;
  IF NEW.is_active IS DISTINCT FROM OLD.is_active THEN
    v_changes := v_changes || ('active ' || OLD.is_active || ' to ' || NEW.is_active);
  END IF;
  IF NEW.is_featured IS DISTINCT FROM OLD.is_featured THEN
    v_changes := v_changes || ('featured ' || OLD.is_featured || ' to ' || NEW.is_featured);
  END IF;
  IF NEW.category_id IS DISTINCT FROM OLD.category_id THEN
    v_changes := v_changes || 'category changed';
  END IF;
  IF NEW.images IS DISTINCT FROM OLD.images THEN
    v_changes := v_changes || 'images updated';
  END IF;
  IF NEW.description IS DISTINCT FROM OLD.description
     OR NEW.short_description IS DISTINCT FROM OLD.short_description THEN
    v_changes := v_changes || 'description updated';
  END IF;

  IF COALESCE(array_length(v_changes, 1), 0) > 0 THEN
    PERFORM public.log_activity(
      'Product Updated',
      'Product "' || NEW.name || '": ' || array_to_string(v_changes, ', '),
      'product', NEW.id, NEW.name, '{}'::jsonb
    );
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_log_product_changes
AFTER INSERT OR UPDATE OR DELETE ON public.products
FOR EACH ROW EXECUTE FUNCTION public.log_product_activity();

-- INVENTORY ----------------------------------------------------------
CREATE OR REPLACE FUNCTION public.log_inventory_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_name text;
  v_delta int := NEW.new_quantity - NEW.previous_quantity;
BEGIN
  SELECT name INTO v_name FROM public.products WHERE id = NEW.product_id;

  PERFORM public.log_activity(
    'Stock Change',
    'Product "' || COALESCE(v_name, 'Unknown') || '": stock ' || NEW.previous_quantity || ' to ' || NEW.new_quantity
      || ' (' || CASE WHEN v_delta >= 0 THEN '+' ELSE '' END || v_delta || ') — ' || NEW.change_type
      || COALESCE(' — ' || NEW.notes, ''),
    'product', NEW.product_id, v_name,
    jsonb_build_object('change_type', NEW.change_type, 'delta', v_delta, 'reference_id', NEW.reference_id)
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_log_inventory_changes
AFTER INSERT ON public.inventory_logs
FOR EACH ROW EXECUTE FUNCTION public.log_inventory_activity();

-- CUSTOMER NOTES -----------------------------------------------------
CREATE OR REPLACE FUNCTION public.log_customer_note_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.log_activity('Customer Note Added', 'Note added for customer ' || NEW.email, 'customer', NULL, NEW.email, '{}'::jsonb);
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.note IS DISTINCT FROM OLD.note THEN
      PERFORM public.log_activity('Customer Note Updated', 'Note updated for customer ' || NEW.email, 'customer', NULL, NEW.email, '{}'::jsonb);
    END IF;
  ELSE
    PERFORM public.log_activity('Customer Note Deleted', 'Note deleted for customer ' || OLD.email, 'customer', NULL, OLD.email, '{}'::jsonb);
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_log_customer_note_changes
AFTER INSERT OR UPDATE OR DELETE ON public.customer_notes
FOR EACH ROW EXECUTE FUNCTION public.log_customer_note_activity();