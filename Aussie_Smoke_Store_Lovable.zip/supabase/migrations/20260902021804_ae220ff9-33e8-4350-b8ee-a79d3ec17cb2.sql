ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS stock_deducted BOOLEAN NOT NULL DEFAULT false;

-- Existing orders predate stock tracking: treat them as not deducted so cancelling them doesn't invent stock.

CREATE OR REPLACE FUNCTION public.place_order(p_guest_email text, p_payment_method text, p_shipping_amount numeric, p_discount_amount numeric, p_shipping_address jsonb, p_notes text, p_items jsonb, p_coupon_id uuid DEFAULT NULL::uuid)
 RETURNS TABLE(order_id uuid, order_number text, verification_token text, total numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id UUID := auth.uid();
  v_order_id UUID;
  v_order_number TEXT;
  v_verification_token TEXT;
  v_subtotal NUMERIC := 0;
  v_total NUMERIC;
  v_item JSONB;
  v_product RECORD;
  v_qty INT;
  v_line_total NUMERIC;
  v_coupon_id UUID;
  v_coupon_type TEXT;
  v_coupon_value NUMERIC;
  v_coupon_max NUMERIC;
  v_discount NUMERIC := 0;
  v_shipping NUMERIC := 0;
  v_free_ship_threshold CONSTANT NUMERIC := 50;
  v_flat_ship CONSTANT NUMERIC := 10;
  v_age_ok BOOLEAN;
  v_new_stock INT;
BEGIN
  IF p_items IS NULL OR jsonb_array_length(p_items) = 0 THEN
    RAISE EXCEPTION 'Cart is empty';
  END IF;

  IF v_user_id IS NOT NULL THEN
    SELECT COALESCE(age_verified, false) INTO v_age_ok
      FROM public.profiles WHERE user_id = v_user_id;
    IF NOT COALESCE(v_age_ok, false) THEN
      RAISE EXCEPTION 'Age verification required before placing an order';
    END IF;
  END IF;

  IF v_user_id IS NULL THEN
    IF p_guest_email IS NULL OR length(trim(p_guest_email)) = 0 THEN
      RAISE EXCEPTION 'Email required for guest orders';
    END IF;
    v_verification_token := gen_random_uuid()::TEXT;
  END IF;

  -- Price + stock check pass (rows locked in id order to avoid deadlocks)
  FOR v_item IN
    SELECT value FROM jsonb_array_elements(p_items) AS t(value)
    ORDER BY (value->>'product_id')
  LOOP
    v_qty := (v_item->>'quantity')::INT;
    IF v_qty IS NULL OR v_qty <= 0 THEN
      RAISE EXCEPTION 'Invalid quantity';
    END IF;
    SELECT id, price, name, sku, images, stock_quantity
      INTO v_product
      FROM public.products
     WHERE id = (v_item->>'product_id')::UUID AND is_active = true
     FOR UPDATE;
    IF v_product.id IS NULL THEN
      RAISE EXCEPTION 'Product unavailable: %', v_item->>'product_id';
    END IF;
    IF COALESCE(v_product.stock_quantity, 0) < v_qty THEN
      IF COALESCE(v_product.stock_quantity, 0) <= 0 THEN
        RAISE EXCEPTION 'Out of stock: % is currently unavailable', v_product.name;
      ELSE
        RAISE EXCEPTION 'Insufficient stock: only % left of %', v_product.stock_quantity, v_product.name;
      END IF;
    END IF;
    v_subtotal := v_subtotal + (v_product.price * v_qty);
  END LOOP;

  v_shipping := CASE WHEN v_subtotal >= v_free_ship_threshold THEN 0 ELSE v_flat_ship END;

  IF p_coupon_id IS NOT NULL THEN
    SELECT id, discount_type::text, discount_value, max_discount_amount
      INTO v_coupon_id, v_coupon_type, v_coupon_value, v_coupon_max
      FROM public.coupons
     WHERE id = p_coupon_id
       AND is_active = true
       AND (valid_from IS NULL OR valid_from <= now())
       AND (valid_until IS NULL OR valid_until > now())
       AND (max_uses IS NULL OR uses_count < max_uses)
       AND (min_order_amount IS NULL OR v_subtotal >= min_order_amount)
     LIMIT 1;

    IF v_coupon_id IS NOT NULL THEN
      IF v_coupon_type = 'percentage' THEN
        v_discount := round((v_subtotal * v_coupon_value / 100)::numeric, 2);
      ELSE
        v_discount := round(v_coupon_value::numeric, 2);
      END IF;

      IF v_coupon_max IS NOT NULL THEN
        v_discount := LEAST(v_discount, v_coupon_max);
      END IF;
      v_discount := LEAST(v_discount, v_subtotal);
      v_discount := GREATEST(v_discount, 0);
    ELSE
      v_discount := 0;
    END IF;
  END IF;

  v_total := round(GREATEST(0, v_subtotal + v_shipping - v_discount)::numeric, 2);

  INSERT INTO public.orders(
    order_number, user_id, guest_email, verification_token,
    status, payment_status, payment_method,
    subtotal, shipping_amount, tax_amount, discount_amount, total,
    shipping_address, notes, stock_deducted
  ) VALUES (
    'TEMP', v_user_id, COALESCE(p_guest_email, NULL), v_verification_token,
    'pending', 'pending', p_payment_method,
    round(v_subtotal::numeric, 2), v_shipping, 0, v_discount, v_total,
    p_shipping_address, NULLIF(p_notes, ''), true
  ) RETURNING id, orders.order_number INTO v_order_id, v_order_number;

  FOR v_item IN
    SELECT value FROM jsonb_array_elements(p_items) AS t(value)
    ORDER BY (value->>'product_id')
  LOOP
    SELECT id, price, name, sku, images, stock_quantity INTO v_product
      FROM public.products WHERE id = (v_item->>'product_id')::UUID AND is_active = true;
    v_qty := (v_item->>'quantity')::INT;
    v_line_total := round((v_product.price * v_qty)::numeric, 2);
    INSERT INTO public.order_items(
      order_id, product_id, product_name, product_sku, product_image, quantity, unit_price, total_price
    ) VALUES (
      v_order_id, v_product.id, v_product.name, v_product.sku,
      COALESCE(v_product.images[1], NULL), v_qty, v_product.price, v_line_total
    );

    -- Reserve stock immediately (guarded so it can never go negative)
    UPDATE public.products
       SET stock_quantity = stock_quantity - v_qty
     WHERE id = v_product.id
       AND stock_quantity >= v_qty
     RETURNING stock_quantity INTO v_new_stock;

    IF v_new_stock IS NULL THEN
      RAISE EXCEPTION 'Insufficient stock: % is no longer available in the requested quantity', v_product.name;
    END IF;

    INSERT INTO public.inventory_logs(product_id, previous_quantity, new_quantity, change_type, reference_id, notes)
    VALUES (v_product.id, v_new_stock + v_qty, v_new_stock, 'order_placed', v_order_id, 'Stock reserved for order ' || v_order_number);
  END LOOP;

  IF v_coupon_id IS NOT NULL AND v_discount > 0 THEN
    PERFORM public.increment_coupon_usage(v_coupon_id, v_order_id, v_user_id, v_discount);
  END IF;

  order_id := v_order_id;
  order_number := v_order_number;
  verification_token := v_verification_token;
  total := v_total;
  RETURN NEXT;
END;
$function$;

-- Restore stock whenever an order moves into the cancelled state and stock was deducted for it
CREATE OR REPLACE FUNCTION public.restore_stock_on_cancel()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  r RECORD;
  v_new_stock INT;
BEGIN
  IF NEW.status = 'cancelled'
     AND OLD.status IS DISTINCT FROM 'cancelled'
     AND COALESCE(OLD.stock_deducted, false) = true THEN

    FOR r IN
      SELECT product_id, SUM(quantity)::INT AS qty
        FROM public.order_items
       WHERE order_id = NEW.id AND product_id IS NOT NULL
       GROUP BY product_id
       ORDER BY product_id
    LOOP
      UPDATE public.products
         SET stock_quantity = stock_quantity + r.qty
       WHERE id = r.product_id
       RETURNING stock_quantity INTO v_new_stock;

      IF v_new_stock IS NOT NULL THEN
        INSERT INTO public.inventory_logs(product_id, previous_quantity, new_quantity, change_type, reference_id, notes)
        VALUES (r.product_id, v_new_stock - r.qty, v_new_stock, 'order_cancelled', NEW.id, 'Stock restored for cancelled order ' || NEW.order_number);
      END IF;
    END LOOP;

    NEW.stock_deducted := false;
  END IF;

  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_restore_stock_on_cancel ON public.orders;
CREATE TRIGGER trg_restore_stock_on_cancel
BEFORE UPDATE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.restore_stock_on_cancel();