import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SITE_URL = "https://cheapsmokescentral.com";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Product {
  name: string;
  slug: string;
  price: number;
  description: string | null;
  short_description: string | null;
  meta_title: string | null;
  meta_description: string | null;
  images: string[] | null;
  brand: string | null;
  compare_at_price: number | null;
  stock_quantity: number;
  category_id: string | null;
}

interface Category {
  name: string;
  slug: string;
  description: string | null;
  image_url: string | null;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderHead(title: string, description: string, canonicalPath: string, jsonLd?: object): string {
  return `<!DOCTYPE html>
<html lang="en-AU">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)}</title>
  <meta name="description" content="${escapeHtml(description)}">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="${SITE_URL}${canonicalPath}">
  <meta property="og:title" content="${escapeHtml(title)}">
  <meta property="og:description" content="${escapeHtml(description)}">
  <meta property="og:url" content="${SITE_URL}${canonicalPath}">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Aussie Smoke Store">
  <meta property="og:locale" content="en_AU">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escapeHtml(title)}">
  <meta name="twitter:description" content="${escapeHtml(description)}">
  ${jsonLd ? `<script type="application/ld+json">${JSON.stringify(jsonLd)}</script>` : ""}
</head>`;
}

function renderNav(): string {
  return `<nav>
  <a href="/">Home</a> |
  <a href="/products">Products</a> |
  <a href="/categories">Categories</a> |
  <a href="/cheap-cigarettes-online">Cigarettes</a> |
  <a href="/cheap-vapes-online">Vapes</a> |
  <a href="/cheap-tobacco-online">Tobacco</a> |
  <a href="/about">About</a> |
  <a href="/contact">Contact</a>
</nav>`;
}

function renderFooter(): string {
  return `<footer>
  <p>&copy; 2026 Aussie Smoke Store. All rights reserved.</p>
  <p>Australia's cheapest online smoke shop. Free shipping on orders over A$50.</p>
  <nav>
    <a href="/privacy">Privacy Policy</a> | <a href="/terms">Terms &amp; Conditions</a>
  </nav>
  <p>⚠️ Statutory Warning: Cigarette smoking is injurious to health. This website is intended for adults aged 21 and above only.</p>
</footer>`;
}

// Static page content map
const STATIC_PAGES: Record<string, { title: string; description: string; h1: string; content: string }> = {
  "/": {
    title: "Cheap Smokes Online Australia | Aussie Smoke Store — Buy Cigarettes Online",
    description: "Buy cheap smokes online in Australia. Cheapest cigarettes, rolling tobacco, vapes & accessories. Free shipping over A$50.",
    h1: "Cheap Smokes Online Australia — Aussie Smoke Store",
    content: "<p>Welcome to Aussie Smoke Store, Australia's #1 online smoke shop. Browse our wide selection of cheap cigarettes, rolling tobacco, vapes, and tobacco accessories at the best prices. Free shipping on orders over A$50.</p>",
  },
  "/about": {
    title: "About Aussie Smoke Store — Cheap Smokes Online Australia",
    description: "Aussie Smoke Store is Australia's trusted source for cheap smokes online. Premium cigarettes, vapes & tobacco at the best prices since 2020.",
    h1: "About Aussie Smoke Store",
    content: "<p>Your trusted source for premium tobacco products since 2020. We provide the finest selection of tobacco products with fast, discreet shipping across Australia.</p>",
  },
  "/contact": {
    title: "Contact Aussie Smoke Store — Cheap Smokes Online Australia",
    description: "Contact Aussie Smoke Store for any questions about cheap smokes online in Australia. Fast support for orders, shipping and products.",
    h1: "Contact Us",
    content: "<p>Have a question? Reach out to our support team and we'll get back to you as soon as possible.</p>",
  },
  "/products": {
    title: "All Products — Cheap Smokes Online Australia | Aussie Smoke Store",
    description: "Browse all cheap smokes, cigarettes, vapes and tobacco products online in Australia. Best prices guaranteed.",
    h1: "All Products",
    content: "<p>Browse our complete collection of cigarettes, vapes, rolling tobacco, and accessories at the cheapest prices in Australia.</p>",
  },
  "/categories": {
    title: "Shop by Category — Cheap Smokes Online Australia | Aussie Smoke Store",
    description: "Browse cigarettes, vapes, tobacco and accessories by category. Find cheap smokes online in Australia.",
    h1: "Shop by Category",
    content: "<p>Find exactly what you're looking for by browsing our product categories.</p>",
  },
  "/cheap-smokes-online": {
    title: "Cheap Smokes Online — Buy Cheap Smokes in Australia | Aussie Smoke Store",
    description: "Buy cheap smokes online in Australia. Best prices on cigarettes, tobacco and vapes. Free shipping over A$50.",
    h1: "Cheap Smokes Online Australia",
    content: "<p>Looking for cheap smokes online? Aussie Smoke Store offers the cheapest smokes in Australia with fast, discreet delivery.</p>",
  },
  "/cheap-cigarettes-online": {
    title: "Cheap Cigarettes Online — Buy Cigarettes Online Australia | Aussie Smoke Store",
    description: "Buy cheap cigarettes online in Australia. Premium brands at the lowest prices. Free shipping over A$50.",
    h1: "Cheap Cigarettes Online Australia",
    content: "<p>Shop cheap cigarettes online at Aussie Smoke Store. We stock all major brands at unbeatable prices.</p>",
  },
  "/cheap-vapes-online": {
    title: "Cheap Vapes Online — Buy Vapes Online Australia | Aussie Smoke Store",
    description: "Buy cheap vapes online in Australia. Top brands like UWELL and Alibarbar at the best prices.",
    h1: "Cheap Vapes Online Australia",
    content: "<p>Shop the best vapes online at Aussie Smoke Store. Premium vape devices and e-liquids at the cheapest prices in Australia.</p>",
  },
  "/cheap-tobacco-online": {
    title: "Cheap Tobacco Online — Buy Tobacco Online Australia | Aussie Smoke Store",
    description: "Buy cheap tobacco online in Australia. Rolling tobacco, pipe tobacco and accessories at the lowest prices.",
    h1: "Cheap Tobacco Online Australia",
    content: "<p>Find cheap tobacco online at Aussie Smoke Store. Premium rolling tobacco and pipe tobacco at discount prices.</p>",
  },
  "/cheap-rolling-tobacco-online": {
    title: "Cheap Rolling Tobacco Online Australia | Aussie Smoke Store",
    description: "Buy cheap rolling tobacco online in Australia. Best brands and prices with free shipping over A$50.",
    h1: "Cheap Rolling Tobacco Online Australia",
    content: "<p>Shop cheap rolling tobacco online. We carry all the top rolling tobacco brands at unbeatable prices.</p>",
  },
  "/buy-cigarettes-online-australia": {
    title: "Buy Cigarettes Online Australia — Aussie Smoke Store",
    description: "Buy cigarettes online in Australia at the cheapest prices. Fast delivery, authentic products.",
    h1: "Buy Cigarettes Online Australia",
    content: "<p>Buy cigarettes online in Australia from Aussie Smoke Store. 100% authentic products with fast, discreet shipping Australia-wide.</p>",
  },
  "/cheapest-cigarettes-australia": {
    title: "Cheapest Cigarettes Australia — Aussie Smoke Store",
    description: "Find the cheapest cigarettes in Australia online. Compare prices and save.",
    h1: "Cheapest Cigarettes in Australia",
    content: "<p>Find the cheapest cigarettes in Australia at Aussie Smoke Store. We guarantee the lowest prices on all major brands.</p>",
  },
  "/best-cigarettes-australia": {
    title: "Best Cigarettes Australia 2026 — Aussie Smoke Store",
    description: "Discover the best cigarettes in Australia. Top brands reviewed and rated.",
    h1: "Best Cigarettes Australia 2026",
    content: "<p>Explore the best cigarettes available in Australia, reviewed and rated by our experts.</p>",
  },
  "/discount-tobacco-online": {
    title: "Discount Tobacco Online Australia — Aussie Smoke Store",
    description: "Shop discount tobacco online in Australia. Lowest prices on rolling tobacco and cigarettes.",
    h1: "Discount Tobacco Online Australia",
    content: "<p>Get the best discounts on tobacco products online at Aussie Smoke Store.</p>",
  },
  "/duty-free-cigarettes-australia": {
    title: "Duty Free Cigarettes Australia — Aussie Smoke Store",
    description: "Buy duty free cigarettes in Australia at discount prices online.",
    h1: "Duty Free Cigarettes Australia",
    content: "<p>Shop duty free cigarettes in Australia at Aussie Smoke Store. Premium international brands at the best prices.</p>",
  },
  "/marlboro-cigarettes-australia": {
    title: "Marlboro Cigarettes Australia — Buy Marlboro Online | Aussie Smoke Store",
    description: "Buy Marlboro cigarettes in Australia online. Marlboro Red, Gold and more at cheap prices.",
    h1: "Marlboro Cigarettes Australia",
    content: "<p>Buy Marlboro cigarettes online in Australia. We stock Marlboro Red, Marlboro Gold and more at unbeatable prices.</p>",
  },
  "/nicotine-pouches-australia": {
    title: "Nicotine Pouches Australia — Buy Online | Aussie Smoke Store",
    description: "Buy nicotine pouches online in Australia. Smoke-free alternative at the best prices.",
    h1: "Nicotine Pouches Australia",
    content: "<p>Shop nicotine pouches online in Australia. A modern, smoke-free nicotine alternative at great prices.</p>",
  },
  "/cigarettes-near-me": {
    title: "Cigarettes Near Me — Buy Cigarettes Online Australia | Aussie Smoke Store",
    description: "Searching for cigarettes near me? Buy cigarettes online and get delivery Australia-wide.",
    h1: "Cigarettes Near Me — Delivered Australia-Wide",
    content: "<p>No need to search for cigarettes near me. Order online from Aussie Smoke Store and get fast delivery to your door anywhere in Australia.</p>",
  },
  "/bulk-cigarettes-australia": {
    title: "Bulk Cigarettes Australia — Buy Cartons Online | Aussie Smoke Store",
    description: "Buy bulk cigarettes and cartons online in Australia at the cheapest prices.",
    h1: "Bulk Cigarettes Australia",
    content: "<p>Save big when you buy cigarettes in bulk. Aussie Smoke Store offers the best carton prices in Australia.</p>",
  },
  "/tobacco-delivery-australia": {
    title: "Tobacco Delivery Australia — Fast Shipping | Aussie Smoke Store",
    description: "Fast tobacco delivery across Australia. Order online and get discreet shipping to your door.",
    h1: "Tobacco Delivery Australia",
    content: "<p>Get fast, discreet tobacco delivery across Australia. Order from Aussie Smoke Store and enjoy free shipping on orders over A$50.</p>",
  },
  "/cheap-darts-online": {
    title: "Cheap Darts Online Australia — Aussie Smoke Store",
    description: "Buy cheap darts (cigarettes) online in Australia. Best prices and fast delivery.",
    h1: "Cheap Darts Online Australia",
    content: "<p>Looking for cheap darts? Aussie Smoke Store has the cheapest cigarettes in Australia with fast delivery.</p>",
  },
  "/cheap-durries-online": {
    title: "Cheap Durries Online Australia — Aussie Smoke Store",
    description: "Buy cheap durries online in Australia. Cheapest cigarettes with fast shipping.",
    h1: "Cheap Durries Online Australia",
    content: "<p>Shop cheap durries online at Aussie Smoke Store. Australia's cheapest cigarettes delivered to your door.</p>",
  },
  "/online-smoke-shop-australia": {
    title: "Online Smoke Shop Australia — Aussie Smoke Store",
    description: "Australia's best online smoke shop. Cigarettes, vapes, tobacco and accessories at cheap prices.",
    h1: "Online Smoke Shop Australia",
    content: "<p>Welcome to Australia's #1 online smoke shop. Aussie Smoke Store stocks everything you need at the cheapest prices.</p>",
  },
  "/online-tobacco-shop-australia": {
    title: "Online Tobacco Shop Australia — Aussie Smoke Store",
    description: "Shop at Australia's best online tobacco shop. Cheap tobacco, cigarettes and accessories.",
    h1: "Online Tobacco Shop Australia",
    content: "<p>Aussie Smoke Store is Australia's premier online tobacco shop. Browse our full range at unbeatable prices.</p>",
  },
  "/order-cigarettes-online-australia": {
    title: "Order Cigarettes Online Australia — Aussie Smoke Store",
    description: "Order cigarettes online in Australia. Fast delivery, best prices, authentic brands.",
    h1: "Order Cigarettes Online Australia",
    content: "<p>Order cigarettes online in Australia from Aussie Smoke Store. Authentic products at the cheapest prices with fast shipping.</p>",
  },
  "/buy-cheap-smokes-australia": {
    title: "Buy Cheap Smokes Australia — Aussie Smoke Store",
    description: "Buy cheap smokes in Australia online. Cigarettes, tobacco and vapes at discount prices.",
    h1: "Buy Cheap Smokes Australia",
    content: "<p>Buy cheap smokes in Australia at Aussie Smoke Store. We offer the lowest prices on cigarettes, tobacco and vapes.</p>",
  },
  // City pages
  "/cheap-smokes-sydney": { title: "Cheap Smokes Sydney — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Sydney online. Fast delivery across Sydney and NSW.", h1: "Cheap Smokes Sydney", content: "<p>Get cheap smokes delivered in Sydney. Aussie Smoke Store offers fast delivery across the Sydney metro area.</p>" },
  "/cheap-smokes-melbourne": { title: "Cheap Smokes Melbourne — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Melbourne online. Fast delivery across Melbourne and VIC.", h1: "Cheap Smokes Melbourne", content: "<p>Get cheap smokes delivered in Melbourne. Fast delivery across the Melbourne metro area.</p>" },
  "/cheap-smokes-brisbane": { title: "Cheap Smokes Brisbane — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Brisbane online. Fast delivery across Brisbane and QLD.", h1: "Cheap Smokes Brisbane", content: "<p>Get cheap smokes delivered in Brisbane. Fast delivery across the Brisbane area.</p>" },
  "/cheap-smokes-perth": { title: "Cheap Smokes Perth — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Perth online. Fast delivery across Perth and WA.", h1: "Cheap Smokes Perth", content: "<p>Get cheap smokes delivered in Perth. Fast delivery across Western Australia.</p>" },
  "/cheap-smokes-adelaide": { title: "Cheap Smokes Adelaide — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Adelaide online. Fast delivery across Adelaide and SA.", h1: "Cheap Smokes Adelaide", content: "<p>Get cheap smokes delivered in Adelaide. Fast delivery across South Australia.</p>" },
  "/cheap-smokes-gold-coast": { title: "Cheap Smokes Gold Coast — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes on the Gold Coast online.", h1: "Cheap Smokes Gold Coast", content: "<p>Get cheap smokes delivered on the Gold Coast.</p>" },
  "/cheap-smokes-canberra": { title: "Cheap Smokes Canberra — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Canberra online.", h1: "Cheap Smokes Canberra", content: "<p>Get cheap smokes delivered in Canberra.</p>" },
  "/cheap-smokes-hobart": { title: "Cheap Smokes Hobart — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Hobart online.", h1: "Cheap Smokes Hobart", content: "<p>Get cheap smokes delivered in Hobart and Tasmania.</p>" },
  "/cheap-smokes-darwin": { title: "Cheap Smokes Darwin — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Darwin online.", h1: "Cheap Smokes Darwin", content: "<p>Get cheap smokes delivered in Darwin and the Northern Territory.</p>" },
  "/cheap-smokes-newcastle": { title: "Cheap Smokes Newcastle — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in Newcastle online.", h1: "Cheap Smokes Newcastle", content: "<p>Get cheap smokes delivered in Newcastle and the Hunter Valley.</p>" },
  // State pages
  "/cheap-smokes-nsw": { title: "Cheap Smokes NSW — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in NSW online. Fast delivery across New South Wales.", h1: "Cheap Smokes NSW", content: "<p>Get cheap smokes delivered across New South Wales.</p>" },
  "/cheap-smokes-vic": { title: "Cheap Smokes VIC — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in VIC online. Fast delivery across Victoria.", h1: "Cheap Smokes VIC", content: "<p>Get cheap smokes delivered across Victoria.</p>" },
  "/cheap-smokes-qld": { title: "Cheap Smokes QLD — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in QLD online. Fast delivery across Queensland.", h1: "Cheap Smokes QLD", content: "<p>Get cheap smokes delivered across Queensland.</p>" },
  "/cheap-smokes-wa": { title: "Cheap Smokes WA — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in WA online. Fast delivery across Western Australia.", h1: "Cheap Smokes WA", content: "<p>Get cheap smokes delivered across Western Australia.</p>" },
  "/cheap-smokes-sa": { title: "Cheap Smokes SA — Buy Online | Aussie Smoke Store", description: "Buy cheap smokes in SA online. Fast delivery across South Australia.", h1: "Cheap Smokes SA", content: "<p>Get cheap smokes delivered across South Australia.</p>" },
  // Brand pages
  "/manchester-cigarettes-australia": { title: "Manchester Cigarettes Australia — Aussie Smoke Store", description: "Buy Manchester cigarettes online in Australia at cheap prices.", h1: "Manchester Cigarettes Australia", content: "<p>Shop Manchester cigarettes online at Aussie Smoke Store.</p>" },
  "/benson-hedges-cigarettes-australia": { title: "Benson & Hedges Cigarettes Australia — Aussie Smoke Store", description: "Buy Benson & Hedges cigarettes online in Australia at cheap prices.", h1: "Benson & Hedges Cigarettes Australia", content: "<p>Shop Benson & Hedges cigarettes online at Aussie Smoke Store.</p>" },
  "/double-happiness-cigarettes-australia": { title: "Double Happiness Cigarettes Australia — Aussie Smoke Store", description: "Buy Double Happiness cigarettes online in Australia.", h1: "Double Happiness Cigarettes Australia", content: "<p>Shop Double Happiness cigarettes online at Aussie Smoke Store.</p>" },
  "/uwell-vapes-australia": { title: "UWELL Vapes Australia — Aussie Smoke Store", description: "Buy UWELL vapes online in Australia at the best prices.", h1: "UWELL Vapes Australia", content: "<p>Shop UWELL vapes online at Aussie Smoke Store.</p>" },
  "/alibarbar-vapes-australia": { title: "Alibarbar Vapes Australia — Aussie Smoke Store", description: "Buy Alibarbar vapes online in Australia at cheap prices.", h1: "Alibarbar Vapes Australia", content: "<p>Shop Alibarbar vapes online at Aussie Smoke Store.</p>" },
  // Guide pages
  "/cigarette-prices-australia": { title: "Cigarette Prices Australia 2026 — Price Guide | Aussie Smoke Store", description: "Complete guide to cigarette prices in Australia 2026. Compare prices and find the cheapest options.", h1: "Cigarette Prices Australia 2026", content: "<p>Your complete guide to cigarette prices in Australia for 2026.</p>" },
  "/rolling-tobacco-guide-australia": { title: "Rolling Tobacco Guide Australia — Aussie Smoke Store", description: "Complete guide to rolling tobacco in Australia. Best brands and techniques.", h1: "Rolling Tobacco Guide Australia", content: "<p>Everything you need to know about rolling tobacco in Australia.</p>" },
  "/vape-guide-australia": { title: "Best Vapes Australia 2026 — Vape Guide | Aussie Smoke Store", description: "Complete vape guide for Australia 2026. Best devices, e-liquids and more.", h1: "Best Vapes Australia 2026", content: "<p>Your complete guide to the best vapes in Australia for 2026.</p>" },
  // Legal pages
  "/privacy": { title: "Privacy Policy — Aussie Smoke Store", description: "Aussie Smoke Store privacy policy. How we handle your data.", h1: "Privacy Policy", content: "<p>Read our privacy policy to understand how we handle your data.</p>" },
  "/terms": { title: "Terms & Conditions — Aussie Smoke Store", description: "Aussie Smoke Store terms and conditions of use.", h1: "Terms & Conditions", content: "<p>Read our terms and conditions for using Aussie Smoke Store.</p>" },
  // Competitor-targeting brand product landing pages
  "/manchester-double-drive-australia": { title: "Manchester Double Drive Cigarettes Australia — Cheapest Online | Aussie Smoke Store", description: "Buy Manchester Double Drive cigarettes online in Australia. Cheapest carton prices, free shipping over A$50, 48h dispatch.", h1: "Manchester Double Drive Cigarettes Australia", content: "<p>Buy Manchester Double Drive cigarettes in Australia. Cheapest carton prices online with 48-hour dispatch and free shipping over A$50.</p>" },
  "/manchester-royal-red-cigarettes-australia": { title: "Manchester Royal Red Cigarettes Australia — Buy Online | Aussie Smoke Store", description: "Buy Manchester Royal Red cigarettes online in Australia at the cheapest carton prices. Free shipping over A$50.", h1: "Manchester Royal Red Cigarettes Australia", content: "<p>Manchester Royal Red — full-flavour classic — delivered Australia-wide at unbeatable prices.</p>" },
  "/manchester-sapphire-blue-australia": { title: "Manchester Sapphire Blue Cigarettes Australia — Cheap Online | Aussie Smoke Store", description: "Buy Manchester Sapphire Blue cigarettes online in Australia. Smoother, lighter blend at the cheapest carton prices.", h1: "Manchester Sapphire Blue Cigarettes Australia", content: "<p>Manchester Sapphire Blue — smoother, lighter Manchester variant — at Australia's cheapest carton prices.</p>" },
  "/marlboro-ice-blast-australia": { title: "Marlboro Ice Blast Australia — Buy Online Cheap | Aussie Smoke Store", description: "Buy Marlboro Ice Blast menthol capsule cigarettes online in Australia. Cheapest carton prices, free shipping over A$50.", h1: "Marlboro Ice Blast Australia", content: "<p>Marlboro Ice Blast — the iconic menthol capsule cigarette — delivered Australia-wide at the cheapest prices.</p>" },
  "/marlboro-red-cigarettes-australia": { title: "Marlboro Red Cigarettes Australia — Cheapest Online | Aussie Smoke Store", description: "Buy Marlboro Red cigarettes online in Australia. Cheapest carton prices, free shipping over A$50, 48h dispatch.", h1: "Marlboro Red Cigarettes Australia", content: "<p>Marlboro Red — the iconic full-flavour cigarette — at Australia's cheapest carton prices.</p>" },
  "/mac-cool-blast-cigarettes-australia": { title: "MAC Cool Blast Cigarettes Australia — Buy Online | Aussie Smoke Store", description: "Buy MAC Cool Blast superslim menthol cigarettes online in Australia. Cheapest carton prices, free shipping over A$50.", h1: "MAC Cool Blast Superslims Australia", content: "<p>MAC Cool Blast Superslim menthol cigarettes — delivered Australia-wide at the cheapest prices.</p>" },
  "/euro-blue-cigarettes-australia": { title: "Euro Blue Cigarettes Australia — Buy Online Cheap | Aussie Smoke Store", description: "Buy Euro Blue cigarettes online in Australia. Smooth European-style blend at the cheapest carton prices.", h1: "Euro Blue Cigarettes Australia", content: "<p>Euro Blue — smooth European-style cigarettes — at Australia's lowest carton prices.</p>" },
  "/esse-menthol-cigarettes-australia": { title: "Esse Menthol Cigarettes Australia — Buy Online | Aussie Smoke Store", description: "Buy Esse menthol superslim cigarettes online in Australia. Cheapest carton prices, free shipping over A$50.", h1: "Esse Menthol Cigarettes Australia", content: "<p>Esse — Korea's iconic superslim menthol cigarettes — delivered Australia-wide.</p>" },
  "/bensons-hedges-gold-cigarettes-australia": { title: "B&H Gold Cigarettes Australia — Buy Benson & Hedges Online | Aussie Smoke Store", description: "Buy Benson & Hedges Gold cigarettes online in Australia. Premium B&H Gold cartons at the cheapest prices.", h1: "B&H Gold Cigarettes Australia", content: "<p>Benson & Hedges Gold — Australia's favourite premium cigarette — at the cheapest carton prices online.</p>" },
  "/dunhill-blue-cigarettes-australia": { title: "Dunhill Blue Cigarettes Australia — Buy Online Cheap | Aussie Smoke Store", description: "Buy Dunhill Blue cigarettes online in Australia. Premium Dunhill cartons at Australia's cheapest prices.", h1: "Dunhill Blue Cigarettes Australia", content: "<p>Dunhill Blue — the smooth premium British blend — at Australia's cheapest carton prices.</p>" },
};

async function renderProductPage(supabase: ReturnType<typeof createClient>, slug: string): Promise<string | null> {
  const { data: product } = await supabase
    .from("products")
    .select("name, slug, price, description, short_description, meta_title, meta_description, images, brand, compare_at_price, stock_quantity, category_id")
    .eq("slug", slug)
    .eq("is_active", true)
    .single();

  if (!product) return null;

  const p = product as Product;
  const title = p.meta_title || `${p.name} — Buy Online | Aussie Smoke Store`;
  const description = p.meta_description || p.short_description || `Buy ${p.name} online at Aussie Smoke Store. Best prices in Australia.`;
  const imageUrl = p.images?.[0] || "";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name,
    description: p.short_description || p.description || "",
    image: imageUrl,
    brand: p.brand ? { "@type": "Brand", name: p.brand } : undefined,
    offers: {
      "@type": "Offer",
      url: `${SITE_URL}/products/${p.slug}`,
      priceCurrency: "AUD",
      price: p.price,
      availability: p.stock_quantity > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      seller: { "@type": "Organization", name: "Aussie Smoke Store" },
    },
  };

  return `${renderHead(title, description, `/products/${p.slug}`, jsonLd)}
<body>
<div style="max-width:960px;margin:0 auto;padding:20px;font-family:system-ui,sans-serif">
  ${renderNav()}
  <nav aria-label="breadcrumb"><a href="/">Home</a> &gt; <a href="/products">Products</a> &gt; ${escapeHtml(p.name)}</nav>
  <article>
    <h1>${escapeHtml(p.name)}</h1>
    ${imageUrl ? `<img src="${escapeHtml(imageUrl)}" alt="${escapeHtml(p.name)}" loading="lazy" width="400">` : ""}
    ${p.brand ? `<p><strong>Brand:</strong> ${escapeHtml(p.brand)}</p>` : ""}
    <p><strong>Price:</strong> A$${p.price.toFixed(2)}</p>
    ${p.compare_at_price ? `<p><s>Was: A$${p.compare_at_price.toFixed(2)}</s></p>` : ""}
    <p><strong>Availability:</strong> ${p.stock_quantity > 0 ? "In Stock" : "Out of Stock"}</p>
    ${p.description ? `<div>${escapeHtml(p.description)}</div>` : ""}
    ${p.short_description ? `<p>${escapeHtml(p.short_description)}</p>` : ""}
  </article>
  ${renderFooter()}
</div>
</body>
</html>`;
}

async function renderProductsListPage(supabase: ReturnType<typeof createClient>): Promise<string> {
  const { data: products } = await supabase
    .from("products")
    .select("name, slug, price, short_description, images, brand")
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(100);

  const pageData = STATIC_PAGES["/products"];
  let productListHtml = "";

  if (products && products.length > 0) {
    productListHtml = "<ul>";
    for (const p of products) {
      const prod = p as Pick<Product, "name" | "slug" | "price" | "short_description" | "images" | "brand">;
      productListHtml += `<li><a href="/products/${escapeHtml(prod.slug)}">${escapeHtml(prod.name)}</a> — A$${prod.price.toFixed(2)}${prod.brand ? ` (${escapeHtml(prod.brand)})` : ""}</li>`;
    }
    productListHtml += "</ul>";
  }

  return `${renderHead(pageData.title, pageData.description, "/products")}
<body>
<div style="max-width:960px;margin:0 auto;padding:20px;font-family:system-ui,sans-serif">
  ${renderNav()}
  <h1>${escapeHtml(pageData.h1)}</h1>
  ${pageData.content}
  ${productListHtml}
  ${renderFooter()}
</div>
</body>
</html>`;
}

async function renderCategoriesPage(supabase: ReturnType<typeof createClient>): Promise<string> {
  const { data: categories } = await supabase
    .from("categories")
    .select("name, slug, description")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  const pageData = STATIC_PAGES["/categories"];
  let catListHtml = "";

  if (categories && categories.length > 0) {
    catListHtml = "<ul>";
    for (const c of categories) {
      const cat = c as Pick<Category, "name" | "slug" | "description">;
      catListHtml += `<li><a href="/products?category=${escapeHtml(cat.slug)}">${escapeHtml(cat.name)}</a>${cat.description ? ` — ${escapeHtml(cat.description)}` : ""}</li>`;
    }
    catListHtml += "</ul>";
  }

  return `${renderHead(pageData.title, pageData.description, "/categories")}
<body>
<div style="max-width:960px;margin:0 auto;padding:20px;font-family:system-ui,sans-serif">
  ${renderNav()}
  <h1>${escapeHtml(pageData.h1)}</h1>
  ${pageData.content}
  ${catListHtml}
  ${renderFooter()}
</div>
</body>
</html>`;
}

function renderStaticPage(path: string): string | null {
  const pageData = STATIC_PAGES[path];
  if (!pageData) return null;

  return `${renderHead(pageData.title, pageData.description, path)}
<body>
<div style="max-width:960px;margin:0 auto;padding:20px;font-family:system-ui,sans-serif">
  ${renderNav()}
  <h1>${escapeHtml(pageData.h1)}</h1>
  ${pageData.content}
  ${renderFooter()}
</div>
</body>
</html>`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.searchParams.get("path") || "/";
    const normalizedPath = path.startsWith("/") ? path : `/${path}`;

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    let html: string | null = null;

    // Product detail page
    if (normalizedPath.startsWith("/products/") && normalizedPath !== "/products/") {
      const slug = normalizedPath.replace("/products/", "");
      html = await renderProductPage(supabase, slug);
    }
    // Products listing with dynamic data
    else if (normalizedPath === "/products") {
      html = await renderProductsListPage(supabase);
    }
    // Categories with dynamic data
    else if (normalizedPath === "/categories") {
      html = await renderCategoriesPage(supabase);
    }
    // Static pages
    else {
      html = renderStaticPage(normalizedPath);
    }

    if (!html) {
      return new Response("Not Found", {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "text/plain" },
      });
    }

    return new Response(html, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "text/html; charset=utf-8",
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "public, max-age=3600, s-maxage=86400",
        "X-Robots-Tag": "noindex",
      },
    });
  } catch (error) {
    console.error("Prerender error:", error);
    return new Response("Internal Server Error", {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "text/plain" },
    });
  }
});
