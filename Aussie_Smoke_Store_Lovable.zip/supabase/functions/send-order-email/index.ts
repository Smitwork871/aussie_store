import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  "https://cheapsmokescentral.com",
  "https://www.cheapsmokescentral.com",
  "https://cheapsmokecentral.lovable.app",
  "https://id-preview--c85f35eb-6636-4401-b296-afd08a7f877e.lovable.app",
  "http://localhost:8080",
  "http://localhost:5173",
];

function buildCorsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get("Origin") ?? "";
  const allowOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowOrigin,
    "Vary": "Origin",
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  };
}

interface OrderItem {
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  product_image: string | null;
}

interface ShippingAddress {
  full_name: string;
  phone: string;
  address_line1: string;
  address_line2?: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
}

// Escape user-controlled values before embedding in HTML email body.
function escapeHtml(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

Deno.serve(async (req) => {
  const corsHeaders = buildCorsHeaders(req);
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  if (!RESEND_API_KEY) {
    return new Response(JSON.stringify({ error: "RESEND_API_KEY not configured" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

  // Authentication: accept service role key, valid user JWT, or verification token
  const authHeader = req.headers.get("Authorization");
  const isServiceRole = authHeader === `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`;
  let authenticatedUserId: string | null = null;

  if (!isServiceRole && authHeader?.startsWith("Bearer ")) {
    // Try to validate as user JWT
    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace("Bearer ", "");
    try {
      const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
      if (!claimsError && claimsData?.claims?.sub) {
        authenticatedUserId = claimsData.claims.sub as string;
      }
    } catch (_e) {
      // Not a valid user JWT, will check verification_token below
    }
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  try {
    const { order_id, email_type, verification_token } = await req.json();

    if (!order_id) {
      throw new Error("order_id is required");
    }

    // Authorization check for non-service-role callers
    if (!isServiceRole) {
      // Fetch order to verify authorization
      const { data: authOrder, error: authErr } = await supabase
        .from("orders")
        .select("user_id, verification_token")
        .eq("id", order_id)
        .single();

      if (authErr || !authOrder) {
        return new Response(JSON.stringify({ error: "Order not found" }), {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (authenticatedUserId) {
        // Authenticated user: must own the order or be admin
        if (authOrder.user_id !== authenticatedUserId) {
          const { data: roleData } = await supabase
            .from("user_roles")
            .select("role")
            .eq("user_id", authenticatedUserId)
            .eq("role", "admin")
            .single();

          if (!roleData) {
            return new Response(JSON.stringify({ error: "Forbidden" }), {
              status: 403,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }
        }
      } else if (verification_token) {
        // Guest caller: must provide valid verification token
        if (!authOrder.verification_token || authOrder.verification_token !== verification_token) {
          return new Response(JSON.stringify({ error: "Invalid verification token" }), {
            status: 403,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
      } else {
        // No valid auth method
        return new Response(JSON.stringify({ error: "Unauthorized" }), {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // Fetch order
    const { data: order, error: orderErr } = await supabase
      .from("orders")
      .select("*")
      .eq("id", order_id)
      .single();

    if (orderErr || !order) throw new Error("Order not found");

    // Fetch order items
    const { data: items, error: itemsErr } = await supabase
      .from("order_items")
      .select("*")
      .eq("order_id", order_id);

    if (itemsErr) throw new Error("Failed to fetch order items");

    // Get recipient email - prefer guest_email (checkout form email) for all orders
    let recipientEmail = order.guest_email;
    if (!recipientEmail && order.user_id) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("email")
        .eq("user_id", order.user_id)
        .single();
      recipientEmail = profile?.email;
    }

    if (!recipientEmail) throw new Error("No recipient email found");

    const shipping = order.shipping_address as ShippingAddress | null;
    const type = email_type || "confirmation";
    const ADMIN_EMAIL = "imsuttaking@gmail.com";

    const subjectMap: Record<string, string> = {
      confirmation: `Order Confirmation - ${order.order_number}`,
      cancellation: `Order ${order.order_number} has been cancelled`,
      payment_confirmed: `Payment Confirmed - ${order.order_number}`,
      order_confirmed: `Order Confirmed - ${order.order_number}`,
      processing: `Order ${order.order_number} is being processed`,
      shipped: `Order ${order.order_number} has been shipped`,
      awaiting_collection: `Your order ${order.order_number} is awaiting collection at Australia Post`,
      delivered: `Order ${order.order_number} has been delivered`,
      refunded: `Order ${order.order_number} has been refunded`,
      payment_failed: `Payment Failed - ${order.order_number}`,
      payment_reminder: `Gentle payment reminder - Order ${order.order_number}`,
    };
    const subject = subjectMap[type] || `Order Update - ${order.order_number}`;

    const html = buildEmailHtml(order, items || [], shipping, type);

    // For confirmation emails, send to both admin and customer
    // For update emails, send only to the customer
    const recipients: string[] = [];
    if (type === "confirmation") {
      recipients.push(ADMIN_EMAIL);
      if (recipientEmail && recipientEmail.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
        recipients.push(recipientEmail);
      }
    } else {
      // Update emails go to customer only
      recipients.push(recipientEmail);
      // Also send to admin for awareness
      if (recipientEmail.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
        recipients.push(ADMIN_EMAIL);
      }
    }

    // Send via Resend to all recipients
    const resendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Aussie Smoke Store <orders@cheapsmokescentral.com>",
        to: recipients,
        subject,
        html,
      }),
    });

    if (!resendRes.ok) {
      const errText = await resendRes.text();
      throw new Error(`Resend error [${resendRes.status}]: ${errText}`);
    }

    // Best-effort SMS via Twilio (does not fail the email response)
    let smsResult: { attempted: boolean; sent?: boolean; error?: string } = { attempted: false };
    try {
      const smsBody = buildSmsBody(order, type);
      const smsTo = normalizePhoneAu(shipping?.phone);
      if (smsBody && smsTo) {
        smsResult = await sendTwilioSms(smsTo, smsBody);
      }
    } catch (e) {
      smsResult = { attempted: true, sent: false, error: e instanceof Error ? e.message : String(e) };
      console.error("SMS send error:", smsResult.error);
    }

    return new Response(JSON.stringify({ success: true, sent_to: recipients, sms: smsResult }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    console.error("send-order-email error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function buildEmailHtml(
  order: Record<string, unknown>,
  items: OrderItem[],
  shipping: ShippingAddress | null,
  type: string
): string {
  const orderNumber = escapeHtml(order.order_number);

  const headerMap: Record<string, { color: string; text: string; intro: string }> = {
    confirmation: {
      color: "#16a34a",
      text: "Thank You For Your Order!",
      intro: `Your order <strong>${orderNumber}</strong> has been placed successfully. Please transfer the payment using your 6-digit reference code <strong>${orderNumber}</strong> as the bank transfer description.`,
    },
    cancellation: {
      color: "#dc2626",
      text: "Your Order Has Been Cancelled",
      intro: `We're sorry to inform you that your order <strong>${orderNumber}</strong> has been automatically cancelled because payment was not received within 48 hours.`,
    },
    payment_confirmed: {
      color: "#16a34a",
      text: "Payment Confirmed! ✅",
      intro: `Great news! We've received and confirmed payment for your order <strong>${orderNumber}</strong>. Your order will be processed shortly.`,
    },
    order_confirmed: {
      color: "#2563eb",
      text: "Order Confirmed! 📦",
      intro: `Your order <strong>${orderNumber}</strong> has been confirmed and is being prepared.`,
    },
    processing: {
      color: "#7c3aed",
      text: "Order Being Processed 🔄",
      intro: `Your order <strong>${orderNumber}</strong> is currently being processed and will be shipped soon.`,
    },
    shipped: {
      color: "#4f46e5",
      text: "Order Shipped! 🚚",
      intro: `Your order <strong>${orderNumber}</strong> has been shipped and is on its way to you!`,
    },
    awaiting_collection: {
      color: "#f59e0b",
      text: "Ready For Collection at Australia Post 📮",
      intro: `Great news! Your order <strong>${orderNumber}</strong> has arrived at your nearest Australia Post outlet and is <strong>awaiting your collection</strong>.<br/><br/>Please bring a valid photo ID and your tracking number (below) when you visit the outlet. AusPost typically holds parcels for around 10 business days before returning them to sender, so please collect as soon as possible.`,
    },
    delivered: {
      color: "#16a34a",
      text: "Order Delivered! 🎉",
      intro: `Your order <strong>${orderNumber}</strong> has been delivered. We hope you enjoy your purchase!`,
    },
    refunded: {
      color: "#6b7280",
      text: "Order Refunded",
      intro: `Your order <strong>${orderNumber}</strong> has been refunded. The refund should appear in your account shortly.`,
    },
    payment_failed: {
      color: "#dc2626",
      text: "Payment Failed ❌",
      intro: `Unfortunately, the payment for your order <strong>${orderNumber}</strong> has failed. Please contact us if you believe this is an error.`,
    },
    payment_reminder: {
      color: "#f59e0b",
      text: "Gentle Payment Reminder ⏰",
      intro: `This is a Gentle reminder to make your payment for your order. You are receiving this email as the funds may not have reflected in our account yet. If you have already made the payment, you will receive a confirmation email for the next progress on your order. Thank you for being our valued customer.<br/><br/><strong style="color:#dc2626;font-size:15px;">Payment Reference Code: ${orderNumber}</strong> — Please include this reference code when making your bank transfer so we can match your payment to this order.`,
    },
  };

  const defaults = { color: "#2563eb", text: "Order Update", intro: `There's an update on your order <strong>${orderNumber}</strong>.` };
  const { color: headerColor, text: headerText, intro } = headerMap[type] || defaults;
  const isCancel = type === "cancellation";

  const itemRows = items
    .map(
      (item) => `
    <tr>
      <td style="padding:10px;border-bottom:1px solid #eee;">${escapeHtml(item.product_name)}</td>
      <td style="padding:10px;border-bottom:1px solid #eee;text-align:center;">${Number(item.quantity) || 0}</td>
      <td style="padding:10px;border-bottom:1px solid #eee;text-align:right;">A$${Number(item.unit_price).toFixed(2)}</td>
      <td style="padding:10px;border-bottom:1px solid #eee;text-align:right;">A$${Number(item.total_price).toFixed(2)}</td>
    </tr>`
    )
    .join("");

  const shippingHtml = shipping
    ? `<div style="margin-top:20px;padding:15px;background:#f9fafb;border-radius:8px;">
        <h3 style="margin:0 0 10px;font-size:14px;color:#374151;">Shipping Address</h3>
        <p style="margin:0;font-size:13px;color:#6b7280;">
          ${escapeHtml(shipping.full_name)}<br/>
          ${escapeHtml(shipping.address_line1)}${shipping.address_line2 ? "<br/>" + escapeHtml(shipping.address_line2) : ""}<br/>
          ${escapeHtml(shipping.city)}, ${escapeHtml(shipping.state)} ${escapeHtml(shipping.postal_code)}<br/>
          ${escapeHtml(shipping.country)}<br/>
          Phone: ${escapeHtml(shipping.phone)}
        </p>
      </div>`
    : "";

  const bankSection = type === "confirmation" || type === "payment_reminder"
    ? `<div style="margin-top:20px;padding:15px;background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;">
        <h3 style="margin:0 0 10px;font-size:14px;color:#92400e;">💰 Bank Transfer Details</h3>
        <table style="width:100%;font-size:13px;">
          <tr><td style="padding:4px 0;color:#6b7280;">Account Name:</td><td style="font-weight:600;">K P TRADERS</td></tr>
          <tr><td style="padding:4px 0;color:#6b7280;">BSB Code:</td><td style="font-weight:600;">067-873</td></tr>
          <tr><td style="padding:4px 0;color:#6b7280;">Account Number:</td><td style="font-weight:600;">2544 7750</td></tr>
          <tr><td style="padding:4px 0;color:#6b7280;">Amount:</td><td style="font-weight:600;color:#16a34a;">A$${Number(order.total).toFixed(2)}</td></tr>
          <tr><td style="padding:4px 0;color:#6b7280;">Reference Code:</td><td style="font-weight:600;color:#dc2626;font-size:16px;">${orderNumber}</td></tr>
        </table>
        <p style="margin:10px 0 0;font-size:13px;color:#92400e;font-weight:600;">⚠️ IMPORTANT: Please use your reference code <strong style="color:#dc2626;font-size:15px;">${orderNumber}</strong> as the description/reference when making your bank transfer. This helps us identify your payment quickly.</p>
        <p style="margin:8px 0 0;font-size:12px;color:#92400e;">⏰ Please complete the payment within 48 hours of placing your order to avoid automatic cancellation.</p>
      </div>`
    : isCancel
    ? `<p style="margin-top:20px;font-size:14px;color:#6b7280;">If you believe this was a mistake or would like to place a new order, please visit our website.</p>`
    : "";

  const trackingList: string[] = Array.isArray((order as any).tracking_numbers)
    ? ((order as any).tracking_numbers as string[]).map((t) => String(t).trim()).filter(Boolean)
    : [];
  if (trackingList.length === 0 && typeof order.tracking_number === "string" && order.tracking_number.trim()) {
    trackingList.push(order.tracking_number.trim());
  }
  const trackingCarrier = escapeHtml((order.tracking_carrier as string) || "AusPost");
  const trackingSection = (type === "shipped" || type === "awaiting_collection") && trackingList.length > 0
    ? `<div style="margin-top:20px;padding:18px;background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;">
        <h3 style="margin:0 0 10px;font-size:15px;color:#3730a3;">🚚 Track Your Parcel${trackingList.length > 1 ? "s" : ""}</h3>
        <table style="width:100%;font-size:13px;">
          <tr><td style="padding:4px 0;color:#6b7280;">Carrier:</td><td style="font-weight:600;">${trackingCarrier}</td></tr>
          ${trackingList.map((tn, i) => `<tr><td style="padding:4px 0;color:#6b7280;">Tracking Number${trackingList.length > 1 ? ` ${i + 1}` : ""}:</td><td style="font-weight:700;font-family:monospace;font-size:15px;color:#1e1b4b;">${escapeHtml(tn)}</td></tr>`).join("")}
        </table>
        <p style="margin:14px 0 0;text-align:center;">
          ${trackingList.map((tn) => `<a href="https://auspost.com.au/mypost/track/#/details/${encodeURIComponent(tn)}" style="display:inline-block;margin:4px;background:#4f46e5;color:white;text-decoration:none;padding:10px 22px;border-radius:6px;font-weight:600;font-size:14px;">Track ${escapeHtml(tn)}</a>`).join("")}
        </p>
      </div>`
    : "";


  return `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <div style="max-width:600px;margin:0 auto;padding:20px;">
    <div style="background:white;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
      <div style="background:${headerColor};padding:30px;text-align:center;">
        <h1 style="margin:0;color:white;font-size:22px;">${headerText}</h1>
      </div>
      <div style="padding:30px;">
        <p style="font-size:14px;color:#374151;line-height:1.6;">${intro}</p>

        <h3 style="margin:20px 0 10px;font-size:14px;color:#374151;">Order Details</h3>
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead>
            <tr style="background:#f9fafb;">
              <th style="padding:10px;text-align:left;">Product</th>
              <th style="padding:10px;text-align:center;">Qty</th>
              <th style="padding:10px;text-align:right;">Price</th>
              <th style="padding:10px;text-align:right;">Total</th>
            </tr>
          </thead>
          <tbody>${itemRows}</tbody>
        </table>

        <div style="margin-top:15px;padding:15px;background:#f9fafb;border-radius:8px;">
          <table style="width:100%;font-size:13px;">
            <tr><td style="padding:4px 0;color:#6b7280;">Subtotal:</td><td style="text-align:right;">A$${Number(order.subtotal).toFixed(2)}</td></tr>
            <tr><td style="padding:4px 0;color:#6b7280;">Shipping:</td><td style="text-align:right;">${Number(order.shipping_amount) === 0 ? "Free" : "A$" + Number(order.shipping_amount).toFixed(2)}</td></tr>
            ${Number(order.discount_amount) > 0 ? `<tr><td style="padding:4px 0;color:#16a34a;">Discount:</td><td style="text-align:right;color:#16a34a;">-A$${Number(order.discount_amount).toFixed(2)}</td></tr>` : ""}
            <tr style="font-weight:700;font-size:15px;"><td style="padding:8px 0 0;border-top:1px solid #e5e7eb;">Total:</td><td style="text-align:right;padding:8px 0 0;border-top:1px solid #e5e7eb;">A$${Number(order.total).toFixed(2)}</td></tr>
          </table>
        </div>

        ${shippingHtml}
        ${trackingSection}
        ${bankSection}
        ${order.notes ? `<div style="margin-top:15px;padding:10px;background:#f0fdf4;border-radius:8px;font-size:13px;color:#374151;"><strong>Order Notes:</strong> ${escapeHtml(order.notes)}</div>` : ""}
      </div>
      <div style="background:#f9fafb;padding:20px;text-align:center;font-size:12px;color:#9ca3af;">
        <p style="margin:0;">Aussie Smoke Store &bull; Thank you for shopping with us</p>
      </div>
    </div>
  </div>
</body>
</html>`;
}

// ============================================================
// SMS notifications via Twilio
// ============================================================

const TWILIO_GATEWAY_URL = "https://connector-gateway.lovable.dev/twilio";

function normalizePhoneAu(raw: unknown): string | null {
  if (!raw) return null;
  const digits = String(raw).replace(/[^\d+]/g, "");
  if (!digits) return null;
  if (digits.startsWith("+")) return /^\+\d{8,15}$/.test(digits) ? digits : null;
  // Australian mobile: 04XXXXXXXX -> +614XXXXXXXX
  if (/^0\d{9}$/.test(digits)) return "+61" + digits.slice(1);
  if (/^61\d{9}$/.test(digits)) return "+" + digits;
  // 10-digit US-style fallback
  if (/^\d{10}$/.test(digits)) return "+1" + digits;
  return null;
}

function buildSmsBody(order: Record<string, unknown>, type: string): string | null {
  const num = String(order.order_number ?? "");
  const total = typeof order.total === "number" ? (order.total as number).toFixed(2) : String(order.total ?? "");
  const trackingArr = Array.isArray((order as any).tracking_numbers)
    ? ((order as any).tracking_numbers as string[]).map((t) => String(t).trim()).filter(Boolean)
    : [];
  const tracking = trackingArr.length > 0
    ? trackingArr.join(", ")
    : String((order as any).tracking_number ?? "").trim();
  const shortBase = "Aussie Smoke Store";
  switch (type) {
    case "confirmation":
      return `${shortBase}: Order ${num} received (A$${total}). Please pay by bank transfer using reference ${num}. Details in your email.`;
    case "payment_confirmed":
    case "order_confirmed":
      return `${shortBase}: Payment received for order ${num}. We're preparing your order.`;
    case "processing":
      return `${shortBase}: Order ${num} is being processed.`;
    case "shipped":
      return tracking
        ? `${shortBase}: Order ${num} shipped via AusPost. Track: https://auspost.com.au/mypost/track/#/details/${encodeURIComponent(tracking)}`
        : `${shortBase}: Order ${num} has been shipped.`;
    case "awaiting_collection":
      return `${shortBase}: Order ${num} is awaiting collection at Australia Post${tracking ? ` (tracking ${tracking})` : ""}.`;
    case "delivered":
      return `${shortBase}: Order ${num} delivered. Thanks for shopping with us!`;
    case "cancellation":
      return `${shortBase}: Order ${num} has been cancelled.`;
    case "refunded":
      return `${shortBase}: Order ${num} has been refunded.`;
    case "payment_reminder":
      return `${shortBase}: Reminder — order ${num} is awaiting your bank transfer of A$${total}. Use reference ${num}.`;
    case "payment_failed":
      return `${shortBase}: Payment for order ${num} failed. Please try again or contact us.`;
    default:
      return null;
  }
}

async function sendTwilioSms(to: string, body: string): Promise<{ attempted: true; sent: boolean; error?: string }> {
  const TWILIO_ACCOUNT_SID = Deno.env.get("TWILIO_ACCOUNT_SID")?.trim();
  const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN")?.trim();
  const TWILIO_FROM_NUMBER = Deno.env.get("TWILIO_FROM_NUMBER")?.trim();
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_FROM_NUMBER) {
    return { attempted: true, sent: false, error: "Twilio not configured" };
  }
  if (!/^AC[a-zA-Z0-9]{32}$/.test(TWILIO_ACCOUNT_SID)) {
    return { attempted: true, sent: false, error: "Twilio Account SID must start with AC and be copied from the Account Info section" };
  }
  // Try the configured Twilio region first, otherwise try global then AU1.
  // This avoids silently failing if the account is not actually hosted in AU1.
  const configuredRegion = (Deno.env.get("TWILIO_REGION") ?? "").trim().toLowerCase();
  const hosts = configuredRegion
    ? [configuredRegion === "us1" ? "api.twilio.com" : `api.${configuredRegion}.twilio.com`]
    : ["api.twilio.com", "api.au1.twilio.com"];
  const basic = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);

  let lastError = "Twilio send failed";
  for (const host of hosts) {
    const url = `https://${host}/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Basic ${basic}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        To: to,
        From: TWILIO_FROM_NUMBER,
        Body: body.slice(0, 1500),
      }),
    });
    const responseText = await res.text();
    if (res.ok) {
      return { attempted: true, sent: true };
    }
    lastError = `Twilio ${res.status} via ${host}: ${responseText.slice(0, 200)}`;
    console.error(lastError);
  }
  return { attempted: true, sent: false, error: lastError };
}

