import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  // Service-role auth required
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || authHeader !== `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  try {
    const now = Date.now();
    const olderThan24h = new Date(now - 24 * 60 * 60 * 1000).toISOString();
    const newerThan48h = new Date(now - 48 * 60 * 60 * 1000).toISOString();

    const { data: orders, error } = await supabase
      .from("orders")
      .select("id, order_number")
      .eq("status", "pending")
      .eq("payment_status", "pending")
      .is("payment_reminder_sent_at", null)
      .lte("created_at", olderThan24h)
      .gte("created_at", newerThan48h);

    if (error) throw error;

    if (!orders || orders.length === 0) {
      return new Response(
        JSON.stringify({ message: "No reminders to send", sent: 0 }),
        { headers: { "Content-Type": "application/json" } }
      );
    }

    const baseUrl = SUPABASE_URL.replace(/\/$/, "");
    let sent = 0;
    const failures: string[] = [];

    for (const order of orders) {
      try {
        const res = await fetch(`${baseUrl}/functions/v1/send-order-email`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            order_id: order.id,
            email_type: "payment_reminder",
          }),
        });
        if (!res.ok) {
          const t = await res.text();
          throw new Error(`status ${res.status}: ${t}`);
        }
        await supabase
          .from("orders")
          .update({ payment_reminder_sent_at: new Date().toISOString() })
          .eq("id", order.id);
        sent++;
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        console.error(`Reminder failed for ${order.order_number}:`, msg);
        failures.push(`${order.order_number}: ${msg}`);
      }
    }

    console.log(`Payment reminders sent: ${sent}/${orders.length}`);

    return new Response(
      JSON.stringify({ sent, total: orders.length, failures }),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    console.error("send-payment-reminders error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
