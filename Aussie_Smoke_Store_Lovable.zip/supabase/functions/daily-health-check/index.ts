// Daily end-to-end health check.
// - Places a clearly-marked test order via place_order RPC
// - Verifies admin can read it
// - Deletes the test order
// - Logs result to health_check_runs
// - Emails swagarists@gmail.com on failure

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALERT_EMAIL = "swagarists@gmail.com";
const FROM_EMAIL = "Aussie Smoke Store <orders@cheapsmokescentral.com>";
const ADMIN_EMAIL = "iamsuttaking@gmail.com";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

type Step = { name: string; ok: boolean; ms: number; detail?: string };

const SERVICE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_KEY = Deno.env.get("RESEND_API_KEY");

async function sendAlert(subject: string, html: string) {
  if (!RESEND_KEY) return;
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: [ALERT_EMAIL],
        subject,
        html,
      }),
    });
  } catch (e) {
    console.error("alert email failed", e);
  }
}

async function runCheck(trigger: "cron" | "manual") {
  const admin = createClient(SERVICE_URL, SERVICE_KEY, {
    auth: { persistSession: false },
  });
  const steps: Step[] = [];
  const startedAt = new Date();
  const t0 = performance.now();

  let runId: string | null = null;
  let testOrderId: string | null = null;
  let testOrderNumber: string | null = null;
  let failedStep: string | null = null;
  let errorMessage: string | null = null;

  const record = async (name: string, fn: () => Promise<string | void>) => {
    const s = performance.now();
    try {
      const detail = (await fn()) || undefined;
      steps.push({ name, ok: true, ms: Math.round(performance.now() - s), detail });
    } catch (e: any) {
      steps.push({
        name,
        ok: false,
        ms: Math.round(performance.now() - s),
        detail: e?.message || String(e),
      });
      throw Object.assign(new Error(e?.message || String(e)), { step: name });
    }
  };

  // Insert running row
  const { data: runRow, error: runErr } = await admin
    .from("health_check_runs")
    .insert({ status: "running", trigger, started_at: startedAt.toISOString() })
    .select("id")
    .single();
  if (runErr) {
    console.error("could not create health_check_runs row", runErr);
  } else {
    runId = runRow.id;
  }

  try {
    // 1. Pick an active product
    let productId = "";
    let productPrice = 0;
    await record("fetch_test_product", async () => {
      const { data, error } = await admin
        .from("products")
        .select("id, name, price")
        .eq("is_active", true)
        .gt("stock_quantity", 0)
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw new Error("No active in-stock product found");
      productId = data.id;
      productPrice = Number(data.price);
      return `${data.name} ($${productPrice})`;
    });

    // 2. Place order via the same RPC the storefront uses
    await record("place_order_rpc", async () => {
      const { data, error } = await admin.rpc("place_order", {
        p_guest_email: "healthcheck+bot@cheapsmokescentral.com",
        p_payment_method: "bank_transfer",
        p_shipping_amount: 0,
        p_discount_amount: 0,
        p_shipping_address: {
          full_name: "HEALTHCHECK BOT",
          phone: "0000000000",
          address_line1: "DO NOT FULFILL",
          city: "Sydney",
          state: "NSW",
          postal_code: "2000",
          country: "Australia",
        },
        p_notes: "AUTOMATED HEALTH CHECK - DO NOT FULFILL",
        p_items: [{ product_id: productId, quantity: 1 }],
        p_coupon_id: null,
      });
      if (error) throw error;
      const result = Array.isArray(data) ? data[0] : data;
      if (!result?.order_id) throw new Error("place_order returned no order_id");
      testOrderId = result.order_id;
      testOrderNumber = result.order_number;
      return `${result.order_number} total $${result.total}`;
    });

    // 3. Read it back via get_order_with_items (admin path)
    await record("read_order_back", async () => {
      const { data, error } = await admin.rpc("get_order_with_items", {
        p_order_id: testOrderId,
        p_token: null,
      });
      if (error) throw error;
      if (!data) throw new Error("get_order_with_items returned null");
      const items = (data as any).items || [];
      if (items.length === 0) throw new Error("Order has no line items");
      return `${items.length} item(s) loaded`;
    });

    // 4. Verify admin dashboard data sources respond
    await record("admin_dashboard_queries", async () => {
      const checks = await Promise.all([
        admin.from("orders").select("id", { count: "exact", head: true }),
        admin.from("products").select("id", { count: "exact", head: true }),
        admin.from("profiles").select("id", { count: "exact", head: true }),
        admin.from("coupons").select("id", { count: "exact", head: true }),
        admin.from("categories").select("id", { count: "exact", head: true }),
      ]);
      const failed = checks.find((r) => r.error);
      if (failed?.error) throw new Error(`admin query failed: ${failed.error.message}`);
      return `orders=${checks[0].count} products=${checks[1].count} profiles=${checks[2].count}`;
    });

    // 5. Verify admin account still exists and has admin role
    await record("verify_admin_account", async () => {
      const { data: prof } = await admin
        .from("profiles")
        .select("user_id, email")
        .eq("email", ADMIN_EMAIL)
        .maybeSingle();
      if (!prof?.user_id) throw new Error(`Admin profile not found for ${ADMIN_EMAIL}`);
      const { data: role } = await admin
        .from("user_roles")
        .select("role")
        .eq("user_id", prof.user_id)
        .eq("role", "admin")
        .maybeSingle();
      if (!role) throw new Error(`Admin role missing for ${ADMIN_EMAIL}`);
      return "ok";
    });
  } catch (e: any) {
    failedStep = e?.step || "unknown";
    errorMessage = e?.message || String(e);
  } finally {
    // 6. Always clean up the test order if it was created
    if (testOrderId) {
      const cleanupStart = performance.now();
      try {
        await admin.from("order_attributions").delete().eq("order_id", testOrderId);
        await admin.from("order_items").delete().eq("order_id", testOrderId);
        await admin.from("orders").delete().eq("id", testOrderId);
        steps.push({
          name: "cleanup_test_order",
          ok: true,
          ms: Math.round(performance.now() - cleanupStart),
          detail: testOrderNumber || undefined,
        });
      } catch (e: any) {
        steps.push({
          name: "cleanup_test_order",
          ok: false,
          ms: Math.round(performance.now() - cleanupStart),
          detail: e?.message || String(e),
        });
        if (!failedStep) {
          failedStep = "cleanup_test_order";
          errorMessage = e?.message || String(e);
        }
      }
    }
  }

  const duration = Math.round(performance.now() - t0);
  const status = failedStep ? "failed" : "success";

  if (runId) {
    await admin
      .from("health_check_runs")
      .update({
        status,
        completed_at: new Date().toISOString(),
        duration_ms: duration,
        test_order_number: testOrderNumber,
        failed_step: failedStep,
        error_message: errorMessage,
        steps,
      })
      .eq("id", runId);
  }

  if (status === "failed") {
    const rows = steps
      .map(
        (s) =>
          `<tr><td>${s.ok ? "✅" : "❌"}</td><td>${s.name}</td><td>${s.ms}ms</td><td>${
            s.detail ? String(s.detail).replace(/</g, "&lt;") : ""
          }</td></tr>`
      )
      .join("");
    await sendAlert(
      `❌ Daily health check FAILED at step: ${failedStep}`,
      `<h2>Aussie Smoke Store — health check failed</h2>
       <p><b>When:</b> ${startedAt.toISOString()}</p>
       <p><b>Failed step:</b> ${failedStep}</p>
       <p><b>Error:</b> ${errorMessage}</p>
       <p><b>Trigger:</b> ${trigger}</p>
       <table border="1" cellpadding="6" cellspacing="0">
         <thead><tr><th></th><th>Step</th><th>Duration</th><th>Detail</th></tr></thead>
         <tbody>${rows}</tbody>
       </table>`
    );
  }

  return { status, duration_ms: duration, failed_step: failedStep, error: errorMessage, steps, test_order_number: testOrderNumber };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    // Require authentication: either a service-role bearer (cron) or admin JWT (manual).
    let trigger: "cron" | "manual" | null = null;
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = authHeader.replace("Bearer ", "").trim();
    if (token === SERVICE_KEY) {
      trigger = "cron";
    } else {
      const userClient = createClient(SERVICE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
        global: { headers: { Authorization: authHeader } },
        auth: { persistSession: false },
      });
      const { data: u } = await userClient.auth.getUser();
      if (!u?.user) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const admin = createClient(SERVICE_URL, SERVICE_KEY, { auth: { persistSession: false } });
      const { data: role } = await admin
        .from("user_roles")
        .select("role")
        .eq("user_id", u.user.id)
        .eq("role", "admin")
        .maybeSingle();
      if (!role) {
        return new Response(JSON.stringify({ error: "Forbidden" }), {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      trigger = "manual";
    }


    const result = await runCheck(trigger);
    return new Response(JSON.stringify(result), {
      status: result.status === "success" ? 200 : 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error("health check fatal", e);
    await sendAlert(
      "❌ Daily health check CRASHED",
      `<p>Fatal error before checks could complete:</p><pre>${String(e?.message || e)}</pre>`
    );
    return new Response(JSON.stringify({ error: e?.message || String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
