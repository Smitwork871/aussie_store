import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  "https://cheapsmokescentral.com",
  "https://www.cheapsmokescentral.com",
  "https://cheapsmokecentral.lovable.app",
  "https://id-preview--c85f35eb-6636-4401-b296-afd08a7f877e.lovable.app",
  "http://localhost:8080",
  "http://localhost:5173",
];

function isAllowedOrigin(origin: string): boolean {
  try {
    const host = new URL(origin).hostname;
    return (
      ALLOWED_ORIGINS.includes(origin) ||
      host.endsWith(".lovable.app") ||
      host.endsWith(".lovableproject.com")
    );
  } catch {
    return false;
  }
}

function cors(req: Request): Record<string, string> {
  const origin = req.headers.get("Origin") ?? "";
  const allow = isAllowedOrigin(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allow,
    "Vary": "Origin",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  };
}

const SITE_URL = "https://cheapsmokescentral.com";

function wrap(html: string, unsubscribeUrl: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <div style="max-width:600px;margin:0 auto;padding:20px;">
    <div style="background:white;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
      <div style="background:#0F172A;padding:24px;text-align:center;">
        <h1 style="margin:0;color:#fff;font-size:20px;letter-spacing:0.5px;">Aussie Smoke Store</h1>
      </div>
      <div style="padding:28px;color:#374151;font-size:14px;line-height:1.65;">
        ${html}
      </div>
      <div style="padding:16px 28px;background:#f9fafb;border-top:1px solid #e5e7eb;font-size:11px;color:#6b7280;text-align:center;">
        You received this because you have an account or placed an order at Aussie Smoke Store.<br/>
        <a href="${unsubscribeUrl}" style="color:#6b7280;text-decoration:underline;">Unsubscribe from these emails</a>
      </div>
    </div>
  </div>
</body></html>`;
}

async function sendOne(resendKey: string, to: string, subject: string, html: string, unsubUrl: string) {
  return await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${resendKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "Aussie Smoke Store <orders@cheapsmokescentral.com>",
      to: [to],
      subject,
      html: wrap(html, unsubUrl),
      headers: {
        "List-Unsubscribe": `<${unsubUrl}>`,
        "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
      },
    }),
  });
}

Deno.serve(async (req) => {
  const corsHeaders = cors(req);
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  if (!RESEND_API_KEY) {
    return new Response(JSON.stringify({ error: "RESEND_API_KEY not configured" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Auth: must be admin
  const authHeader = req.headers.get("Authorization") ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const token = authHeader.replace("Bearer ", "");
  const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: claimsData, error: claimsErr } = await userClient.auth.getClaims(token);
  const userId = claimsData?.claims?.sub as string | undefined;
  if (claimsErr || !userId) {
    return new Response(JSON.stringify({ error: "Invalid session" }), {
      status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const { data: roleRow } = await admin.from("user_roles").select("role")
    .eq("user_id", userId).eq("role", "admin").maybeSingle();
  if (!roleRow) {
    return new Response(JSON.stringify({ error: "Forbidden" }), {
      status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let body: any;
  try { body = await req.json(); } catch { body = {}; }
  const action = String(body.action ?? "");
  const subject = String(body.subject ?? "").slice(0, 300);
  const html = String(body.html ?? "");

  // Page through a table to bypass PostgREST's default 1000-row cap.
  async function fetchAllColumn(table: string, column: string): Promise<string[]> {
    const PAGE = 1000;
    const out: string[] = [];
    let from = 0;
    while (true) {
      const { data, error } = await admin.from(table).select(column).range(from, from + PAGE - 1);
      if (error) throw new Error(`Load ${table}.${column} failed: ${error.message}`);
      const rows = data ?? [];
      for (const r of rows as any[]) {
        const v = r[column];
        if (typeof v === "string") out.push(v);
      }
      if (rows.length < PAGE) break;
      from += PAGE;
    }
    return out;
  }

  // Gather unique emails
  async function loadRecipients(): Promise<{ emails: string[]; suppressed: number }> {
    const [profileEmails, guestEmails, unsubEmails] = await Promise.all([
      fetchAllColumn("profiles", "email"),
      fetchAllColumn("orders", "guest_email"),
      fetchAllColumn("broadcast_unsubscribes", "email"),
    ]);
    const unsub = new Set(unsubEmails.map((e) => (e ?? "").toLowerCase()));
    const set = new Set<string>();
    for (const e0 of profileEmails) {
      const e = (e0 ?? "").trim().toLowerCase();
      if (e && /.+@.+\..+/.test(e)) set.add(e);
    }
    for (const e0 of guestEmails) {
      const e = (e0 ?? "").trim().toLowerCase();
      if (e && /.+@.+\..+/.test(e)) set.add(e);
    }
    let suppressed = 0;
    const list: string[] = [];
    for (const e of set) {
      if (unsub.has(e)) suppressed++;
      else list.push(e);
    }
    return { emails: list, suppressed };
  }


  try {
    if (action === "preview") {
      const { emails, suppressed } = await loadRecipients();
      return new Response(JSON.stringify({ total: emails.length, suppressed }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "test") {
      if (!subject || !html) throw new Error("Subject and body required");
      const testTo = String(body.to ?? "").trim().toLowerCase();
      if (!/.+@.+\..+/.test(testTo)) throw new Error("Invalid test email");
      const unsub = `${SITE_URL}/unsubscribe?email=${encodeURIComponent(testTo)}`;
      const r = await sendOne(RESEND_API_KEY, testTo, `[TEST] ${subject}`, html, unsub);
      if (!r.ok) {
        const t = await r.text();
        throw new Error(`Resend ${r.status}: ${t}`);
      }
      return new Response(JSON.stringify({ success: true, sent_to: testTo }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "send") {
      if (!subject || !html) throw new Error("Subject and body required");
      const { emails, suppressed } = await loadRecipients();

      const draftId = typeof body.broadcastId === "string" ? body.broadcastId : null;
      let broadcastId: string;
      if (draftId) {
        const { data: bc, error: bcErr } = await admin.from("broadcasts").update({
          subject, html, total: emails.length, skipped: suppressed,
          sent: 0, failed: 0, status: "running",
        }).eq("id", draftId).select("id").single();
        if (bcErr || !bc) throw new Error(`Update broadcast failed: ${bcErr?.message}`);
        broadcastId = bc.id;
      } else {
        const { data: bc, error: bcErr } = await admin.from("broadcasts").insert({
          subject, html, created_by: userId, total: emails.length,
          skipped: suppressed, status: "running",
        }).select("id").single();
        if (bcErr || !bc) throw new Error(`Create broadcast failed: ${bcErr?.message}`);
        broadcastId = bc.id;
      }


      let sent = 0, failed = 0;
      const logs: any[] = [];
      const CONCURRENCY = 5;
      const DELAY_MS = 120; // ~8/s to stay well under Resend defaults

      for (let i = 0; i < emails.length; i += CONCURRENCY) {
        const chunk = emails.slice(i, i + CONCURRENCY);
        const results = await Promise.all(chunk.map(async (email) => {
          const unsub = `${SITE_URL}/unsubscribe?email=${encodeURIComponent(email)}`;
          try {
            const r = await sendOne(RESEND_API_KEY, email, subject, html, unsub);
            if (!r.ok) {
              const t = await r.text();
              return { email, status: "failed", error: `${r.status}: ${t}`.slice(0, 500) };
            }
            return { email, status: "sent", error: null };
          } catch (e: any) {
            return { email, status: "failed", error: String(e?.message ?? e).slice(0, 500) };
          }
        }));
        for (const r of results) {
          if (r.status === "sent") sent++; else failed++;
          logs.push({ broadcast_id: broadcastId, email: r.email, status: r.status, error: r.error });
        }
        if (logs.length >= 200) {
          await admin.from("broadcast_sends").insert(logs.splice(0, logs.length));
        }
        await new Promise((res) => setTimeout(res, DELAY_MS));
      }
      if (logs.length) await admin.from("broadcast_sends").insert(logs);

      await admin.from("broadcasts").update({
        sent, failed, status: "completed",
      }).eq("id", broadcastId);

      return new Response(JSON.stringify({
        success: true, broadcast_id: broadcastId,
        total: emails.length, sent, failed, skipped: suppressed,
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "resend_failed") {
      const broadcastId = typeof body.broadcastId === "string" ? body.broadcastId : "";
      if (!broadcastId) throw new Error("broadcastId required");
      const { data: bc, error: bcErr } = await admin.from("broadcasts")
        .select("id,subject,html").eq("id", broadcastId).maybeSingle();
      if (bcErr || !bc) throw new Error(`Broadcast not found: ${bcErr?.message ?? ""}`);
      const bSubject = String(bc.subject ?? "");
      const bHtml = String(bc.html ?? "");
      if (!bSubject || !bHtml) throw new Error("Broadcast has no subject/html");

      // Page through failed rows (bypass PostgREST 1000-row cap)
      const failedRows: { id: string; email: string }[] = [];
      {
        const PAGE = 1000;
        let from = 0;
        while (true) {
          const { data, error } = await admin.from("broadcast_sends")
            .select("id,email").eq("broadcast_id", broadcastId).eq("status", "failed")
            .range(from, from + PAGE - 1);
          if (error) throw new Error(`Load failed rows: ${error.message}`);
          const rows = (data ?? []) as any[];
          for (const r of rows) failedRows.push({ id: r.id, email: r.email });
          if (rows.length < PAGE) break;
          from += PAGE;
        }
      }

      // Also exclude anyone who has unsubscribed since (paged)
      const unsubEmails = await fetchAllColumn("broadcast_unsubscribes", "email");
      const unsub = new Set(unsubEmails.map((e) => (e ?? "").toLowerCase()));


      const targets = (failedRows ?? []).filter((r: any) => !unsub.has((r.email ?? "").toLowerCase()));
      await admin.from("broadcasts").update({ status: "running" }).eq("id", broadcastId);

      let sent = 0, failed = 0;
      const CONCURRENCY = 5;
      const DELAY_MS = 120;

      for (let i = 0; i < targets.length; i += CONCURRENCY) {
        const chunk = targets.slice(i, i + CONCURRENCY);
        const results = await Promise.all(chunk.map(async (row: any) => {
          const email = row.email as string;
          const unsubUrl = `${SITE_URL}/unsubscribe?email=${encodeURIComponent(email)}`;
          try {
            const r = await sendOne(RESEND_API_KEY, email, bSubject, bHtml, unsubUrl);
            if (!r.ok) {
              const t = await r.text();
              return { id: row.id, status: "failed", error: `${r.status}: ${t}`.slice(0, 500) };
            }
            return { id: row.id, status: "sent", error: null };
          } catch (e: any) {
            return { id: row.id, status: "failed", error: String(e?.message ?? e).slice(0, 500) };
          }
        }));
        for (const r of results) {
          if (r.status === "sent") sent++; else failed++;
          await admin.from("broadcast_sends").update({
            status: r.status, error: r.error, sent_at: new Date().toISOString(),
          }).eq("id", r.id);
        }
        await new Promise((res) => setTimeout(res, DELAY_MS));
      }

      // Recompute broadcast totals from broadcast_sends (count-only, no row cap)
      const [{ count: sentCount }, { count: failedCount }] = await Promise.all([
        admin.from("broadcast_sends").select("id", { count: "exact", head: true })
          .eq("broadcast_id", broadcastId).eq("status", "sent"),
        admin.from("broadcast_sends").select("id", { count: "exact", head: true })
          .eq("broadcast_id", broadcastId).eq("status", "failed"),
      ]);
      const totalSent = sentCount ?? 0;
      const totalFailed = failedCount ?? 0;

      await admin.from("broadcasts").update({
        sent: totalSent, failed: totalFailed, status: "completed",
      }).eq("id", broadcastId);

      return new Response(JSON.stringify({
        success: true, broadcast_id: broadcastId,
        attempted: targets.length, sent, failed,
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error("send-bulk-broadcast error:", e?.message ?? e);
    return new Response(JSON.stringify({ error: String(e?.message ?? e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
