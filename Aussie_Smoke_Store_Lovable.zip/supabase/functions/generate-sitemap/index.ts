import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SITE_URL = "https://cheapsmokescentral.com";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Content-Type": "application/xml; charset=utf-8",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch active products
    const { data: products } = await supabase
      .from("products")
      .select("slug, updated_at")
      .eq("is_active", true)
      .order("updated_at", { ascending: false });

    // Fetch active categories
    const { data: categories } = await supabase
      .from("categories")
      .select("slug, updated_at")
      .eq("is_active", true)
      .order("updated_at", { ascending: false });

    // Fetch active SEO city landing pages
    const { data: seoCities } = await supabase
      .from("seo_cities")
      .select("slug, updated_at")
      .eq("is_active", true);

    const today = new Date().toISOString().split("T")[0];

    const staticPages = [
      { loc: "/", changefreq: "daily", priority: "1.0" },
      { loc: "/products", changefreq: "daily", priority: "0.9" },
      { loc: "/categories", changefreq: "weekly", priority: "0.8" },
      // Core keyword pages
      { loc: "/cheap-smokes-online", changefreq: "weekly", priority: "0.9" },
      { loc: "/cheap-cigarettes-online", changefreq: "weekly", priority: "0.9" },
      { loc: "/cheap-vapes-online", changefreq: "weekly", priority: "0.9" },
      { loc: "/cheap-tobacco-online", changefreq: "weekly", priority: "0.9" },
      { loc: "/buy-cigarettes-online-australia", changefreq: "weekly", priority: "0.9" },
      { loc: "/cheap-rolling-tobacco-online", changefreq: "weekly", priority: "0.8" },
      { loc: "/best-cigarettes-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/cheapest-cigarettes-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/discount-tobacco-online", changefreq: "weekly", priority: "0.8" },
      { loc: "/buy-cheap-smokes-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/online-tobacco-shop-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/online-smoke-shop-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/order-cigarettes-online-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/duty-free-cigarettes-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/marlboro-cigarettes-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/nicotine-pouches-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/cigarettes-near-me", changefreq: "weekly", priority: "0.8" },
      { loc: "/bulk-cigarettes-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/tobacco-delivery-australia", changefreq: "weekly", priority: "0.8" },
      { loc: "/cheap-darts-online", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-durries-online", changefreq: "weekly", priority: "0.7" },
      // City pages
      { loc: "/cheap-smokes-sydney", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-melbourne", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-brisbane", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-perth", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-adelaide", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-gold-coast", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-canberra", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-hobart", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-darwin", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-newcastle", changefreq: "weekly", priority: "0.7" },
      // State pages
      { loc: "/cheap-smokes-nsw", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-vic", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-qld", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-wa", changefreq: "weekly", priority: "0.7" },
      { loc: "/cheap-smokes-sa", changefreq: "weekly", priority: "0.7" },
      // Brand pages
      { loc: "/manchester-cigarettes-australia", changefreq: "weekly", priority: "0.7" },
      { loc: "/benson-hedges-cigarettes-australia", changefreq: "weekly", priority: "0.7" },
      { loc: "/double-happiness-cigarettes-australia", changefreq: "weekly", priority: "0.7" },
      { loc: "/uwell-vapes-australia", changefreq: "weekly", priority: "0.7" },
      { loc: "/alibarbar-vapes-australia", changefreq: "weekly", priority: "0.7" },
      // Guide pages
      { loc: "/cigarette-prices-australia", changefreq: "monthly", priority: "0.7" },
      { loc: "/rolling-tobacco-guide-australia", changefreq: "monthly", priority: "0.7" },
      { loc: "/vape-guide-australia", changefreq: "monthly", priority: "0.7" },
      { loc: "/tobacco-price-comparison-supermarkets", changefreq: "monthly", priority: "0.7" },
      // Info pages
      { loc: "/about", changefreq: "monthly", priority: "0.6" },
      { loc: "/contact", changefreq: "monthly", priority: "0.6" },
      { loc: "/privacy", changefreq: "yearly", priority: "0.3" },
      { loc: "/terms", changefreq: "yearly", priority: "0.3" },
    ];

    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;

    // Static pages
    for (const page of staticPages) {
      xml += `  <url>\n    <loc>${SITE_URL}${page.loc}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>${page.changefreq}</changefreq>\n    <priority>${page.priority}</priority>\n  </url>\n`;
    }

    // Product pages
    if (products) {
      for (const product of products) {
        const lastmod = product.updated_at ? new Date(product.updated_at).toISOString().split("T")[0] : today;
        xml += `  <url>\n    <loc>${SITE_URL}/products/${product.slug}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.7</priority>\n  </url>\n`;
      }
    }

    // Category pages intentionally omitted: /products?category=<slug> URLs
    // canonicalize to /products, so listing them in the sitemap triggers
    // Google Search Console's "Alternate page with proper canonical tag" warning.

    // SEO city landing pages (hub + 4 category subpages each)
    if (seoCities) {
      const subCategories = ["cigarettes", "vapes", "pouches", "tobacco"];
      for (const city of seoCities) {
        const lastmod = city.updated_at ? new Date(city.updated_at).toISOString().split("T")[0] : today;
        xml += `  <url>\n    <loc>${SITE_URL}/locations/${city.slug}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.7</priority>\n  </url>\n`;
        for (const cat of subCategories) {
          xml += `  <url>\n    <loc>${SITE_URL}/locations/${city.slug}/${cat}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.6</priority>\n  </url>\n`;
        }
      }
    }

    xml += `</urlset>`;

    return new Response(xml, { headers: corsHeaders });
  } catch (error) {
    console.error("Sitemap generation error:", error);
    return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>`, {
      headers: corsHeaders,
    });
  }
});
