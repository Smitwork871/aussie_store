// Recovers abandoned carts by sending reminder emails.
// Runs hourly via pg_cron. Stages: +1h reminder, +24h reminder with A$5 code, +72h last chance.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface CartItem {
  name: string;
  slug: string;
  price: number;
  quantity: number;
  image: string | null;
}

function escapeHtml(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function generateCouponCode(): string {
  return "BACK" + Math.random().toString(36).slice(2, 8).toUpperCase();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  if (!RESEND_API_KEY) {
    return new Response(JSON.stringify({ error: "RESEND_API_KEY not configured" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Require service-role bearer token (pg_cron passes this automatically)
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || authHeader !== `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }


  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const SITE_URL = "https://cheapsmokescentral.com";
  const FROM_EMAIL = "Aussie Smoke Store <orders@cheapsmokescentral.com>";

  // Email stages (hours after abandon)
  const stages: Array<{
    reminder: number;
    hoursMin: number;
    hoursMax: number;
    withCoupon: boolean;
    subject: string;
    headline: string;
    body: string;
  }> = [
    {
      reminder: 0,
      hoursMin: 1,
      hoursMax: 23,
      withCoupon: false,
      subject: "You left something in your cart 🛒",
      headline: "Still thinking it over?",
      body: "Your items are waiting. Pick up where you left off in one click.",
    },
    {
      reminder: 1,
      hoursMin: 24,
      hoursMax: 71,
      withCoupon: true,
      subject: "Here's A$5 off — your cart is still waiting",
      headline: "A little nudge: A$5 off",
      body: "Complete your order in the next 48 hours and save A$5 with the code below.",
    },
    {
      reminder: 2,
      hoursMin: 72,
      hoursMax: 168,
      withCoupon: false,
      subject: "Last chance on your cart",
      headline: "Final reminder",
      body: "We're about to clear your cart. Grab your items before they're gone.",
    },
  ];

  const results: Array<{ email: string; stage: number; sent: boolean; error?: string }> = [];

  try {
    for (const stage of stages) {
      const now = new Date();
      const minTime = new Date(now.getTime() - stage.hoursMax * 3600_000).toISOString();
      const maxTime = new Date(now.getTime() - stage.hoursMin * 3600_000).toISOString();

      const { data: carts, error } = await supabase
        .from("abandoned_carts")
        .select("id, email, cart_snapshot, subtotal, recovery_token, reminder_count")
        .is("recovered_at", null)
        .eq("reminder_count", stage.reminder)
        .gte("created_at", minTime)
        .lte("created_at", maxTime)
        .limit(50);

      if (error) {
        console.error("Query error:", error.message);
        continue;
      }
      if (!carts || carts.length === 0) continue;

      // Dedupe: skip emails that already have a recent order
      for (const cart of carts) {
        const { data: recentOrders } = await supabase
          .from("orders")
          .select("id")
          .eq("guest_email", cart.email)
          .gte("created_at", minTime)
          .limit(1);

        if (recentOrders && recentOrders.length > 0) {
          await supabase
            .from("abandoned_carts")
            .update({ recovered_at: new Date().toISOString(), recovered_order_id: recentOrders[0].id })
            .eq("id", cart.id);
          continue;
        }

        // Build coupon if needed
        let couponCode: string | null = null;
        if (stage.withCoupon) {
          couponCode = generateCouponCode();
          const validUntil = new Date(now.getTime() + 48 * 3600_000).toISOString();
          const { error: couponErr } = await supabase.from("coupons").insert({
            code: couponCode,
            description: `Abandoned cart recovery (A$5 off) for ${cart.email}`,
            discount_type: "fixed",
            discount_value: 5,
            min_order_amount: 20,
            max_uses: 1,
            is_active: true,
            valid_until: validUntil,
          });
          if (couponErr) {
            console.warn("Coupon insert failed:", couponErr.message);
            couponCode = null;
          }
        }

        const items = (cart.cart_snapshot as CartItem[]) || [];
        const recoveryUrl = `${SITE_URL}/cart?recovery=${cart.recovery_token}`;

        const itemRows = items
          .map(
            (it) => `
            <tr>
              <td style="padding:10px;border-bottom:1px solid #eee;">${escapeHtml(it.name)}</td>
              <td style="padding:10px;text-align:center;border-bottom:1px solid #eee;">${it.quantity}</td>
              <td style="padding:10px;text-align:right;border-bottom:1px solid #eee;">A$${Number(it.price).toFixed(2)}</td>
            </tr>`,
          )
          .join("");

        const couponBlock = couponCode
          ? `<div style="margin:20px 0;padding:18px;background:#fef3c7;border:1px solid #fcd34d;border-radius:10px;text-align:center;">
              <p style="margin:0 0 8px;font-size:13px;color:#92400e;">Use this code at checkout — A$5 off, expires in 48 hours:</p>
              <p style="margin:0;font-size:22px;font-weight:700;color:#92400e;letter-spacing:2px;">${escapeHtml(couponCode)}</p>
            </div>`
          : "";

        const html = `
<!DOCTYPE html>
<html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <div style="max-width:600px;margin:0 auto;padding:20px;">
    <div style="background:white;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
      <div style="background:#5B4CF5;padding:28px;text-align:center;">
        <h1 style="margin:0;color:white;font-size:22px;">${escapeHtml(stage.headline)}</h1>
      </div>
      <div style="padding:28px;">
        <p style="font-size:14px;color:#374151;line-height:1.6;margin:0 0 16px;">${escapeHtml(stage.body)}</p>
        <table style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:16px;">
          <thead><tr style="background:#f9fafb;">
            <th style="padding:10px;text-align:left;">Item</th>
            <th style="padding:10px;text-align:center;">Qty</th>
            <th style="padding:10px;text-align:right;">Price</th>
          </tr></thead>
          <tbody>${itemRows}</tbody>
          <tfoot><tr style="font-weight:700;"><td colspan="2" style="padding:10px;border-top:2px solid #e5e7eb;">Subtotal</td><td style="padding:10px;text-align:right;border-top:2px solid #e5e7eb;">A$${Number(cart.subtotal).toFixed(2)}</td></tr></tfoot>
        </table>
        ${couponBlock}
        <div style="text-align:center;margin:24px 0;">
          <a href="${recoveryUrl}" style="display:inline-block;background:#5B4CF5;color:white;text-decoration:none;padding:14px 32px;border-radius:8px;font-weight:600;font-size:15px;">Complete my order →</a>
        </div>
        <p style="font-size:12px;color:#9ca3af;text-align:center;margin:18px 0 0;">Free shipping on orders over A$50 · 48h dispatch from Australia</p>
      </div>
      <div style="background:#f9fafb;padding:16px;text-align:center;font-size:11px;color:#9ca3af;">
        <p style="margin:0;">Aussie Smoke Store — you're receiving this because you started a checkout with us.</p>
      </div>
    </div>
  </div>
</body></html>`;

        const resendRes = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${RESEND_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            from: FROM_EMAIL,
            to: [cart.email],
            subject: stage.subject,
            html,
          }),
        });

        if (!resendRes.ok) {
          const errText = await resendRes.text();
          console.error(`Resend failed for ${cart.email}:`, errText);
          results.push({ email: cart.email, stage: stage.reminder, sent: false, error: errText });
          continue;
        }

        await supabase
          .from("abandoned_carts")
          .update({
            reminder_count: stage.reminder + 1,
            last_reminder_at: new Date().toISOString(),
          })
          .eq("id", cart.id);

        results.push({ email: cart.email, stage: stage.reminder, sent: true });
      }
    }

    return new Response(JSON.stringify({ success: true, results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    console.error("recover-abandoned-carts error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
