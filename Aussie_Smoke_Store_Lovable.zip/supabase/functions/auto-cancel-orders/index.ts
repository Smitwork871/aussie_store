import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  

  // Verify the caller is authorized (service role key required)
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || authHeader !== `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  try {
    // Daily review pass: flag (do NOT cancel) orders still pending + unpaid 7+ days after placement.
    // Admins action these from the "Unpaid Orders (7+ Days)" tab, which restores stock on cancel.
    const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

    const { data: staleOrders, error } = await supabase
      .from("orders")
      .select("id, order_number, created_at, total")
      .eq("status", "pending")
      .eq("payment_status", "pending")
      .lt("created_at", cutoff)
      .order("created_at", { ascending: true });

    if (error) throw error;

    const flagged = staleOrders ?? [];
    console.log(`Flagged ${flagged.length} unpaid orders (7+ days) for admin review`);

    return new Response(
      JSON.stringify({
        flagged: flagged.length,
        cancelled: 0,
        orders: flagged.map((o) => o.order_number),
      }),
      { headers: { "Content-Type": "application/json" } }
    );

  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    console.error("auto-cancel-orders error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
