// Generates unique AI intro + FAQs per city in seo_cities.
// Admin-triggered. Idempotent (skips cities that already have intro_html unless force=true).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
const SITE_BRAND = "Aussie Smoke Store";

async function generateCityContent(city: {
  name: string; state_full: string; region: string | null; nearest_capital: string | null; population: number | null;
}) {
  const prompt = `Write SEO landing-page content for an Australian online tobacco / vape / nicotine pouch retailer called "${SITE_BRAND}" delivering to ${city.name}, ${city.state_full}${city.region ? " (" + city.region + " region)" : ""}.
Audience: adult smokers/vapers (18+) in ${city.name} who want cheaper prices and home delivery.
Output STRICT JSON only, no markdown fences, with this exact shape:
{
  "intro_html": "<p>...</p><p>...</p>",  // 2 unique paragraphs (90-140 words total). Mention ${city.name} naturally, the nearest capital (${city.nearest_capital ?? "the nearest capital"}), realistic delivery timing for regional AU, why locals order online vs local tobacconists. Avoid clichés, no fake guarantees, no medical claims, no underage references. No headings.
  "faqs": [
    {"q": "How long does delivery take to ${city.name}?", "a": "..."},
    {"q": "Is it legal to buy cigarettes online in ${city.state_full}?", "a": "..."},
    {"q": "Do you ship vapes and nicotine pouches to ${city.name}?", "a": "..."}
  ]
}
Tone: plain, factual, Australian English. No emojis. Each FAQ answer 30-60 words.`;

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${LOVABLE_API_KEY}` },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    }),
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`AI gateway ${res.status}: ${txt.slice(0, 200)}`);
  }
  const json = await res.json();
  const content = json.choices?.[0]?.message?.content ?? "{}";
  return JSON.parse(content);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Verify caller is admin
    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const { data: isAdmin } = await userClient.rpc("has_role", {
      _user_id: userData.user.id, _role: "admin",
    });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const force: boolean = !!body.force;
    const limit: number = Math.min(Math.max(parseInt(body.limit ?? "30", 10), 1), 60);

    const admin = createClient(supabaseUrl, serviceKey);
    let query = admin.from("seo_cities").select("id, slug, name, state_full, region, nearest_capital, population").eq("is_active", true);
    if (!force) query = query.is("intro_html", null);
    const { data: cities, error } = await query.limit(limit);
    if (error) throw error;

    const results: { slug: string; ok: boolean; error?: string }[] = [];
    for (const city of cities ?? []) {
      try {
        const content = await generateCityContent(city);
        const intro_html = String(content.intro_html ?? "").slice(0, 4000);
        const local_faq = Array.isArray(content.faqs) ? content.faqs.slice(0, 5) : [];
        await admin.from("seo_cities")
          .update({ intro_html, local_faq })
          .eq("id", city.id);
        results.push({ slug: city.slug, ok: true });
        await new Promise(r => setTimeout(r, 300)); // gentle rate-limit
      } catch (e) {
        results.push({ slug: city.slug, ok: false, error: (e as Error).message });
      }
    }

    return new Response(JSON.stringify({
      processed: results.length,
      succeeded: results.filter(r => r.ok).length,
      failed: results.filter(r => !r.ok).length,
      remaining_hint: "Call again until processed=0 to finish backfill.",
      results,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
