# Aussie Smoke Store

A React, TypeScript and Vite storefront with Supabase authentication, catalogue, orders, storage and administration.

## Review in Lovable

Use a working copy of the original Lovable project. Apply this source at its project root, keeping package.json next to index.html. The archive includes the original browser-facing Supabase settings in .env. For a staging review, set VITE_SUPABASE_URL, VITE_SUPABASE_PROJECT_ID and VITE_SUPABASE_PUBLISHABLE_KEY to the corresponding values for your staging project before starting Vite. Keep privileged keys in server-side secrets.

The source includes migrations and Edge Functions. A source upload alone does not copy database records, product images, users or server-side secrets. An existing backend can already have these migrations applied. Check its migration history before applying changes.

## Run locally

Use Node 22 or later. Run npm ci, then npm run dev. For the production build run npm run build. The output is dist/. Configure static hosting to serve index.html for application routes.

## Review checklist

1. Open the home page at desktop and phone widths. Check both age-screen choices in separate sessions.
2. Search for an existing product. Check filters, categories and price sorting.
3. Open a product, add it to the cart, change the quantity and reload checkout.
4. Use a staging customer to check registration, sign-in, saved items and order history.
5. Use a staging order to check totals, coupon handling, confirmation and email delivery.
6. Use a staging administrator to review inventory, orders and bulk operations. Check the configured payment recipient before enabling orders.
